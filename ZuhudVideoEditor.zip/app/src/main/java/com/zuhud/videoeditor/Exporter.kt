package com.zuhud.videoeditor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Crop
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.FileInputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Mengekspor proyek menjadi MP4 memakai Media3 Transformer:
 * pangkas + potong + gabung + kecepatan + teks/gambar + musik, lalu simpan ke Movies/ZuhudVideoEditor.
 */
class Exporter(private val context: Context) {

    interface Callback {
        fun onProgress(percent: Int)
        fun onDone(uri: Uri)
        fun onError(message: String)
    }

    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var outFile: File? = null
    private var cancelled = false
    private var polling: Runnable? = null

    /**
     * @param shortSide sisi terpendek hasil (1080, 1440, 2160) atau 0 untuk Native Resolution
     *            (mengikuti sisi terpendek video pertama).
     * @param fps 0 = pertahankan FPS asli (default, gerakan paling natural). Nilai lain (30/60/120)
     *            hanya batas maksimum: tidak ada interpolasi atau frame generation, jadi tidak ada ghosting.
     * Harus dipanggil dari thread utama.
     */
    fun start(project: Project, shortSide: Int, fps: Int, cb: Callback) {
        LayerRenderer.init(context)
        val clips = project.clips.map { it.copy() }
        val layers = project.layers.map { it.copy() }
        val audio = project.audio
        val mute = project.muteOriginal
        val fill = project.fillMode
        if (clips.isEmpty()) {
            cb.onError("Tidak ada klip untuk diekspor")
            return
        }

        val file = File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        outFile = file
        cancelled = false

        try {
            val first = clips.first()
            val base = if (shortSide > 0) shortSide else min(first.width, first.height)
            val (outW, outH) = outputSize(project.canvasAspect(), base)
            val totalMs = clips.sumOf { it.effectiveMs }
            val layout = if (fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT

            // --- urutan video: tiap klip dipangkas lalu dipas ke ukuran kanvas ---
            val videoItems = clips.map { c ->
                val mediaItem = MediaItem.Builder()
                    .setUri(c.uri)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(c.startMs)
                            .setEndPositionMs(c.endMs)
                            .build()
                    )
                    .build()

                val itemEffects = ArrayList<Effect>()
                if (c.hasCrop) {
                    // Crop memakai koordinat -1..1 (kiri, kanan, bawah, atas)
                    itemEffects.add(
                        Crop(
                            -1f + 2f * c.cropL,
                            1f - 2f * c.cropR,
                            -1f + 2f * c.cropB,
                            1f - 2f * c.cropT
                        )
                    )
                }
                itemEffects.add(Presentation.createForWidthAndHeight(outW, outH, layout))

                val b = EditedMediaItem.Builder(mediaItem)
                    .setRemoveAudio(mute)
                    .setEffects(Effects(listOf<AudioProcessor>(), itemEffects))
                // fps <= 0 berarti FPS asli.
                if (fps > 0) b.setFrameRate(fps)
                if (c.speed != 1f) b.setSpeed(ConstantSpeed(c.speed))
                b.build()
            }
            val videoSequence = if (mute) {
                EditedMediaItemSequence.withVideoFrom(videoItems)
            } else {
                EditedMediaItemSequence.withAudioAndVideoFrom(videoItems)
            }

            // --- musik latar (diulang sampai video selesai, dipotong bila lebih panjang) ---
            val audioSequence = audio?.let { a ->
                val mb = MediaItem.Builder().setUri(a.uri)
                if (a.durationMs > totalMs) {
                    mb.setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(0)
                            .setEndPositionMs(totalMs)
                            .build()
                    )
                }
                val item = EditedMediaItem.Builder(mb.build()).build()
                EditedMediaItemSequence.withAudioFrom(listOf(item))
                    .buildUpon()
                    .setIsLooping(true)
                    .build()
            }

            // --- efek tingkat komposisi: teks/gambar ---
            val compEffects = ArrayList<Effect>()
            if (layers.isNotEmpty()) {
                compEffects.add(
                    OverlayEffect(
                        ImmutableList.of<TextureOverlay>(LayersOverlay(outW, outH, layers))
                    )
                )
            }

            val builder = if (audioSequence != null) {
                Composition.Builder(videoSequence, audioSequence)
            } else {
                Composition.Builder(videoSequence)
            }
            val composition = builder
                .setEffects(Effects(listOf<AudioProcessor>(), compEffects))
                .build()

            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopPolling()
                    saveToGallery(file, cb)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    stopPolling()
                    file.delete()
                    if (!cancelled) {
                        cb.onError("${exportException.errorCodeName}: ${exportException.message}")
                    }
                }
            }

            val videoMime =
                if (max(outW, outH) > 2000) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264

            val t = Transformer.Builder(context)
                .setVideoMimeType(videoMime)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
            transformer = t
            t.start(composition, file.absolutePath)
            startPolling(t, cb)
        } catch (e: Exception) {
            file.delete()
            cb.onError(e.message ?: e.javaClass.simpleName)
        }
    }

    fun cancel() {
        cancelled = true
        stopPolling()
        try {
            transformer?.cancel()
        } catch (e: Exception) {
            // abaikan
        }
        outFile?.delete()
    }

    private fun startPolling(t: Transformer, cb: Callback) {
        val holder = ProgressHolder()
        val r = object : Runnable {
            override fun run() {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    cb.onProgress(holder.progress)
                }
                handler.postDelayed(this, 300)
            }
        }
        polling = r
        handler.post(r)
    }

    private fun stopPolling() {
        polling?.let { handler.removeCallbacks(it) }
        polling = null
    }

    /** Sisi terpendek = base, sisi lainnya mengikuti rasio kanvas. Keduanya genap. */
    private fun outputSize(aspect: Float, base: Int): Pair<Int, Int> {
        return if (aspect >= 1f) {
            even(base * aspect) to even(base.toFloat())
        } else {
            even(base.toFloat()) to even(base / aspect)
        }
    }

    private fun even(v: Float): Int = max(2, (v.roundToInt() / 2) * 2)

    /** Menyalin hasil dari cache ke galeri (Movies/ZuhudVideoEditor) di thread terpisah. */
    private fun saveToGallery(file: File, cb: Callback) {
        Thread {
            try {
                val resolver = context.contentResolver
                val name = "Zuhud_${System.currentTimeMillis()}.mp4"
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(
                        MediaStore.Video.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_MOVIES + "/ZuhudVideoEditor"
                    )
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Gagal membuat berkas di galeri")
                resolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(file).use { input -> input.copyTo(out) }
                } ?: throw IllegalStateException("Gagal menulis berkas")
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                file.delete()
                handler.post { cb.onDone(uri) }
            } catch (e: Exception) {
                file.delete()
                handler.post { cb.onError(e.message ?: "Gagal menyimpan hasil") }
            }
        }.start()
    }
}

/** Kecepatan tetap untuk satu klip. */
private class ConstantSpeed(private val speed: Float) : SpeedProvider {
    override fun getSpeed(timeUs: Long): Float = speed
    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = C.TIME_UNSET
}

/**
 * Overlay seukuran frame hasil yang menggambar semua teks/gambar aktif pada waktu tertentu
 * memakai LayerRenderer yang sama dengan preview.
 */
private class LayersOverlay(
    private val w: Int,
    private val h: Int,
    private val layers: List<Layer>
) : BitmapOverlay() {

    private val empty: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    private var lastKey: String? = null
    private var lastBitmap: Bitmap = empty

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        val active = layers.filter { LayerRenderer.isActive(it, ms) }
        if (active.isEmpty()) return empty

        val key = active.joinToString(",") { it.id.toString() }
        if (key == lastKey) return lastBitmap

        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        for (l in active) LayerRenderer.drawLayer(canvas, w.toFloat(), h.toFloat(), l)
        lastKey = key
        lastBitmap = bmp
        return bmp
    }
}
