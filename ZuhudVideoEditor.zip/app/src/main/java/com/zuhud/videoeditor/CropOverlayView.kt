package com.zuhud.videoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Bingkai pangkas (crop) yang bisa ditarik. View ini menutupi seluruh frame video,
 * dan rect disimpan sebagai pecahan 0..1 dari frame.
 */
class CropOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density

    // pecahan 0..1 terhadap frame video
    var fLeft = 0f
        private set
    var fTop = 0f
        private set
    var fRight = 1f
        private set
    var fBottom = 1f
        private set

    /** Ukuran asli video (piksel), untuk menjaga rasio saat dikunci. */
    private var srcW = 16f
    private var srcH = 9f

    /** Rasio lebar/tinggi yang dikunci (piksel video). 0 = bebas. */
    private var ratio = 0f

    private val dimPaint = Paint().apply { color = 0xAA000000.toInt() }
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFFFFFF.toInt()
        strokeWidth = 2f * density
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x66FFFFFF
        strokeWidth = 1f * density
    }
    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFFFFFF.toInt()
        strokeWidth = 4f * density
        strokeCap = Paint.Cap.SQUARE
    }

    private enum class Drag { NONE, MOVE, TL, TR, BL, BR, L, T, R, B }

    private var drag = Drag.NONE
    private var lastX = 0f
    private var lastY = 0f

    fun setSource(w: Int, h: Int) {
        srcW = max(1, w).toFloat()
        srcH = max(1, h).toFloat()
    }

    fun setRect(l: Float, t: Float, r: Float, b: Float) {
        fLeft = l.coerceIn(0f, 0.95f)
        fTop = t.coerceIn(0f, 0.95f)
        fRight = r.coerceIn(fLeft + 0.05f, 1f)
        fBottom = b.coerceIn(fTop + 0.05f, 1f)
        invalidate()
    }

    /** Menetapkan rasio terkunci (lebar/tinggi) dan memasang bingkai terbesar di tengah. 0 = bebas. */
    fun setRatio(r: Float) {
        ratio = r
        if (r <= 0f) return
        // bingkai terbesar dengan rasio r di dalam frame, di tengah
        val frameAspect = srcW / srcH
        var wFrac: Float
        var hFrac: Float
        if (r >= frameAspect) {
            wFrac = 1f
            hFrac = frameAspect / r
        } else {
            hFrac = 1f
            wFrac = r / frameAspect
        }
        wFrac = wFrac.coerceIn(0.05f, 1f)
        hFrac = hFrac.coerceIn(0.05f, 1f)
        fLeft = (1f - wFrac) / 2f
        fRight = fLeft + wFrac
        fTop = (1f - hFrac) / 2f
        fBottom = fTop + hFrac
        invalidate()
    }

    fun reset() {
        ratio = 0f
        fLeft = 0f
        fTop = 0f
        fRight = 1f
        fBottom = 1f
        invalidate()
    }

    private fun rectPx(): RectF = RectF(fLeft * width, fTop * height, fRight * width, fBottom * height)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = rectPx()
        canvas.drawRect(0f, 0f, w, r.top, dimPaint)
        canvas.drawRect(0f, r.bottom, w, h, dimPaint)
        canvas.drawRect(0f, r.top, r.left, r.bottom, dimPaint)
        canvas.drawRect(r.right, r.top, w, r.bottom, dimPaint)
        canvas.drawRect(r, framePaint)

        val tw = r.width() / 3f
        val th = r.height() / 3f
        for (i in 1..2) {
            canvas.drawLine(r.left + tw * i, r.top, r.left + tw * i, r.bottom, gridPaint)
            canvas.drawLine(r.left, r.top + th * i, r.right, r.top + th * i, gridPaint)
        }

        val c = 18f * density
        canvas.drawLine(r.left, r.top, r.left + c, r.top, cornerPaint)
        canvas.drawLine(r.left, r.top, r.left, r.top + c, cornerPaint)
        canvas.drawLine(r.right, r.top, r.right - c, r.top, cornerPaint)
        canvas.drawLine(r.right, r.top, r.right, r.top + c, cornerPaint)
        canvas.drawLine(r.left, r.bottom, r.left + c, r.bottom, cornerPaint)
        canvas.drawLine(r.left, r.bottom, r.left, r.bottom - c, cornerPaint)
        canvas.drawLine(r.right, r.bottom, r.right - c, r.bottom, cornerPaint)
        canvas.drawLine(r.right, r.bottom, r.right, r.bottom - c, cornerPaint)
    }

    // ---------------------------------------------------------------- touch

    private fun pick(x: Float, y: Float): Drag {
        val r = rectPx()
        val t = 28f * density
        val nearL = abs(x - r.left) < t
        val nearR = abs(x - r.right) < t
        val nearT = abs(y - r.top) < t
        val nearB = abs(y - r.bottom) < t
        if (nearL && nearT) return Drag.TL
        if (nearR && nearT) return Drag.TR
        if (nearL && nearB) return Drag.BL
        if (nearR && nearB) return Drag.BR
        if (ratio <= 0f) {
            val inX = x > r.left && x < r.right
            val inY = y > r.top && y < r.bottom
            if (nearL && inY) return Drag.L
            if (nearR && inY) return Drag.R
            if (nearT && inX) return Drag.T
            if (nearB && inX) return Drag.B
        }
        if (r.contains(x, y)) return Drag.MOVE
        return Drag.NONE
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                drag = pick(e.x, e.y)
                lastX = e.x
                lastY = e.y
                parent?.requestDisallowInterceptTouchEvent(true)
                return drag != Drag.NONE
            }
            MotionEvent.ACTION_MOVE -> {
                val w = max(1f, width.toFloat())
                val h = max(1f, height.toFloat())
                val dx = (e.x - lastX) / w
                val dy = (e.y - lastY) / h
                lastX = e.x
                lastY = e.y
                val minSize = 0.08f
                when (drag) {
                    Drag.MOVE -> {
                        val rw = fRight - fLeft
                        val rh = fBottom - fTop
                        fLeft = (fLeft + dx).coerceIn(0f, 1f - rw)
                        fTop = (fTop + dy).coerceIn(0f, 1f - rh)
                        fRight = fLeft + rw
                        fBottom = fTop + rh
                    }
                    Drag.L -> fLeft = (fLeft + dx).coerceIn(0f, fRight - minSize)
                    Drag.R -> fRight = (fRight + dx).coerceIn(fLeft + minSize, 1f)
                    Drag.T -> fTop = (fTop + dy).coerceIn(0f, fBottom - minSize)
                    Drag.B -> fBottom = (fBottom + dy).coerceIn(fTop + minSize, 1f)
                    Drag.TL, Drag.TR, Drag.BL, Drag.BR -> dragCorner(e.x / w, e.y / h, minSize)
                    Drag.NONE -> {}
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                drag = Drag.NONE
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun dragCorner(tx0: Float, ty0: Float, minSize: Float) {
        val tx = tx0.coerceIn(0f, 1f)
        val ty = ty0.coerceIn(0f, 1f)
        // sudut yang tetap = sudut berseberangan
        val fx = if (drag == Drag.TL || drag == Drag.BL) fRight else fLeft
        val fy = if (drag == Drag.TL || drag == Drag.TR) fBottom else fTop
        val signX = if (tx >= fx) 1f else -1f
        val signY = if (ty >= fy) 1f else -1f
        var wFrac = max(minSize, abs(tx - fx))
        var hFrac = max(minSize, abs(ty - fy))
        if (ratio > 0f) {
            // wFrac * srcW / (hFrac * srcH) = ratio
            hFrac = wFrac * srcW / (ratio * srcH)
            val maxW = if (signX > 0) 1f - fx else fx
            val maxH = if (signY > 0) 1f - fy else fy
            if (wFrac > maxW) {
                wFrac = maxW
                hFrac = wFrac * srcW / (ratio * srcH)
            }
            if (hFrac > maxH) {
                hFrac = maxH
                wFrac = hFrac * ratio * srcH / srcW
            }
        }
        val nx = fx + signX * wFrac
        val ny = fy + signY * hFrac
        fLeft = min(fx, nx).coerceIn(0f, 1f)
        fRight = max(fx, nx).coerceIn(0f, 1f)
        fTop = min(fy, ny).coerceIn(0f, 1f)
        fBottom = max(fy, ny).coerceIn(0f, 1f)
    }

    @Suppress("unused")
    private fun dist(a: Float, b: Float) = hypot(a, b)
}
