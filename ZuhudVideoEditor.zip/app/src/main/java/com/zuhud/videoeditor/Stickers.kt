package com.zuhud.videoeditor

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.cos
import kotlin.math.sin

/**
 * Katalog dan penggambar stiker. Semua digambar lewat kode (tanpa berkas gambar/unduhan):
 *  "e:😺"        emoji (berwarna bawaan sistem)
 *  "t:WKWK"      stiker teks gaya meme
 *  "v:bentuk:rot" bentuk vektor yang warnanya bisa diganti (rot = putaran derajat)
 */
object Stickers {

    class Category(val name: String, val items: List<String>)

    private fun emoji(s: String): List<String> =
        s.trim().split(" ").filter { it.isNotEmpty() }.map { "e:$it" }

    private fun rotated(name: String, vararg rots: Int): List<String> = rots.map { "v:$name:$it" }

    val categories: List<Category> = listOf(
        Category(
            "Meme",
            listOf("WKWK", "NGAKAK", "LOL", "OMG", "BRUH", "NO WAY", "POV", "GG", "MANTAP", "GOKIL", "SABAR", "CRINGE")
                .map { "t:$it" } +
                emoji("😂 🤣 😭 😎 🤡 💀 🗿 🔥 🤯 😱 🥶 🥵 😤 🙄 🤔 😏 😳 🤪 🤫 🤙 🙏 👀 💩 😈 🤓 🥴 😴 🤮")
        ),
        Category(
            "Kucing",
            emoji("😺 😸 😹 😻 😼 😽 🙀 😿 😾 🐱 🐈 🐾 🦁 🐯 🐅 🐆 🐭 🧶 🐟 🥛 🎀")
        ),
        Category(
            "Modern",
            listOf(
                "star", "heart", "burst", "starburst", "sparkle", "ring", "bubble", "bolt",
                "triangle", "diamond", "plus", "check", "cloud", "moon"
            ).map { "v:$it:0" } + rotated("plus", 45) + emoji("✨ 💯 🎉 🏆 👑 🚀 💎 💥 🌈 ⭐ ❤️ 🎵")
        ),
        Category(
            "Panah",
            rotated("arrow", 0, 45, 90, 135, 180, 225, 270, 315) +
                rotated("block", 0, 90, 180, 270) +
                rotated("chevron", 0, 90, 180, 270) +
                rotated("chevron2", 0, 90, 180, 270) +
                rotated("doublehead", 0, 90) +
                rotated("curve", 0, 90, 180, 270) +
                rotated("uturn", 0, 90, 180, 270) +
                rotated("zigzag", 0, 90) +
                rotated("loop", 0, 180) +
                rotated("pointer", 0, 90, 180, 270)
        )
    )

    // ------------------------------------------------------------ menggambar

    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF000000.toInt()
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    /** Menggambar stiker (bukan "t:") berpusat di titik asal dengan ukuran size x size. */
    fun draw(c: Canvas, key: String, size: Float, color: Int) {
        if (key.startsWith("e:")) {
            emojiPaint.textSize = size * 0.8f
            val y = -(emojiPaint.ascent() + emojiPaint.descent()) / 2f
            c.drawText(key.substring(2), 0f, y, emojiPaint)
            return
        }
        if (!key.startsWith("v:")) return
        val parts = key.split(":")
        val name = parts.getOrNull(1) ?: return
        val rot = parts.getOrNull(2)?.toFloatOrNull() ?: 0f
        c.save()
        c.scale(size, size)
        c.rotate(rot)
        fill.color = color
        val ow = 0.045f
        for (shape in shapes(name)) {
            if (shape.stroke > 0f) {
                outline.strokeWidth = shape.stroke + ow * 2f
                c.drawPath(shape.path, outline)
                fill.style = Paint.Style.STROKE
                fill.strokeWidth = shape.stroke
                fill.strokeCap = Paint.Cap.ROUND
                fill.strokeJoin = Paint.Join.ROUND
                c.drawPath(shape.path, fill)
            } else {
                outline.strokeWidth = ow
                c.drawPath(shape.path, outline)
                fill.style = Paint.Style.FILL
                c.drawPath(shape.path, fill)
            }
        }
        c.restore()
    }

    // ---------------------------------------------------------------- bentuk

    private class Shape(val path: Path, val stroke: Float = 0f)

    private fun poly(vararg v: Float): Path {
        val p = Path()
        p.moveTo(v[0], v[1])
        var i = 2
        while (i < v.size) {
            p.lineTo(v[i], v[i + 1])
            i += 2
        }
        p.close()
        return p
    }

    private fun starPath(points: Int, outer: Float, inner: Float): Path {
        val p = Path()
        val n = points * 2
        for (i in 0 until n) {
            val r = if (i % 2 == 0) outer else inner
            val a = Math.toRadians((-90.0 + i * 360.0 / n))
            val x = (r * cos(a)).toFloat()
            val y = (r * sin(a)).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    /** Kepala panah segitiga dengan ujung di (x,y) menghadap sudut deg. */
    private fun head(x: Float, y: Float, deg: Float, len: Float = 0.24f, half: Float = 0.17f): Path {
        val a = Math.toRadians(deg.toDouble())
        val dx = cos(a).toFloat()
        val dy = sin(a).toFloat()
        val bx = x - dx * len
        val by = y - dy * len
        val nx = -dy
        val ny = dx
        return poly(x, y, bx + nx * half, by + ny * half, bx - nx * half, by - ny * half)
    }

    private fun shapes(name: String): List<Shape> = when (name) {
        "star" -> listOf(Shape(starPath(5, 0.5f, 0.22f)))
        "heart" -> {
            val p = Path()
            p.moveTo(0f, 0.45f)
            p.cubicTo(-0.65f, 0.0f, -0.45f, -0.5f, 0f, -0.2f)
            p.cubicTo(0.45f, -0.5f, 0.65f, 0.0f, 0f, 0.45f)
            p.close()
            listOf(Shape(p))
        }
        "burst" -> listOf(Shape(starPath(12, 0.5f, 0.38f)))
        "starburst" -> listOf(Shape(starPath(8, 0.5f, 0.24f)))
        "sparkle" -> listOf(Shape(starPath(4, 0.5f, 0.1f)))
        "ring" -> {
            val p = Path()
            p.fillType = Path.FillType.EVEN_ODD
            p.addCircle(0f, 0f, 0.46f, Path.Direction.CW)
            p.addCircle(0f, 0f, 0.28f, Path.Direction.CW)
            listOf(Shape(p))
        }
        "bubble" -> {
            val p = Path()
            p.addRoundRect(RectF(-0.5f, -0.42f, 0.5f, 0.2f), 0.16f, 0.16f, Path.Direction.CW)
            val tail = poly(-0.22f, 0.15f, -0.32f, 0.5f, 0.04f, 0.15f)
            listOf(Shape(p), Shape(tail))
        }
        "bolt" -> listOf(Shape(poly(0.1f, -0.5f, -0.3f, 0.08f, -0.02f, 0.08f, -0.12f, 0.5f, 0.32f, -0.12f, 0.04f, -0.12f)))
        "triangle" -> listOf(Shape(poly(0f, -0.45f, 0.5f, 0.4f, -0.5f, 0.4f)))
        "diamond" -> listOf(Shape(poly(0f, -0.5f, 0.4f, 0f, 0f, 0.5f, -0.4f, 0f)))
        "plus" -> listOf(
            Shape(
                poly(
                    -0.12f, -0.45f, 0.12f, -0.45f, 0.12f, -0.12f, 0.45f, -0.12f, 0.45f, 0.12f,
                    0.12f, 0.12f, 0.12f, 0.45f, -0.12f, 0.45f, -0.12f, 0.12f, -0.45f, 0.12f,
                    -0.45f, -0.12f, -0.12f, -0.12f
                )
            )
        )
        "check" -> listOf(Shape(poly(-0.45f, 0.05f, -0.28f, -0.12f, -0.1f, 0.06f, 0.28f, -0.4f, 0.45f, -0.23f, -0.1f, 0.4f)))
        "cloud" -> {
            val p = Path()
            p.addCircle(-0.22f, 0.08f, 0.24f, Path.Direction.CW)
            p.addCircle(0.02f, -0.1f, 0.3f, Path.Direction.CW)
            p.addCircle(0.26f, 0.1f, 0.22f, Path.Direction.CW)
            p.addRoundRect(RectF(-0.42f, 0.1f, 0.46f, 0.32f), 0.11f, 0.11f, Path.Direction.CW)
            listOf(Shape(p))
        }
        "moon" -> {
            val a = Path()
            a.addCircle(0f, 0f, 0.44f, Path.Direction.CW)
            val b = Path()
            b.addCircle(0.2f, -0.12f, 0.36f, Path.Direction.CW)
            a.op(b, Path.Op.DIFFERENCE)
            listOf(Shape(a))
        }
        "arrow" -> listOf(Shape(poly(-0.5f, -0.1f, 0.1f, -0.1f, 0.1f, -0.3f, 0.5f, 0f, 0.1f, 0.3f, 0.1f, 0.1f, -0.5f, 0.1f)))
        "block" -> listOf(Shape(poly(-0.5f, -0.2f, 0.05f, -0.2f, 0.05f, -0.45f, 0.5f, 0f, 0.05f, 0.45f, 0.05f, 0.2f, -0.5f, 0.2f)))
        "chevron" -> listOf(Shape(poly(-0.3f, -0.45f, -0.1f, -0.45f, 0.3f, 0f, -0.1f, 0.45f, -0.3f, 0.45f, 0.1f, 0f)))
        "chevron2" -> listOf(
            Shape(poly(-0.45f, -0.4f, -0.28f, -0.4f, 0.0f, 0f, -0.28f, 0.4f, -0.45f, 0.4f, -0.17f, 0f)),
            Shape(poly(-0.05f, -0.4f, 0.12f, -0.4f, 0.4f, 0f, 0.12f, 0.4f, -0.05f, 0.4f, 0.23f, 0f))
        )
        "doublehead" -> listOf(
            Shape(
                poly(
                    -0.5f, 0f, -0.2f, -0.3f, -0.2f, -0.1f, 0.2f, -0.1f, 0.2f, -0.3f, 0.5f, 0f,
                    0.2f, 0.3f, 0.2f, 0.1f, -0.2f, 0.1f, -0.2f, 0.3f
                )
            )
        )
        "curve" -> {
            val p = Path()
            p.moveTo(-0.42f, 0.38f)
            p.quadTo(-0.42f, -0.3f, 0.12f, -0.3f)
            listOf(Shape(p, 0.12f), Shape(head(0.48f, -0.3f, 0f)))
        }
        "uturn" -> {
            val p = Path()
            p.moveTo(-0.34f, 0.45f)
            p.lineTo(-0.34f, -0.08f)
            p.quadTo(-0.34f, -0.4f, 0f, -0.4f)
            p.quadTo(0.32f, -0.4f, 0.32f, -0.08f)
            p.lineTo(0.32f, 0.08f)
            listOf(Shape(p, 0.12f), Shape(head(0.32f, 0.46f, 90f)))
        }
        "zigzag" -> {
            val p = Path()
            p.moveTo(-0.46f, 0.32f)
            p.lineTo(-0.2f, -0.2f)
            p.lineTo(0.02f, 0.2f)
            p.lineTo(0.2f, -0.12f)
            listOf(Shape(p, 0.11f), Shape(head(0.48f, -0.32f, -35f)))
        }
        "loop" -> {
            val p = Path()
            p.addArc(RectF(-0.34f, -0.34f, 0.34f, 0.34f), 40f, 270f)
            // ujung busur di sudut 310 derajat; arah singgung searah putaran jam
            val a = Math.toRadians(310.0)
            val ex = (0.34 * cos(a)).toFloat()
            val ey = (0.34 * sin(a)).toFloat()
            listOf(Shape(p, 0.11f), Shape(head(ex + 0.12f, ey + 0.14f, 50f)))
        }
        "pointer" -> listOf(Shape(poly(-0.35f, -0.45f, 0.45f, 0f, -0.35f, 0.45f)))
        else -> emptyList()
    }
}
