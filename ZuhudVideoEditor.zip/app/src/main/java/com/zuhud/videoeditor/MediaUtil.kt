package com.zuhud.videoeditor

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import java.util.Locale

object MediaUtil {

    fun formatTime(ms: Long): String {
        val totalSec = (ms / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", totalSec / 60, totalSec % 60)
    }

    fun formatSeconds(ms: Long): String = String.format(Locale.US, "%.1f", ms / 1000.0)

    fun keepAccess(context: Context, uri: Uri) {
        try {
            context.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: Exception) {
            // Tidak semua URI mendukung izin permanen; abaikan.
        }
    }

    fun displayName(context: Context, uri: Uri): String {
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        val name = c.getString(0)
                        if (!name.isNullOrBlank()) return name
                    }
                }
        } catch (e: Exception) {
            // gunakan cadangan di bawah
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "media"
    }

    fun probeVideo(context: Context, uri: Uri): Clip? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            if (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) != "yes") return null
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: return null
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                val t = w
                w = h
                h = t
            }
            if (dur <= 0 || w <= 0 || h <= 0) return null
            return Clip(uri, displayName(context, uri), dur, w, h)
        } catch (e: Exception) {
            return null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
                // abaikan
            }
        }
    }

    fun isImage(context: Context, uri: Uri): Boolean {
        val t = try {
            context.contentResolver.getType(uri)
        } catch (e: Exception) {
            null
        }
        return t != null && t.startsWith("image/")
    }

    /** Foto sebagai klip: durasi awal 5 detik, bisa diperpanjang sampai 60 detik di timeline. */
    fun probeImage(context: Context, uri: Uri): Clip? {
        return try {
            val o = android.graphics.BitmapFactory.Options()
            o.inJustDecodeBounds = true
            context.contentResolver.openInputStream(uri)?.use {
                android.graphics.BitmapFactory.decodeStream(it, null, o)
            }
            if (o.outWidth <= 0 || o.outHeight <= 0) return null
            Clip(
                uri, displayName(context, uri), 60_000L, o.outWidth, o.outHeight,
                startMs = 0L, endMs = 5_000L, isImage = true
            )
        } catch (e: Exception) {
            null
        }
    }

    /** Video atau foto, ditentukan dari jenis berkasnya. */
    fun probeMedia(context: Context, uri: Uri): Clip? =
        if (isImage(context, uri)) probeImage(context, uri) else probeVideo(context, uri)

    fun probeAudio(context: Context, uri: Uri): AudioTrack? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: return null
            if (dur <= 0) return null
            return AudioTrack(uri, displayName(context, uri), dur)
        } catch (e: Exception) {
            return null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
                // abaikan
            }
        }
    }

    fun thumbnail(context: Context, uri: Uri, timeMs: Long): Bitmap? {
        if (isImage(context, uri)) {
            LayerRenderer.init(context)
            return LayerRenderer.bitmapFor(uri)
        }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            r.getScaledFrameAtTime(
                timeMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 192, 192
            )
        } catch (e: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
                // abaikan
            }
        }
    }
}
