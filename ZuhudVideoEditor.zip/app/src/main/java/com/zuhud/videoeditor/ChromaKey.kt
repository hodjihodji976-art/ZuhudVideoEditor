package com.zuhud.videoeditor

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Menghapus warna latar dari gambar:
 *  - manual: semua piksel yang mirip warna terpilih (kunci kroma, mis. layar hijau)
 *  - otomatis: mendeteksi warna latar dari tepi gambar, lalu menghapus area latar yang tersambung ke tepi.
 */
object ChromaKey {

    fun apply(src: Bitmap, mode: Int, keyColor: Int, tol: Float, soft: Float): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val bg = if (mode == 1) detectBackground(px, w, h) else keyColor
        if (mode == 1) autoRemove(px, w, h, bg, tol, soft) else manualRemove(px, bg, tol, soft)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Jarak warna 0..1 (RGB Euclid, ternormalisasi). */
    private fun dist(c: Int, r2: Int, g2: Int, b2: Int): Float {
        val dr = ((c shr 16) and 0xFF) - r2
        val dg = ((c shr 8) and 0xFF) - g2
        val db = (c and 0xFF) - b2
        return sqrt((dr * dr + dg * dg + db * db).toFloat()) / 441.67f
    }

    private fun withAlpha(c: Int, factor: Float): Int {
        val a = ((c ushr 24) * factor.coerceIn(0f, 1f)).toInt()
        return (a shl 24) or (c and 0x00FFFFFF)
    }

    private fun manualRemove(px: IntArray, key: Int, tol: Float, soft: Float) {
        val kr = (key shr 16) and 0xFF
        val kg = (key shr 8) and 0xFF
        val kb = key and 0xFF
        val s = max(soft, 0.001f)
        for (i in px.indices) {
            val d = dist(px[i], kr, kg, kb)
            if (d <= tol) px[i] = 0
            else if (d < tol + s) px[i] = withAlpha(px[i], (d - tol) / s)
        }
    }

    /** Warna latar = warna paling sering muncul di tepi gambar. */
    private fun detectBackground(px: IntArray, w: Int, h: Int): Int {
        val count = HashMap<Int, Int>()
        val sumR = HashMap<Int, Long>()
        val sumG = HashMap<Int, Long>()
        val sumB = HashMap<Int, Long>()
        fun add(c: Int) {
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val k = ((r shr 4) shl 8) or ((g shr 4) shl 4) or (b shr 4)
            count[k] = (count[k] ?: 0) + 1
            sumR[k] = (sumR[k] ?: 0L) + r
            sumG[k] = (sumG[k] ?: 0L) + g
            sumB[k] = (sumB[k] ?: 0L) + b
        }
        for (x in 0 until w) {
            add(px[x])
            add(px[(h - 1) * w + x])
        }
        for (y in 0 until h) {
            add(px[y * w])
            add(px[y * w + w - 1])
        }
        var best = 0
        var bestN = -1
        for ((k, n) in count) if (n > bestN) {
            best = k
            bestN = n
        }
        val n = max(1, bestN).toLong()
        val r = (sumR[best] ?: 0L) / n
        val g = (sumG[best] ?: 0L) / n
        val b = (sumB[best] ?: 0L) / n
        return (0xFF shl 24) or (r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt()
    }

    private fun autoRemove(px: IntArray, w: Int, h: Int, bg: Int, tol: Float, soft: Float) {
        val br = (bg shr 16) and 0xFF
        val bgG = (bg shr 8) and 0xFF
        val bb = bg and 0xFF
        val removed = BooleanArray(w * h)
        val queue = IntArray(w * h)
        var head = 0
        var tail = 0

        fun tryPush(i: Int) {
            if (removed[i]) return
            if (dist(px[i], br, bgG, bb) <= tol) {
                removed[i] = true
                queue[tail++] = i
            }
        }
        for (x in 0 until w) {
            tryPush(x)
            tryPush((h - 1) * w + x)
        }
        for (y in 0 until h) {
            tryPush(y * w)
            tryPush(y * w + w - 1)
        }
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            if (x > 0) tryPush(i - 1)
            if (x < w - 1) tryPush(i + 1)
            if (y > 0) tryPush(i - w)
            if (y < h - 1) tryPush(i + w)
        }

        val s = max(soft, 0.001f)
        for (i in px.indices) {
            if (removed[i]) continue
            val x = i % w
            val y = i / w
            val nearRemoved = (x > 0 && removed[i - 1]) || (x < w - 1 && removed[i + 1]) ||
                (y > 0 && removed[i - w]) || (y < h - 1 && removed[i + w])
            if (nearRemoved) {
                val d = dist(px[i], br, bgG, bb)
                if (d < tol + s) px[i] = withAlpha(px[i], (d - tol) / s)
            }
        }
        for (i in px.indices) if (removed[i]) px[i] = 0
    }

    /** Dipakai untuk mengambil warna dari gambar saat memilih warna kunci. */
    fun colorDistance(a: Int, b: Int): Float =
        abs(dist(a, (b shr 16) and 0xFF, (b shr 8) and 0xFF, b and 0xFF))
}
