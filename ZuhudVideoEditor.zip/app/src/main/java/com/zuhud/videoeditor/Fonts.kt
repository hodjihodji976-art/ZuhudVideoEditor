package com.zuhud.videoeditor

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import java.io.File

/** 20 gaya huruf. Memakai keluarga font bawaan Android sehingga selalu tersedia tanpa unduhan. */
object Fonts {

    class Font(
        val name: String,
        private val family: String,
        private val style: Int,
        val caps: Boolean = false,
        val spacing: Float = 0f
    ) {
        val typeface: Typeface by lazy {
            try {
                Typeface.create(family, style)
            } catch (e: Exception) {
                Typeface.create(Typeface.DEFAULT, style)
            }
        }
    }

    val all: List<Font> = listOf(
        Font("Standar Tebal", "sans-serif", Typeface.BOLD),
        Font("Sans Tipis", "sans-serif-thin", Typeface.NORMAL),
        Font("Sans Ringan", "sans-serif-light", Typeface.NORMAL),
        Font("Sans Medium", "sans-serif-medium", Typeface.NORMAL),
        Font("Sans Hitam", "sans-serif-black", Typeface.NORMAL),
        Font("Kondensasi", "sans-serif-condensed", Typeface.BOLD),
        Font("KAPITAL LEBAR", "sans-serif-medium", Typeface.NORMAL, caps = true, spacing = 0.14f),
        Font("Serif Klasik", "serif", Typeface.NORMAL),
        Font("Serif Tebal", "serif", Typeface.BOLD),
        Font("Serif Miring", "serif", Typeface.ITALIC),
        Font("Serif Miring Tebal", "serif", Typeface.BOLD_ITALIC),
        Font("Monospace", "monospace", Typeface.BOLD),
        Font("Mesin Tik", "serif-monospace", Typeface.NORMAL),
        Font("Mono Miring", "monospace", Typeface.ITALIC),
        Font("Tulisan Tangan", "cursive", Typeface.NORMAL),
        Font("Tangan Tebal", "cursive", Typeface.BOLD),
        Font("Kasual", "casual", Typeface.NORMAL),
        Font("Kapital Kecil", "sans-serif-smallcaps", Typeface.NORMAL),
        Font("Sans Miring", "sans-serif", Typeface.ITALIC),
        Font("POSTER TEBAL", "sans-serif-black", Typeface.ITALIC, caps = true, spacing = 0.04f)
    )

    fun get(i: Int): Font = all[i.coerceIn(0, all.size - 1)]

    // ------------------------------------------------------------ font berkas

    /** Folder font buatan pengguna (butuh izin "Akses semua file" di Android 11+). */
    const val USER_DIR = "/storage/emulated/0/fonts"

    class FileFont(val name: String, val path: String)

    private val fileCache = HashMap<String, Typeface?>()
    private var systemCache: List<FileFont>? = null

    @Synchronized
    fun fromFile(path: String): Typeface? {
        if (fileCache.containsKey(path)) return fileCache[path]
        val tf = try {
            Typeface.createFromFile(File(path))
        } catch (e: Exception) {
            null
        }
        fileCache[path] = tf
        return tf
    }

    /** Typeface lapisan: font berkas bila ada, kalau tidak font bawaan. */
    fun typefaceFor(l: Layer): Typeface {
        if (l.fontFile.isNotEmpty()) fromFile(l.fontFile)?.let { return it }
        return get(l.font).typeface
    }

    private fun pretty(f: File): String =
        f.nameWithoutExtension.replace('-', ' ').replace('_', ' ').trim()

    private fun scan(dir: File, latinOnly: Boolean): List<FileFont> {
        var files: Array<File>? = null
        try {
            files = dir.listFiles { x -> x.isFile && (x.extension.equals("ttf", true) || x.extension.equals("otf", true)) }
        } catch (e: Exception) {
            files = null
        }
        if (files == null) return emptyList()
        val probe = Paint()
        val out = ArrayList<FileFont>()
        for (f in files.sortedBy { it.name.lowercase() }) {
            if (latinOnly) {
                val tf = fromFile(f.absolutePath) ?: continue
                probe.typeface = tf
                if (!probe.hasGlyph("Ag")) continue
            }
            out.add(FileFont(pretty(f), f.absolutePath))
        }
        return out
    }

    /** Font bawaan sistem Android yang punya huruf Latin (di-cache). */
    @Synchronized
    fun systemFonts(): List<FileFont> {
        systemCache?.let { return it }
        val list = scan(File("/system/fonts"), true)
        systemCache = list
        return list
    }

    private fun importedDir(ctx: Context): File {
        val d = File(ctx.filesDir, "fonts")
        if (!d.exists()) d.mkdirs()
        return d
    }

    /** Font dari /storage/emulated/0/fonts dan font yang sudah diimpor ke aplikasi. */
    fun userFonts(ctx: Context): List<FileFont> {
        val list = ArrayList<FileFont>()
        list.addAll(scan(File(USER_DIR), false))
        list.addAll(scan(importedDir(ctx), false))
        return list
    }

    fun canReadUserDir(): Boolean {
        val d = File(USER_DIR)
        return d.exists() && d.canRead() && d.listFiles() != null
    }

    /**
     * Menyalin font ke penyimpanan aplikasi agar tetap bisa dipakai (dan diekspor) walaupun izin
     * akses berkas dicabut. Mengembalikan path salinan, atau null bila font tidak valid.
     */
    fun adopt(ctx: Context, path: String): String? {
        val src = File(path)
        val dir = importedDir(ctx)
        if (src.parentFile?.absolutePath == dir.absolutePath) return path
        return try {
            val dst = File(dir, src.name)
            if (!dst.exists()) src.copyTo(dst)
            forget(dst.absolutePath)
            if (fromFile(dst.absolutePath) == null) {
                dst.delete()
                null
            } else dst.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    @Synchronized
    private fun forget(path: String) {
        fileCache.remove(path)
    }

    /** Mengimpor font dari Uri (pemilih berkas). */
    fun importUri(ctx: Context, uri: android.net.Uri, name: String): String? {
        return try {
            val clean = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val fileName = if (clean.lowercase().endsWith(".ttf") || clean.lowercase().endsWith(".otf")) clean else "$clean.ttf"
            val dst = File(importedDir(ctx), fileName)
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                dst.outputStream().use { out -> input.copyTo(out) }
            } ?: return null
            forget(dst.absolutePath)
            if (fromFile(dst.absolutePath) == null) {
                dst.delete()
                null
            } else dst.absolutePath
        } catch (e: Exception) {
            null
        }
    }
}
