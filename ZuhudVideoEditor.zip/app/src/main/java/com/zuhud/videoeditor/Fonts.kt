package com.zuhud.videoeditor

import android.graphics.Typeface

/** 20 gaya huruf. Memakai keluarga font bawaan Android sehingga selalu tersedia tanpa unduhan. */
object Fonts {

    class Font(
        val name: String,
        private val family: String,
        private val style: Int,
        val caps: Boolean = false,
        val spacing: Float = 0f
    ) {
        val typeface: Typeface by lazy {
            try {
                Typeface.create(family, style)
            } catch (e: Exception) {
                Typeface.create(Typeface.DEFAULT, style)
            }
        }
    }

    val all: List<Font> = listOf(
        Font("Standar Tebal", "sans-serif", Typeface.BOLD),
        Font("Sans Tipis", "sans-serif-thin", Typeface.NORMAL),
        Font("Sans Ringan", "sans-serif-light", Typeface.NORMAL),
        Font("Sans Medium", "sans-serif-medium", Typeface.NORMAL),
        Font("Sans Hitam", "sans-serif-black", Typeface.NORMAL),
        Font("Kondensasi", "sans-serif-condensed", Typeface.BOLD),
        Font("KAPITAL LEBAR", "sans-serif-medium", Typeface.NORMAL, caps = true, spacing = 0.14f),
        Font("Serif Klasik", "serif", Typeface.NORMAL),
        Font("Serif Tebal", "serif", Typeface.BOLD),
        Font("Serif Miring", "serif", Typeface.ITALIC),
        Font("Serif Miring Tebal", "serif", Typeface.BOLD_ITALIC),
        Font("Monospace", "monospace", Typeface.BOLD),
        Font("Mesin Tik", "serif-monospace", Typeface.NORMAL),
        Font("Mono Miring", "monospace", Typeface.ITALIC),
        Font("Tulisan Tangan", "cursive", Typeface.NORMAL),
        Font("Tangan Tebal", "cursive", Typeface.BOLD),
        Font("Kasual", "casual", Typeface.NORMAL),
        Font("Kapital Kecil", "sans-serif-smallcaps", Typeface.NORMAL),
        Font("Sans Miring", "sans-serif", Typeface.ITALIC),
        Font("POSTER TEBAL", "sans-serif-black", Typeface.ITALIC, caps = true, spacing = 0.04f)
    )

    fun get(i: Int): Font = all[i.coerceIn(0, all.size - 1)]
}
