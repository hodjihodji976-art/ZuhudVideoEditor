package com.zuhud.videoeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlin.math.max
import kotlin.math.min

/**
 * Menggambar lapisan teks/gambar ke Canvas. Dipakai bersama oleh preview dan ekspor,
 * sehingga hasil ekspor persis sama dengan yang terlihat di layar.
 */
object LayerRenderer {

    private var app: Context? = null
    private val cache = HashMap<String, Bitmap?>()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    fun init(ctx: Context) {
        app = ctx.applicationContext
    }

    class Box(val w: Float, val h: Float, val layout: StaticLayout?, val bitmap: Bitmap?)

    fun bitmapFor(uri: Uri): Bitmap? {
        val key = uri.toString()
        if (cache.containsKey(key)) return cache[key]
        val bmp = decode(uri)
        cache[key] = bmp
        return bmp
    }

    private fun decode(uri: Uri): Bitmap? {
        val ctx = app ?: return null
        return try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (e: Exception) {
            null
        }
    }

    /** Ukuran lapisan dalam piksel kanvas (cw x ch). */
    fun measure(l: Layer, cw: Float, ch: Float): Box {
        if (l.type == Layer.IMAGE) {
            val bmp = l.uri?.let { bitmapFor(it) }
            val aspect = if (bmp != null && bmp.height > 0) bmp.width.toFloat() / bmp.height else 1f
            val w = cw * 0.4f * l.scale
            return Box(w, w / aspect, null, bmp)
        }
        val size = min(cw, ch) * 0.08f * l.scale
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = size
        paint.typeface = Typeface.DEFAULT_BOLD
        val text = if (l.text.isEmpty()) " " else l.text
        val maxW = (cw * 0.92f).toInt().coerceAtLeast(10)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .build()
        var w = 0f
        for (i in 0 until layout.lineCount) w = max(w, layout.getLineWidth(i))
        return Box(w + size * 0.3f, layout.height.toFloat(), layout, null)
    }

    fun drawLayer(c: Canvas, cw: Float, ch: Float, l: Layer) {
        val box = measure(l, cw, ch)
        c.save()
        c.translate(l.cx * cw, l.cy * ch)
        c.rotate(l.rotation)
        val lay = box.layout
        if (lay != null) {
            c.translate(-lay.width / 2f, -lay.height / 2f)
            val p = lay.paint
            p.style = Paint.Style.STROKE
            p.strokeJoin = Paint.Join.ROUND
            p.strokeWidth = p.textSize * 0.14f
            p.color = 0xFF000000.toInt()
            lay.draw(c)
            p.style = Paint.Style.FILL
            p.color = l.color
            lay.draw(c)
        } else {
            val bmp = box.bitmap
            if (bmp != null) {
                val dst = RectF(-box.w / 2f, -box.h / 2f, box.w / 2f, box.h / 2f)
                c.drawBitmap(bmp, null, dst, bitmapPaint)
            }
        }
        c.restore()
    }

    fun isActive(l: Layer, timeMs: Long): Boolean = timeMs >= l.startMs && timeMs < l.startMs + l.durationMs

    fun draw(c: Canvas, cw: Float, ch: Float, layers: List<Layer>, timeMs: Long) {
        for (l in layers) {
            if (isActive(l, timeMs)) drawLayer(c, cw, ch, l)
        }
    }
}
