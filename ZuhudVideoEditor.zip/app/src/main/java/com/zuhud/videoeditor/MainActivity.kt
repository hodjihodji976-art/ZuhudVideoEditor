package com.zuhud.videoeditor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private val io = Executors.newFixedThreadPool(2)
    private lateinit var grid: GridLayout
    private lateinit var txtEmpty: TextView
    private lateinit var txtInfo: TextView

    private val pickVideos =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) createProject(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        grid = findViewById(R.id.projectGrid)
        txtEmpty = findViewById(R.id.txtEmpty)
        txtInfo = findViewById(R.id.txtInfo)

        // ruang grafiti = sepertiga tinggi layar
        val hero = findViewById<View>(R.id.hero)
        hero.layoutParams.height = (resources.displayMetrics.heightPixels * 0.34f).toInt()

        findViewById<Button>(R.id.btnNew).setOnClickListener {
            pickVideos.launch(arrayOf("video/*", "image/*"))
        }
        findViewById<Button>(R.id.btnMeta).setOnClickListener {
            startActivity(Intent(this, MetaSoundActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshProjects()
        val pending = ProjectStore.pendingAudio
        txtInfo.text = if (pending != null) "Musik siap dipakai: ${pending.name}" else ""
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdownNow()
    }

    // --------------------------------------------------------------- proyek

    private fun createProject(uris: List<Uri>) {
        Toast.makeText(this, "Memuat video…", Toast.LENGTH_SHORT).show()
        io.execute {
            val clips = uris.mapNotNull { uri ->
                MediaUtil.keepAccess(this, uri)
                MediaUtil.probeMedia(this, uri)
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (clips.isEmpty()) {
                    Toast.makeText(this, "Video/foto tidak dapat dibaca", Toast.LENGTH_LONG).show()
                } else {
                    val p = Project()
                    p.name = "Proyek " + SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date())
                    p.clips.addAll(clips)
                    ProjectStore.current = p
                    ProjectStore.save(this, p)
                    startActivity(Intent(this, EditorActivity::class.java))
                }
            }
        }
    }

    private fun refreshProjects() {
        val projects = ProjectStore.list(this)
        grid.removeAllViews()
        txtEmpty.visibility = if (projects.isEmpty()) View.VISIBLE else View.GONE

        val dm = resources.displayMetrics
        val density = dm.density
        val cols = max(2, min(5, (dm.widthPixels / density / 170f).toInt()))
        grid.columnCount = cols
        val gap = (10 * density).toInt()
        val avail = dm.widthPixels - (40 * density).toInt()
        val cardW = (avail - gap * cols * 2) / cols

        for (p in projects) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundResource(R.drawable.bg_card)
            card.setPadding(0, 0, 0, (10 * density).toInt())

            val img = ImageView(this)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setBackgroundColor(0xFF22222C.toInt())
            card.addView(img, LinearLayout.LayoutParams(cardW, (cardW * 0.62f).toInt()))

            val name = TextView(this)
            name.text = p.name.ifEmpty { "Proyek" }
            name.setTextColor(0xFFFFFFFF.toInt())
            name.textSize = 13f
            name.maxLines = 1
            name.ellipsize = android.text.TextUtils.TruncateAt.END
            name.setPadding((10 * density).toInt(), (8 * density).toInt(), (10 * density).toInt(), 0)
            card.addView(name)

            val meta = TextView(this)
            meta.text = MediaUtil.formatTime(p.totalMs) + "  ·  " + p.clips.size + " klip"
            meta.setTextColor(0xFF9A9AA8.toInt())
            meta.textSize = 11f
            meta.setPadding((10 * density).toInt(), (2 * density).toInt(), (10 * density).toInt(), 0)
            card.addView(meta)

            val lp = GridLayout.LayoutParams()
            lp.width = cardW
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            lp.setMargins(gap, gap, gap, gap)
            grid.addView(card, lp)

            val first = p.clips.first()
            val key = p.id
            img.tag = key
            io.execute {
                val bmp = MediaUtil.thumbnail(this, first.uri, first.startMs)
                if (bmp != null) {
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed && img.tag == key) img.setImageBitmap(bmp)
                    }
                }
            }

            card.setOnClickListener {
                ProjectStore.current = p
                startActivity(Intent(this, EditorActivity::class.java))
            }
            card.setOnLongClickListener {
                AlertDialog.Builder(this, R.style.ZuhudDialog)
                    .setTitle("Hapus proyek?")
                    .setMessage("“${p.name}” akan dihapus dari daftar. Video aslinya tidak ikut terhapus.")
                    .setPositiveButton("Hapus") { _, _ ->
                        ProjectStore.delete(this, p)
                        refreshProjects()
                    }
                    .setNegativeButton("Batal", null)
                    .show()
                true
            }
        }
    }
}
