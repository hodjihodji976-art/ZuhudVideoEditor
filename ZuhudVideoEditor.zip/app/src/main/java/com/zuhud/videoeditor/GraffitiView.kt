package com.zuhud.videoeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import kotlin.random.Random

/**
 * Latar dinding bata dengan tulisan besar "Zuhud" bergaya grafiti.
 * Seluruhnya digambar lewat Canvas (tanpa file gambar), dan di-cache sekali per ukuran layar.
 */
class GraffitiView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    /** 0..255, seberapa gelap lapisan peredam di atas grafiti. */
    var dimAlpha: Int = 0

    /** Posisi vertikal tengah tulisan (0..1 dari tinggi view). */
    var textCenterY: Float = 0.3f

    private var cache: Bitmap? = null

    private val pink = 0xFFFF2BD6.toInt()
    private val lime = 0xFFC6FF1A.toInt()
    private val blue = 0xFF19B4FF.toInt()

    init {
        if (attrs != null) {
            val a = context.obtainStyledAttributes(attrs, R.styleable.GraffitiView)
            dimAlpha = a.getInt(R.styleable.GraffitiView_dimAlpha, 0)
            textCenterY = a.getFloat(R.styleable.GraffitiView_textCenterY, 0.3f)
            a.recycle()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cache?.recycle()
        cache = if (w > 0 && h > 0) render(w, h) else null
    }

    override fun onDraw(canvas: Canvas) {
        cache?.let { canvas.drawBitmap(it, 0f, 0f, null) }
        if (dimAlpha > 0) {
            canvas.drawColor(Color.argb(dimAlpha.coerceIn(0, 255), 8, 8, 12))
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
    }

    private fun render(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rnd = Random(42)
        drawBricks(c, w, h, rnd)
        drawGraffiti(c, w, h, rnd)
        return bmp
    }

    private fun drawBricks(c: Canvas, w: Int, h: Int, rnd: Random) {
        c.drawColor(0xFF8C8379.toInt()) // warna semen/celah
        val colors = intArrayOf(
            0xFF8E3B2E.toInt(), 0xFF9C4636.toInt(), 0xFF7A3226.toInt(),
            0xFFA85A44.toInt(), 0xFF6E2C24.toInt(), 0xFF8A4A3A.toInt()
        )
        val bw = w / 6f
        val bh = bw / 3f
        val gap = bh * 0.12f
        val p = Paint()
        var y = 0f
        var row = 0
        while (y < h) {
            var x = if (row % 2 == 0) 0f else -bw / 2f
            while (x < w) {
                p.color = colors[rnd.nextInt(colors.size)]
                c.drawRect(x + gap, y + gap, x + bw - gap, y + bh - gap, p)
                if (rnd.nextInt(4) == 0) {
                    p.color = Color.argb(40 + rnd.nextInt(50), 255, 255, 255)
                    c.drawRect(
                        x + gap + rnd.nextFloat() * bw * 0.4f, y + gap,
                        x + bw - gap, y + bh * 0.5f, p
                    )
                }
                x += bw
            }
            y += bh
            row++
        }
        repeat(w * h / 900) {
            p.color = Color.argb(rnd.nextInt(70), 0, 0, 0)
            c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h, 1f + rnd.nextFloat() * 2f, p)
        }
    }

    private fun drawGraffiti(c: Canvas, w: Int, h: Int, rnd: Random) {
        val text = "Zuhud"
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC)
        p.textAlign = Paint.Align.CENTER
        p.textSize = 200f
        val size = 200f * (w * 0.80f / p.measureText(text))
        p.textSize = size
        val textW = p.measureText(text)
        val cx = w / 2f
        val cy = h * textCenterY
        val y = -(p.ascent() + p.descent()) / 2f

        c.save()
        c.translate(cx, cy)
        c.rotate(-6f)
        c.skew(-0.15f, 0f)

        // 1) bayangan / outline hitam tebal
        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = size * 0.16f
        p.color = Color.BLACK
        c.drawText(text, size * 0.03f, y + size * 0.04f, p)
        c.drawText(text, 0f, y, p)

        // 2) outline biru
        p.strokeWidth = size * 0.09f
        p.color = blue
        c.drawText(text, 0f, y, p)

        // 3) kilau putih di sisi kiri-atas
        p.strokeWidth = size * 0.03f
        p.color = Color.WHITE
        c.drawText(text, -size * 0.015f, y - size * 0.015f, p)

        // 4) isi gradien pink - lemon - biru
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            -textW / 2f, y - size * 0.6f, textW / 2f, y + size * 0.2f,
            intArrayOf(pink, lime, blue), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawText(text, 0f, y, p)

        // 5) kilap putih transparan di bagian atas huruf
        p.shader = LinearGradient(
            0f, y - size * 0.7f, 0f, y - size * 0.1f,
            0x66FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        c.drawText(text, 0f, y, p)
        p.shader = null

        // 6) tetesan cat
        val dripColors = intArrayOf(pink, blue, lime)
        repeat(7) {
            val dx = (rnd.nextFloat() - 0.5f) * textW * 0.85f
            val startY = y + size * 0.04f
            val len = size * (0.08f + rnd.nextFloat() * 0.30f)
            val thick = size * 0.035f
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = thick + size * 0.04f
            p.color = Color.BLACK
            c.drawLine(dx, startY, dx, startY + len, p)
            p.strokeWidth = thick
            p.color = dripColors[rnd.nextInt(dripColors.size)]
            c.drawLine(dx, startY, dx, startY + len, p)
        }
        c.restore()

        // 7) percikan cat semprot di sekitar tulisan
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        val sprayColors = intArrayOf(pink, lime, blue)
        repeat(220) {
            val gx = cx + (rnd.nextFloat() - 0.5f) * w * 0.95f
            val gy = cy + (rnd.nextFloat() - 0.5f) * size * 1.6f
            dot.color = sprayColors[rnd.nextInt(sprayColors.size)]
            dot.alpha = 110 + rnd.nextInt(110)
            c.drawCircle(gx, gy, 1.2f + rnd.nextFloat() * 2.2f, dot)
        }
    }
}
