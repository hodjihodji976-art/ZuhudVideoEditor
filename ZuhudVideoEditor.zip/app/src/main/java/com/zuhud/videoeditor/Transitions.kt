package com.zuhud.videoeditor

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.media3.common.Effect
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.common.OverlaySettings
import androidx.media3.effect.TextureOverlay
import com.google.common.collect.ImmutableList
import kotlin.math.min

/**
 * 10 transisi masuk untuk sebuah klip (animasi di awal klip). Animasi yang sama dipakai
 * di preview (lewat transformasi view) dan di ekspor (lewat efek Media3).
 */
object Transitions {

    val names = listOf(
        "Pudar hitam", "Kilatan putih", "Zoom masuk", "Zoom keluar", "Geser kiri",
        "Geser kanan", "Geser atas", "Geser bawah", "Putar", "Pop"
    )

    private const val DURATION_MS = 600L

    fun durationMs(clipMs: Long): Long = min(DURATION_MS, clipMs / 2)

    class Fx {
        var overlayAlpha = 0f
        var white = false
        var scale = 1f
        var tx = 0f   // pecahan lebar, positif = ke kanan
        var ty = 0f   // pecahan tinggi, positif = ke bawah
        var rot = 0f  // derajat
    }

    /** type 1..10, p = kemajuan 0..1. */
    fun fx(type: Int, p: Float): Fx {
        val f = Fx()
        val q = p.coerceIn(0f, 1f)
        val e = 1f - (1f - q) * (1f - q) * (1f - q)
        when (type) {
            1 -> f.overlayAlpha = 1f - q
            2 -> {
                f.overlayAlpha = 1f - q
                f.white = true
            }
            3 -> f.scale = 0.5f + 0.5f * e
            4 -> f.scale = 1.5f - 0.5f * e
            5 -> f.tx = 1f - e
            6 -> f.tx = -(1f - e)
            7 -> f.ty = 1f - e
            8 -> f.ty = -(1f - e)
            9 -> {
                f.rot = 180f * (1f - e)
                f.scale = 0.4f + 0.6f * e
            }
            10 -> f.scale = if (q < 0.6f) 1.15f * (q / 0.6f) else 1.15f - 0.15f * ((q - 0.6f) / 0.4f)
        }
        return f
    }

    /** Efek ekspor untuk klip ini (daftar kosong bila tanpa transisi). */
    fun exportEffects(c: Clip, w: Int, h: Int): List<Effect> {
        val type = c.transition
        if (type < 1 || type > names.size) return emptyList()
        val durUs = durationMs(c.effectiveMs) * 1000L
        if (durUs <= 0L) return emptyList()
        if (type <= 2) {
            return listOf(
                OverlayEffect(ImmutableList.of<TextureOverlay>(FadeOverlay(w, h, type == 2, durUs)))
            )
        }
        val aspect = w.toFloat() / h.toFloat()
        return listOf(object : MatrixTransformation {
            override fun getMatrix(presentationTimeUs: Long): Matrix {
                val m = Matrix()
                if (presentationTimeUs >= durUs) return m
                val fx = fx(type, presentationTimeUs.toFloat() / durUs.toFloat())
                m.postScale(fx.scale, fx.scale)
                if (fx.rot != 0f) {
                    m.postScale(aspect, 1f)
                    m.postRotate(fx.rot)
                    m.postScale(1f / aspect, 1f)
                }
                m.postTranslate(2f * fx.tx, -2f * fx.ty)
                return m
            }
        })
    }
}

/** Lapisan satu warna (hitam/putih) seukuran frame yang memudar dalam durUs. */
private class FadeOverlay(
    private val w: Int,
    private val h: Int,
    white: Boolean,
    private val durUs: Long
) : BitmapOverlay() {

    private val bmp: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also {
        it.eraseColor(if (white) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap = bmp

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val a = (1f - presentationTimeUs.toFloat() / durUs.toFloat()).coerceIn(0f, 1f)
        return StaticOverlaySettings.Builder().setAlphaScale(a).build()
    }
}
