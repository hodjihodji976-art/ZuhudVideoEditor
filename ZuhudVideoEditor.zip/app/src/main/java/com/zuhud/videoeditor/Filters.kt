package com.zuhud.videoeditor

import android.graphics.ColorMatrix
import androidx.media3.common.Effect
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.RgbAdjustment

/** 10 filter warna siap pakai. Parameter yang sama dipakai preview dan ekspor. */
object Filters {

    class Def(
        val name: String,
        val sat: Float = 0f,        // -1..1 (perubahan saturasi)
        val contrast: Float = 0f,   // -1..1
        val brightness: Float = 0f, // -1..1
        val r: Float = 1f,
        val g: Float = 1f,
        val b: Float = 1f
    )

    val all: List<Def> = listOf(
        Def("Hitam Putih", sat = -1f),
        Def("Vivid", sat = 0.5f, contrast = 0.15f),
        Def("Hangat", sat = 0.1f, r = 1.12f, b = 0.88f),
        Def("Dingin", r = 0.88f, b = 1.12f),
        Def("Retro", sat = -0.35f, contrast = -0.1f, r = 1.1f, b = 0.85f),
        Def("Sinematik", sat = -0.2f, contrast = 0.25f, r = 0.95f, b = 1.05f),
        Def("Pudar", sat = -0.25f, contrast = -0.25f, brightness = 0.05f),
        Def("Dramatis", sat = 0.2f, contrast = 0.4f, brightness = -0.05f),
        Def("Cerah", sat = 0.15f, brightness = 0.12f),
        Def("Noir", sat = -1f, contrast = 0.35f, brightness = -0.08f)
    )

    /** index 1..10 (0 = tanpa filter). */
    fun def(index: Int): Def? = all.getOrNull(index - 1)

    /** Matriks warna untuk preview (android.graphics.ColorMatrix). */
    fun previewMatrix(index: Int): ColorMatrix? {
        val d = def(index) ?: return null
        val m = ColorMatrix()
        m.setSaturation((1f + d.sat).coerceAtLeast(0f))
        m.postConcat(ColorMatrix(floatArrayOf(
            d.r, 0f, 0f, 0f, 0f,
            0f, d.g, 0f, 0f, 0f,
            0f, 0f, d.b, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )))
        val c = 1f + d.contrast
        val t = (1f - c) * 128f + d.brightness * 255f
        m.postConcat(ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )))
        return m
    }

    /** Efek Media3 untuk ekspor. */
    fun exportEffects(index: Int): List<Effect> {
        val d = def(index) ?: return emptyList()
        val list = ArrayList<Effect>()
        if (d.sat != 0f) {
            list.add(HslAdjustment.Builder().adjustSaturation(d.sat * 100f).build())
        }
        if (d.r != 1f || d.g != 1f || d.b != 1f) {
            list.add(
                RgbAdjustment.Builder()
                    .setRedScale(d.r)
                    .setGreenScale(d.g)
                    .setBlueScale(d.b)
                    .build()
            )
        }
        if (d.contrast != 0f) list.add(Contrast(d.contrast))
        if (d.brightness != 0f) list.add(Brightness(d.brightness))
        return list
    }
}
