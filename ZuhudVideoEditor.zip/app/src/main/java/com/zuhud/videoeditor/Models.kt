package com.zuhud.videoeditor

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Satu klip video di timeline. width/height sudah memperhitungkan rotasi. */
data class Clip(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    var startMs: Long = 0L,
    var endMs: Long = durationMs,
    var speed: Float = 1f,
    // Pangkas (crop) sebagai pecahan 0..1 dari tiap sisi.
    var cropL: Float = 0f,
    var cropT: Float = 0f,
    var cropR: Float = 0f,
    var cropB: Float = 0f
) {
    /** Durasi klip di timeline setelah dipotong dan diatur kecepatannya. */
    val effectiveMs: Long
        get() = ((endMs - startMs) / speed).toLong().coerceAtLeast(1L)

    val hasCrop: Boolean
        get() = cropL > 0.001f || cropT > 0.001f || cropR > 0.001f || cropB > 0.001f

    /** Rasio lebar/tinggi setelah dipangkas. */
    val croppedAspect: Float
        get() = (width * (1f - cropL - cropR)) / (height * (1f - cropT - cropB))
}

/** Lapisan di atas video: teks atau gambar. Posisi dalam pecahan kanvas (0..1). */
data class Layer(
    val id: Long,
    val type: Int,
    var text: String = "",
    var uri: Uri? = null,
    var color: Int = 0xFFFFFFFF.toInt(),
    var cx: Float = 0.5f,
    var cy: Float = 0.5f,
    var scale: Float = 1f,
    var rotation: Float = 0f,
    var startMs: Long = 0L,
    var durationMs: Long = 3000L
) {
    companion object {
        const val TEXT = 0
        const val IMAGE = 1
    }

    val endMs: Long get() = startMs + durationMs
}

data class AudioTrack(
    val uri: Uri,
    val name: String,
    val durationMs: Long
)

class Project(var id: String = System.currentTimeMillis().toString()) {
    var name: String = ""
    var updatedAt: Long = System.currentTimeMillis()
    val clips = mutableListOf<Clip>()
    val layers = mutableListOf<Layer>()
    var audio: AudioTrack? = null
    var muteOriginal: Boolean = false

    /** Rasio kanvas. 0/0 berarti mengikuti video pertama. */
    var aspectW: Int = 0
    var aspectH: Int = 0

    /** false = muat (ada bingkai hitam), true = penuhi kanvas (tepi terpotong). */
    var fillMode: Boolean = false

    val totalMs: Long get() = clips.sumOf { it.effectiveMs }

    fun canvasAspect(): Float {
        if (aspectW > 0 && aspectH > 0) return aspectW.toFloat() / aspectH
        val c = clips.firstOrNull() ?: return 16f / 9f
        return c.croppedAspect
    }

    fun nextLayerId(): Long {
        var id = System.currentTimeMillis()
        val max = layers.maxOfOrNull { it.id } ?: 0L
        if (id <= max) id = max + 1
        return id
    }
}

/** Konversi proyek ke/dari JSON (untuk simpan proyek dan undo/redo). */
object ProjectJson {

    fun toJson(p: Project): JSONObject {
        val o = JSONObject()
        o.put("id", p.id)
        o.put("name", p.name)
        o.put("updatedAt", p.updatedAt)
        o.put("mute", p.muteOriginal)
        o.put("aw", p.aspectW)
        o.put("ah", p.aspectH)
        o.put("fill", p.fillMode)

        val clips = JSONArray()
        for (c in p.clips) {
            val j = JSONObject()
            j.put("uri", c.uri.toString())
            j.put("name", c.name)
            j.put("dur", c.durationMs)
            j.put("w", c.width)
            j.put("h", c.height)
            j.put("s", c.startMs)
            j.put("e", c.endMs)
            j.put("sp", c.speed.toDouble())
            j.put("cl", c.cropL.toDouble())
            j.put("ct", c.cropT.toDouble())
            j.put("cr", c.cropR.toDouble())
            j.put("cb", c.cropB.toDouble())
            clips.put(j)
        }
        o.put("clips", clips)

        val layers = JSONArray()
        for (l in p.layers) {
            val j = JSONObject()
            j.put("id", l.id)
            j.put("type", l.type)
            j.put("text", l.text)
            j.put("uri", l.uri?.toString() ?: "")
            j.put("color", l.color)
            j.put("cx", l.cx.toDouble())
            j.put("cy", l.cy.toDouble())
            j.put("sc", l.scale.toDouble())
            j.put("rot", l.rotation.toDouble())
            j.put("s", l.startMs)
            j.put("d", l.durationMs)
            layers.put(j)
        }
        o.put("layers", layers)

        p.audio?.let { a ->
            val j = JSONObject()
            j.put("uri", a.uri.toString())
            j.put("name", a.name)
            j.put("dur", a.durationMs)
            o.put("audio", j)
        }
        return o
    }

    fun fromJson(o: JSONObject): Project {
        val p = Project(o.optString("id", System.currentTimeMillis().toString()))
        p.name = o.optString("name", "")
        p.updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
        p.muteOriginal = o.optBoolean("mute", false)
        p.aspectW = o.optInt("aw", 0)
        p.aspectH = o.optInt("ah", 0)
        p.fillMode = o.optBoolean("fill", false)

        val clips = o.optJSONArray("clips")
        if (clips != null) {
            for (i in 0 until clips.length()) {
                val j = clips.getJSONObject(i)
                p.clips.add(
                    Clip(
                        uri = Uri.parse(j.getString("uri")),
                        name = j.optString("name", "video"),
                        durationMs = j.getLong("dur"),
                        width = j.getInt("w"),
                        height = j.getInt("h"),
                        startMs = j.optLong("s", 0L),
                        endMs = j.optLong("e", j.getLong("dur")),
                        speed = j.optDouble("sp", 1.0).toFloat(),
                        cropL = j.optDouble("cl", 0.0).toFloat(),
                        cropT = j.optDouble("ct", 0.0).toFloat(),
                        cropR = j.optDouble("cr", 0.0).toFloat(),
                        cropB = j.optDouble("cb", 0.0).toFloat()
                    )
                )
            }
        }

        val layers = o.optJSONArray("layers")
        if (layers != null) {
            for (i in 0 until layers.length()) {
                val j = layers.getJSONObject(i)
                val u = j.optString("uri", "")
                p.layers.add(
                    Layer(
                        id = j.getLong("id"),
                        type = j.getInt("type"),
                        text = j.optString("text", ""),
                        uri = if (u.isEmpty()) null else Uri.parse(u),
                        color = j.optInt("color", 0xFFFFFFFF.toInt()),
                        cx = j.optDouble("cx", 0.5).toFloat(),
                        cy = j.optDouble("cy", 0.5).toFloat(),
                        scale = j.optDouble("sc", 1.0).toFloat(),
                        rotation = j.optDouble("rot", 0.0).toFloat(),
                        startMs = j.optLong("s", 0L),
                        durationMs = j.optLong("d", 3000L)
                    )
                )
            }
        }

        val a = o.optJSONObject("audio")
        if (a != null) {
            p.audio = AudioTrack(
                Uri.parse(a.getString("uri")),
                a.optString("name", "audio"),
                a.getLong("dur")
            )
        }
        return p
    }
}
