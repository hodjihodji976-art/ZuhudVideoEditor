package com.zuhud.videoeditor

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Proyek yang sedang dibuka, musik tertunda dari Meta Sound, dan penyimpanan proyek di perangkat. */
object ProjectStore {

    var current: Project = Project()

    /** Musik hasil unduhan Meta Sound Collection yang menunggu diimpor oleh editor. */
    var pendingAudio: AudioTrack? = null

    private fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "projects")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun save(ctx: Context, p: Project) {
        if (p.clips.isEmpty()) return
        try {
            p.updatedAt = System.currentTimeMillis()
            File(dir(ctx), "${p.id}.json").writeText(ProjectJson.toJson(p).toString())
        } catch (e: Exception) {
            // gagal menyimpan tidak boleh menghentikan editor
        }
    }

    fun list(ctx: Context): List<Project> {
        val out = ArrayList<Project>()
        val files = dir(ctx).listFiles() ?: return out
        for (f in files) {
            if (!f.name.endsWith(".json")) continue
            try {
                val p = ProjectJson.fromJson(JSONObject(f.readText()))
                if (p.clips.isNotEmpty()) out.add(p)
            } catch (e: Exception) {
                // lewati berkas rusak
            }
        }
        out.sortByDescending { it.updatedAt }
        return out
    }

    fun delete(ctx: Context, p: Project) {
        try {
            File(dir(ctx), "${p.id}.json").delete()
        } catch (e: Exception) {
            // abaikan
        }
    }
}
