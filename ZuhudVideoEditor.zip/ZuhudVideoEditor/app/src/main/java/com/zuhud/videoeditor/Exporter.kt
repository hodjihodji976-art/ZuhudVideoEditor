package com.zuhud.videoeditor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.OverlaySettings
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.util.Size
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Crop
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Mengekspor proyek menjadi MP4 memakai Media3 Transformer:
 * pangkas + potong + gabung + kecepatan + teks/gambar + musik, lalu simpan ke Movies/ZuhudVideoEditor.
 */
class Exporter(private val context: Context) {

    interface Callback {
        fun onProgress(percent: Int)
        fun onDone(uri: Uri)
        fun onError(message: String)
    }

    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var outFile: File? = null
    private var cancelled = false
    private var polling: Runnable? = null

    /**
     * @param shortSide sisi terpendek hasil (1080, 1440, 2160) atau 0 untuk Native Resolution
     *            (mengikuti sisi terpendek video pertama).
     * @param fps 0 = pertahankan FPS asli (default, gerakan paling natural). Nilai lain (30/60/120)
     *            hanya batas maksimum: tidak ada interpolasi atau frame generation, jadi tidak ada ghosting.
     * Harus dipanggil dari thread utama.
     */
    fun start(project: Project, shortSide: Int, fps: Int, cb: Callback) {
        LayerRenderer.init(context)
        val clips = project.clips.map { it.copy() }
        val layers = project.layers.map { it.copy() }
        val audio = project.audio
        val mute = project.muteOriginal
        val videoVol = project.videoVolume
        val audioVol = project.audioVolume
        val fill = project.fillMode
        if (clips.isEmpty()) {
            cb.onError("Tidak ada klip untuk diekspor")
            return
        }

        val file = File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        outFile = file
        cancelled = false

        try {
            val first = clips.first()
            val base = if (shortSide > 0) shortSide else min(first.width, first.height)
            val (outW, outH) = outputSize(project.canvasAspect(), base)
            val totalMs = clips.sumOf { it.effectiveMs }
            val layout = if (fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT

            // --- urutan video: tiap klip dipangkas lalu dipas ke ukuran kanvas ---
            val videoItems = clips.map { c ->
                val mediaItem = if (c.isImage) {
                    MediaItem.Builder()
                        .setUri(c.uri)
                        .setImageDurationMs(c.endMs - c.startMs)
                        .build()
                } else {
                    MediaItem.Builder()
                        .setUri(c.uri)
                        .setClippingConfiguration(
                            MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(c.startMs)
                                .setEndPositionMs(c.endMs)
                                .build()
                        )
                        .build()
                }

                val itemEffects = ArrayList<Effect>()
                itemEffects.addAll(Filters.exportEffects(c.filter))
                if (c.hasCrop) {
                    // Crop memakai koordinat -1..1 (kiri, kanan, bawah, atas)
                    itemEffects.add(
                        Crop(
                            -1f + 2f * c.cropL,
                            1f - 2f * c.cropR,
                            -1f + 2f * c.cropB,
                            1f - 2f * c.cropT
                        )
                    )
                }
                itemEffects.add(Presentation.createForWidthAndHeight(outW, outH, layout))
                if (c.zoom != 1f || c.panX != 0f || c.panY != 0f) {
                    itemEffects.add(zoomEffect(c.zoom, c.panX, c.panY))
                }
                itemEffects.addAll(Transitions.exportEffects(c, outW, outH))

                val audioProcs = ArrayList<AudioProcessor>()
                if (!c.isImage && !mute && videoVol != 1f) audioProcs.add(GainProcessor(videoVol))

                val b = EditedMediaItem.Builder(mediaItem)
                    .setRemoveAudio(mute)
                    .setEffects(Effects(audioProcs, itemEffects))
                // fps <= 0 berarti FPS asli. Foto tidak punya FPS asli, jadi dipakai 30.
                if (c.isImage) b.setFrameRate(if (fps > 0) fps else 30)
                else if (fps > 0) b.setFrameRate(fps)
                if (!c.isImage && c.speed != 1f) b.setSpeed(ConstantSpeed(c.speed))
                b.build()
            }
            val videoSequence = if (mute) {
                EditedMediaItemSequence.withVideoFrom(videoItems)
            } else {
                EditedMediaItemSequence.withAudioAndVideoFrom(videoItems)
            }

            // --- musik latar (diulang sampai video selesai, dipotong bila lebih panjang) ---
            val audioSequence = audio?.let { a ->
                val mb = MediaItem.Builder().setUri(a.uri)
                if (a.durationMs > totalMs) {
                    mb.setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(0)
                            .setEndPositionMs(totalMs)
                            .build()
                    )
                }
                val musicProcs = ArrayList<AudioProcessor>()
                if (audioVol != 1f) musicProcs.add(GainProcessor(audioVol))
                val item = EditedMediaItem.Builder(mb.build())
                    .setEffects(Effects(musicProcs, listOf<Effect>()))
                    .build()
                EditedMediaItemSequence.withAudioFrom(listOf(item))
                    .buildUpon()
                    .setIsLooping(true)
                    .build()
            }

            // --- layer video (PiP): tiap layer = satu urutan selebar durasi proyek ---
            // Sumber pertama yang terdaftar berada paling atas, jadi layer teratas didaftarkan lebih dulu
            // dan video utama terakhir.
            val videoLayers = layers
                .filter { it.type == Layer.VIDEO && it.uri != null && it.startMs < totalMs }
                .reversed()
            val layerSequences = ArrayList<EditedMediaItemSequence>()
            val layerSettings = ArrayList<OverlaySettings>()
            if (videoLayers.isNotEmpty()) {
                val gapUri = transparentGap()
                val layerFps = if (fps > 0) fps else guessFps(clips.firstOrNull { !it.isImage }?.uri)
                for (l in videoLayers) {
                    layerSequences.add(layerSequence(l, totalMs, outW, outH, layerFps, gapUri))
                    val box = LayerRenderer.measure(l, outW.toFloat(), outH.toFloat())
                    layerSettings.add(
                        StaticOverlaySettings.Builder()
                            .setScale(box.w / outW, box.h / outH)
                            .setOverlayFrameAnchor(0f, 0f)
                            .setBackgroundFrameAnchor(2f * l.cx - 1f, 1f - 2f * l.cy)
                            .setRotationDegrees(-l.rotation)
                            .build()
                    )
                }
            }

            // --- efek tingkat komposisi: teks/gambar/stiker ---
            val overlayLayers = layers.filter { it.type != Layer.VIDEO }
            val compEffects = ArrayList<Effect>()
            if (overlayLayers.isNotEmpty()) {
                compEffects.add(
                    OverlayEffect(
                        ImmutableList.of<TextureOverlay>(LayersOverlay(outW, outH, overlayLayers))
                    )
                )
            }

            val sequences = ArrayList<EditedMediaItemSequence>()
            sequences.addAll(layerSequences)
            sequences.add(videoSequence)
            if (audioSequence != null) sequences.add(audioSequence)
            val builder = Composition.Builder(sequences)
            if (layerSequences.isNotEmpty()) {
                builder.setVideoCompositorSettings(object : VideoCompositorSettings {
                    override fun getOutputSize(inputSizes: List<Size>): Size = Size(outW, outH)

                    override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
                        return layerSettings.getOrNull(inputId) ?: StaticOverlaySettings.Builder().build()
                    }
                })
            }
            val composition = builder
                .setEffects(Effects(listOf<AudioProcessor>(), compEffects))
                .build()

            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopPolling()
                    saveToGallery(file, cb)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    stopPolling()
                    file.delete()
                    if (!cancelled) {
                        cb.onError("${exportException.errorCodeName}: ${exportException.message}")
                    }
                }
            }

            val videoMime =
                if (max(outW, outH) > 2000) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264

            val t = Transformer.Builder(context)
                .setVideoMimeType(videoMime)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
            transformer = t
            t.start(composition, file.absolutePath)
            startPolling(t, cb)
        } catch (e: Exception) {
            file.delete()
            cb.onError(e.message ?: e.javaClass.simpleName)
        }
    }

    /** PNG transparan kecil sebagai "jeda" sebelum/sesudah layer video muncul. */
    private fun transparentGap(): Uri {
        val f = File(context.cacheDir, "zuhud_gap.png")
        if (!f.exists()) {
            val b = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)
            b.eraseColor(0x00000000)
            f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
        return Uri.fromFile(f)
    }

    private fun gapItem(gap: Uri, ms: Long, w: Int, h: Int, fps: Int): EditedMediaItem {
        val mi = MediaItem.Builder().setUri(gap).setImageDurationMs(ms).build()
        return EditedMediaItem.Builder(mi)
            .setFrameRate(fps)
            .setEffects(
                Effects(
                    listOf<AudioProcessor>(),
                    listOf<Effect>(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_STRETCH_TO_FIT))
                )
            )
            .build()
    }

    private fun layerSequence(
        l: Layer, totalMs: Long, w: Int, h: Int, fps: Int, gap: Uri
    ): EditedMediaItemSequence {
        val src = if (l.srcDurMs > 0) l.srcDurMs else l.durationMs
        val play = min(min(l.durationMs, src), totalMs - l.startMs).coerceAtLeast(1L)
        val items = ArrayList<EditedMediaItem>()
        if (l.startMs >= 40L) items.add(gapItem(gap, l.startMs, w, h, fps))

        val mb = MediaItem.Builder().setUri(l.uri!!)
        if (play < src) {
            mb.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(0)
                    .setEndPositionMs(play)
                    .build()
            )
        }
        val procs = ArrayList<AudioProcessor>()
        if (l.volume != 1f) procs.add(GainProcessor(l.volume))
        items.add(
            EditedMediaItem.Builder(mb.build())
                .setFrameRate(fps)
                .setEffects(
                    Effects(
                        procs,
                        listOf<Effect>(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_STRETCH_TO_FIT))
                    )
                )
                .build()
        )
        val rest = totalMs - l.startMs - play
        if (rest >= 40L) items.add(gapItem(gap, rest, w, h, fps))
        return EditedMediaItemSequence.withAudioAndVideoFrom(items)
    }

    /** Perkiraan FPS video sumber (dipakai menyamakan layer video dengan video utama). */
    private fun guessFps(uri: Uri?): Int {
        if (uri == null) return 30
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            val cap = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()
            val frames = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toFloatOrNull()
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toFloatOrNull()
            val v = when {
                cap != null && cap > 0f -> cap
                frames != null && dur != null && dur > 0f -> frames * 1000f / dur
                else -> 30f
            }
            v.roundToInt().coerceIn(10, 120)
        } catch (e: Exception) {
            30
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
                // abaikan
            }
        }
    }

    fun cancel() {
        cancelled = true
        stopPolling()
        try {
            transformer?.cancel()
        } catch (e: Exception) {
            // abaikan
        }
        outFile?.delete()
    }

    private fun startPolling(t: Transformer, cb: Callback) {
        val holder = ProgressHolder()
        val r = object : Runnable {
            override fun run() {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    cb.onProgress(holder.progress)
                }
                handler.postDelayed(this, 300)
            }
        }
        polling = r
        handler.post(r)
    }

    private fun stopPolling() {
        polling?.let { handler.removeCallbacks(it) }
        polling = null
    }

    /** Sisi terpendek = base, sisi lainnya mengikuti rasio kanvas. Keduanya genap. */
    private fun outputSize(aspect: Float, base: Int): Pair<Int, Int> {
        return if (aspect >= 1f) {
            even(base * aspect) to even(base.toFloat())
        } else {
            even(base.toFloat()) to even(base / aspect)
        }
    }

    private fun even(v: Float): Int = max(2, (v.roundToInt() / 2) * 2)

    /** Menyalin hasil dari cache ke galeri (Movies/ZuhudVideoEditor) di thread terpisah. */
    private fun saveToGallery(file: File, cb: Callback) {
        Thread {
            try {
                val resolver = context.contentResolver
                val name = "Zuhud_${System.currentTimeMillis()}.mp4"
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(
                        MediaStore.Video.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_MOVIES + "/ZuhudVideoEditor"
                    )
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Gagal membuat berkas di galeri")
                resolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(file).use { input -> input.copyTo(out) }
                } ?: throw IllegalStateException("Gagal menulis berkas")
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                file.delete()
                handler.post { cb.onDone(uri) }
            } catch (e: Exception) {
                file.delete()
                handler.post { cb.onError(e.message ?: "Gagal menyimpan hasil") }
            }
        }.start()
    }
}

/** Zoom dan geser klip (hasil cubit layar) terhadap bingkai keluaran. */
private fun zoomEffect(zoom: Float, panX: Float, panY: Float): Effect =
    object : MatrixTransformation {
        override fun getMatrix(presentationTimeUs: Long): Matrix {
            val m = Matrix()
            m.postScale(zoom, zoom)
            m.postTranslate(2f * panX, -2f * panY)
            return m
        }
    }

/** Mengubah volume (gain) audio PCM 16-bit. Nilai > 1 menguatkan, dibatasi agar tidak pecah. */
private class GainProcessor(private val gain: Float) : BaseAudioProcessor() {

    override fun onConfigure(
        inputAudioFormat: AudioProcessor.AudioFormat
    ): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val out = replaceOutputBuffer(inputBuffer.remaining())
        while (inputBuffer.remaining() >= 2) {
            val v = (inputBuffer.getShort() * gain).toInt().coerceIn(-32768, 32767)
            out.putShort(v.toShort())
        }
        out.flip()
    }
}

/** Kecepatan tetap untuk satu klip. */
private class ConstantSpeed(private val speed: Float) : SpeedProvider {
    override fun getSpeed(timeUs: Long): Float = speed
    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = C.TIME_UNSET
}

/**
 * Overlay seukuran frame hasil yang menggambar semua teks/gambar/stiker aktif pada waktu tertentu
 * memakai LayerRenderer yang sama dengan preview (termasuk animasi).
 */
private class LayersOverlay(
    private val w: Int,
    private val h: Int,
    private val layers: List<Layer>
) : BitmapOverlay() {

    private val empty: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    private val ring = arrayOf<Bitmap?>(null, null)
    private var ringIndex = 0
    private var lastKey: String? = null
    private var lastBitmap: Bitmap = empty

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        val active = layers.filter { LayerRenderer.isActive(it, ms) }
        if (active.isEmpty()) return empty

        val animated = active.any { LayerAnim.hasAnimation(it) }
        // Tanpa animasi: gambar ulang hanya saat daftar layer aktif berubah. Dengan animasi: tiap ~33 ms.
        val key = active.joinToString(",") { it.id.toString() } + if (animated) "@" + (ms / 33) else ""
        if (key == lastKey) return lastBitmap

        // Dua bitmap bergantian agar objeknya berbeda dan teksturnya selalu diunggah ulang.
        ringIndex = 1 - ringIndex
        var bmp = ring[ringIndex]
        if (bmp == null) {
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            ring[ringIndex] = bmp
        }
        bmp.eraseColor(0)
        val canvas = Canvas(bmp)
        for (l in active) LayerRenderer.drawLayer(canvas, w.toFloat(), h.toFloat(), l, ms)
        lastKey = key
        lastBitmap = bmp
        return bmp
    }
}
