package com.zuhud.videoeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlin.math.max
import kotlin.math.min

/**
 * Menggambar lapisan teks/gambar ke Canvas. Dipakai bersama oleh preview dan ekspor,
 * sehingga hasil ekspor persis sama dengan yang terlihat di layar.
 */
object LayerRenderer {

    private var app: Context? = null
    private val cache = HashMap<String, Bitmap?>()
    private val keyCache = HashMap<String, Bitmap>()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    fun init(ctx: Context) {
        app = ctx.applicationContext
        Fonts.init(ctx)
    }

    /** Bagian lebar/tinggi sumber yang tersisa setelah dipangkas (0.05..1). */
    fun keepW(l: Layer): Float = (1f - l.lCropL - l.lCropR).coerceIn(0.05f, 1f)

    fun keepH(l: Layer): Float = (1f - l.lCropT - l.lCropB).coerceIn(0.05f, 1f)

    class Box(val w: Float, val h: Float, val layout: StaticLayout?, val bitmap: Bitmap?)

    @Synchronized
    fun bitmapFor(uri: Uri): Bitmap? {
        val key = uri.toString()
        if (cache.containsKey(key)) return cache[key]
        val bmp = decode(uri)
        cache[key] = bmp
        return bmp
    }

    /** Gambar lapisan setelah kunci kroma / hapus latar (jika aktif). Hasilnya di-cache. */
    @Synchronized
    fun imageFor(l: Layer): Bitmap? {
        val uri = l.uri ?: return null
        val base = bitmapFor(uri) ?: return null
        if (l.keyMode == 0) return base
        val key = "$uri|${l.keyMode}|${l.keyColor}|${(l.keyTol * 100).toInt()}|${(l.keySoft * 100).toInt()}"
        keyCache[key]?.let { return it }
        val out = ChromaKey.apply(base, l.keyMode, l.keyColor, l.keyTol, l.keySoft)
        if (keyCache.size >= 6) keyCache.clear()
        keyCache[key] = out
        return out
    }

    private fun decode(uri: Uri): Bitmap? {
        val ctx = app ?: return null
        return try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (e: Exception) {
            null
        }
    }

    /** Ukuran lapisan dalam piksel kanvas (cw x ch). */
    fun measure(l: Layer, cw: Float, ch: Float): Box {
        if (l.type == Layer.STICKER && !l.text.startsWith("t:")) {
            val side = min(cw, ch) * 0.28f * l.scale
            return Box(side, side, null, null)
        }
        if (l.type == Layer.VIDEO) {
            val kw = keepW(l)
            val kh = keepH(l)
            val aspect = (if (l.srcH > 0) l.srcW.toFloat() / l.srcH else 16f / 9f) * kw / kh
            val w = cw * 0.4f * l.scale
            return Box(w, w / aspect, null, null)
        }
        if (l.type == Layer.IMAGE) {
            val bmp = imageFor(l)
            val aspect = (if (bmp != null && bmp.height > 0) bmp.width.toFloat() / bmp.height else 1f) *
                keepW(l) / keepH(l)
            val w = cw * 0.4f * l.scale
            return Box(w, w / aspect, null, bmp)
        }
        val isMemeText = l.type == Layer.STICKER
        val size = min(cw, ch) * (if (isMemeText) 0.1f else 0.08f) * l.scale
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = size
        var raw = if (isMemeText) l.text.substring(2) else l.text
        if (isMemeText) {
            paint.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            raw = raw.uppercase()
        } else {
            val f = Fonts.get(l.font)
            paint.typeface = Fonts.typefaceFor(l)
            paint.letterSpacing = l.spacing + (if (l.fontFile.isEmpty()) f.spacing else 0f)
            if (f.caps && l.fontFile.isEmpty()) raw = raw.uppercase()
        }
        paint.isFakeBoldText = l.bold
        if (l.italic) paint.textSkewX = -0.25f
        val text = if (raw.isEmpty()) " " else raw
        val maxW = (cw * 0.92f).toInt().coerceAtLeast(10)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .build()
        var w = 0f
        for (i in 0 until layout.lineCount) w = max(w, layout.getLineWidth(i))
        return Box(w + size * 0.3f, layout.height.toFloat(), layout, null)
    }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** timeMs < 0 = tanpa animasi. */
    fun drawLayer(c: Canvas, cw: Float, ch: Float, l: Layer, timeMs: Long = -1L) {
        val box = measure(l, cw, ch)
        val a = if (timeMs >= 0 && l.type != Layer.VIDEO) LayerAnim.compute(l, timeMs) else LayerAnim.NONE
        val alpha = (l.opacity * a.alpha).coerceIn(0f, 1f)
        if (alpha <= 0.003f) return

        c.save()
        c.translate((l.cx + a.tx) * cw, (l.cy + a.ty) * ch)
        c.rotate(l.rotation + a.rot)
        if (a.scale != 1f) c.scale(a.scale, a.scale)
        val grouped = alpha < 0.999f
        if (grouped) {
            c.saveLayerAlpha(RectF(-cw, -ch, cw, ch), (alpha * 255f).toInt())
        }

        val lay = box.layout
        if (lay != null) {
            drawText(c, lay, box, l, a)
        } else {
            val bmp = box.bitmap
            if (l.type == Layer.STICKER) {
                Stickers.draw(c, l.text, box.w, l.color)
            } else if (bmp != null) {
                val dst = RectF(-box.w / 2f, -box.h / 2f, box.w / 2f, box.h / 2f)
                val src = if (l.lCropL > 0f || l.lCropT > 0f || l.lCropR > 0f || l.lCropB > 0f) {
                    android.graphics.Rect(
                        (l.lCropL * bmp.width).toInt(), (l.lCropT * bmp.height).toInt(),
                        (bmp.width - l.lCropR * bmp.width).toInt(), (bmp.height - l.lCropB * bmp.height).toInt()
                    )
                } else null
                c.drawBitmap(bmp, src, dst, bitmapPaint)
            }
        }
        if (grouped) c.restore()
        c.restore()
    }

    private fun drawText(c: Canvas, full: StaticLayout, box: Box, l: Layer, a: LayerAnim.Fx) {
        val size = full.paint.textSize
        c.translate(-full.width / 2f, -full.height / 2f)

        // Latar belakang teks
        if (l.bgAlpha > 0.01f) {
            val pad = size * 0.2f
            bgPaint.color = l.bgColor
            bgPaint.alpha = (l.bgAlpha.coerceIn(0f, 1f) * 255f).toInt()
            val left = (full.width - box.w) / 2f - pad
            val right = (full.width + box.w) / 2f + pad
            c.drawRoundRect(RectF(left, -pad * 0.4f, right, full.height + pad * 0.4f), size * 0.25f, size * 0.25f, bgPaint)
        }

        // Mesin tik: huruf yang belum muncul dibuat transparan.
        var lay = full
        if (a.chars < 0.999f) {
            val txt = full.text
            val visible = (txt.length * a.chars).toInt().coerceIn(0, txt.length)
            val sp = android.text.SpannableString(txt)
            if (visible < txt.length) {
                sp.setSpan(
                    android.text.style.ForegroundColorSpan(0x00000000),
                    visible, txt.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            lay = StaticLayout.Builder.obtain(sp, 0, sp.length, TextPaint(full.paint), full.width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .build()
        }

        val p = lay.paint
        p.strokeJoin = Paint.Join.ROUND
        val strokeW = size * l.strokeW

        fun fill(color: Int, shader: Boolean) {
            p.style = Paint.Style.FILL
            p.color = color
            p.shader = if (shader && l.gradOn) {
                android.graphics.LinearGradient(
                    0f, 0f, 0f, lay.height.toFloat(), l.color, l.gradColor, android.graphics.Shader.TileMode.CLAMP
                )
            } else null
            lay.draw(c)
            p.shader = null
        }

        fun stroke(color: Int, width: Float) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = width
            p.color = color
            lay.draw(c)
        }

        // 3D / timbul: salinan bergeser di belakang teks
        if (l.extrude > 0) {
            val step = size * 0.03f
            for (i in l.extrude downTo 1) {
                c.save()
                c.translate(i * step, i * step)
                if (strokeW > 0f) stroke(l.strokeColor, strokeW)
                fill(l.strokeColor, false)
                c.restore()
            }
        }

        // Glitch: salinan merah dan cyan bergeser
        if (l.glitch) {
            val off = size * 0.05f
            c.save()
            c.translate(-off, 0f)
            fill(0xCCFF0040.toInt(), false)
            c.restore()
            c.save()
            c.translate(off, 0f)
            fill(0xCC00E5FF.toInt(), false)
            c.restore()
        }

        // Cahaya (neon)
        if (l.glowR > 0.001f) {
            p.setShadowLayer(size * l.glowR, 0f, 0f, l.glowColor)
            fill(l.color, true)
            fill(l.color, true)
            p.clearShadowLayer()
        }

        // Bayangan
        if (l.shadow) {
            p.setShadowLayer(size * 0.12f, size * 0.07f, size * 0.07f, l.shadowColor)
            if (strokeW > 0f) stroke(l.strokeColor, strokeW) else fill(l.color, true)
            p.clearShadowLayer()
        }

        if (strokeW > 0f) stroke(l.strokeColor, strokeW)
        fill(l.color, true)
    }

    fun isActive(l: Layer, timeMs: Long): Boolean = timeMs >= l.startMs && timeMs < l.startMs + l.durationMs

    fun draw(c: Canvas, cw: Float, ch: Float, layers: List<Layer>, timeMs: Long) {
        for (l in layers) {
            if (isActive(l, timeMs)) drawLayer(c, cw, ch, l, timeMs)
        }
    }
}
