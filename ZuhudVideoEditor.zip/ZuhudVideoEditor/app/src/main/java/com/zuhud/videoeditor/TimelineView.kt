package com.zuhud.videoeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Timeline ala CapCut: garis putar tetap di tengah, timeline digeser.
 * Klip dipotong dengan menarik pinggirnya; teks/gambar/audio punya baris sendiri.
 */
class TimelineView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        const val NONE = 0
        const val CLIP = 1
        const val LAYER = 2
        const val AUDIO = 3
        const val FX = 4
        private const val MIN_CLIP_MS = 300L
    }

    interface Listener {
        /** Pengguna menggeser timeline: pindahkan posisi putar. */
        fun onScrub(ms: Long)

        fun onSelect(kind: Int, id: Long)

        /** Sebelum pengubahan (untuk undo). */
        fun onBeginEdit()

        /** Pengubahan sedang berlangsung (tarik pinggir/geser). */
        fun onEditing()

        /** Pengubahan selesai. */
        fun onEndEdit(clipChanged: Boolean)

        fun onAdd()

        /** Klip dipindah urutannya dengan tap-tahan lalu seret. */
        fun onMoveClip(from: Int, to: Int) {}
    }

    var listener: Listener? = null

    /** Posisi putar dalam ms. */
    var timeMs: Long = 0L
        private set

    var selKind: Int = NONE
        private set
    var selId: Long = -1L
        private set

    /** Thumbnail per klip, kunci = uri. */
    val thumbs = HashMap<String, Bitmap>()

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    // piksel per milidetik
    private var ppm = 0.04f * density

    private val project: Project get() = ProjectStore.current

    private val rulerH = dp(26f)
    private val videoH = dp(54f)
    private val rowH = dp(30f)
    private val rowGap = dp(6f)
    private val handleW = dp(14f)

    private val bgPaint = Paint().apply { color = 0xFF121218.toInt() }
    private val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFFFFFF.toInt()
        strokeWidth = dp(2f)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textSize = dp(11f)
    }
    private val rulerText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8D8D9B.toInt()
        textSize = dp(10f)
    }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF55556A.toInt()
        strokeWidth = 1f
    }
    private val headPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        strokeWidth = dp(2f)
    }
    private val whitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val gripPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF14141C.toInt()
        strokeWidth = dp(2f)
        strokeCap = Paint.Cap.ROUND
    }

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                ppm = (ppm * d.scaleFactor).coerceIn(0.006f * density, 0.3f * density)
                invalidate()
                return true
            }
        })

    private enum class Mode { NONE, SCROLL, PENDING_TAP, PENDING_LAYER, MOVE_LAYER, DRAG_CLIP, TRIM_L, TRIM_R, ADD }

    private class Hit(val kind: Int, val id: Long, val part: Int) // part: 0 isi, 1 kiri, 2 kanan

    private var mode = Mode.NONE
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var downTime = 0L
    private var pending: Hit? = null

    // seret-urut klip (tap dan tahan)
    private var dragIdx = -1
    private var dragOffX = 0f
    private var dragX = 0f
    private val longPress = Runnable {
        val hit = pending
        if (mode == Mode.PENDING_TAP && !moved && hit != null && hit.kind == CLIP &&
            hit.part == 0 && project.clips.size > 1) {
            mode = Mode.DRAG_CLIP
            dragIdx = hit.id.toInt()
            dragOffX = downX - clipRect(dragIdx).left
            dragX = downX
            if (selKind != CLIP || selId != hit.id) select(CLIP, hit.id)
            parent?.requestDisallowInterceptTouchEvent(true)
            performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
            invalidate()
        }
    }

    // mode urut: semua klip mengecil jadi kotak kecil sama besar (seperti CapCut)
    private fun tileW(): Float {
        val n = max(1, project.clips.size)
        return min(dp(76f), (width - dp(32f) - (n - 1) * dp(8f)) / n).coerceAtLeast(dp(28f))
    }

    private fun tileLeft0(): Float {
        val n = project.clips.size
        val total = n * tileW() + (n - 1) * dp(8f)
        return max(dp(8f), (width - total) / 2f)
    }

    private fun tileRect(slot: Int): RectF {
        val l = tileLeft0() + slot * (tileW() + dp(8f))
        return RectF(l, videoTop(), l + tileW(), videoTop() + videoH)
    }

    private fun dragTarget(): Int {
        val n = project.clips.size
        val t = Math.round((dragX - tileLeft0() - tileW() / 2f) / (tileW() + dp(8f)))
        return t.coerceIn(0, n - 1)
    }

    // nilai awal saat mulai tarik
    private var o1 = 0L
    private var o2 = 0L
    private var oSpeed = 1f

    // ------------------------------------------------------------- koordinat

    private fun xOf(ms: Long): Float = width / 2f + (ms - timeMs) * ppm

    private fun videoTop(): Float = rulerH + dp(6f)

    private fun audioTop(): Float = videoTop() + videoH + dp(8f)

    private fun layersTop(): Float =
        if (project.audio != null) audioTop() + rowH + rowGap else audioTop()

    private fun clipStartMs(index: Int): Long {
        var s = 0L
        for (i in 0 until index) s += project.clips[i].effectiveMs
        return s
    }

    private fun clipRect(index: Int): RectF {
        val s = clipStartMs(index)
        val e = s + project.clips[index].effectiveMs
        return RectF(xOf(s) + 1f, videoTop(), xOf(e) - 1f, videoTop() + videoH)
    }

    private fun layerRows(): IntArray {
        val ls = project.layers
        val rows = IntArray(ls.size)
        val ends = ArrayList<Long>()
        val order = ls.indices.sortedBy { ls[it].startMs }
        for (i in order) {
            var r = ends.indexOfFirst { it <= ls[i].startMs }
            if (r < 0) {
                ends.add(0L)
                r = ends.size - 1
            }
            ends[r] = ls[i].startMs + ls[i].durationMs
            rows[i] = r
        }
        return rows
    }

    private fun layerRect(index: Int, rows: IntArray): RectF {
        val l = project.layers[index]
        val top = layersTop() + rows[index] * (rowH + rowGap)
        return RectF(xOf(l.startMs), top, xOf(l.endMs), top + rowH)
    }

    private fun layerRowCount(): Int = (layerRows().maxOrNull() ?: -1) + 1

    private fun fxTop(): Float = layersTop() + layerRowCount() * (rowH + rowGap)

    private fun fxRows(): IntArray {
        val ls = project.fx
        val rows = IntArray(ls.size)
        val ends = ArrayList<Long>()
        val order = ls.indices.sortedBy { ls[it].startMs }
        for (i in order) {
            var r = ends.indexOfFirst { it <= ls[i].startMs }
            if (r < 0) {
                ends.add(0L)
                r = ends.size - 1
            }
            ends[r] = ls[i].startMs + ls[i].durationMs
            rows[i] = r
        }
        return rows
    }

    private fun fxRect(index: Int, rows: IntArray): RectF {
        val f = project.fx[index]
        val top = fxTop() + rows[index] * (rowH + rowGap)
        return RectF(xOf(f.startMs), top, xOf(f.endMs), top + rowH)
    }

    private fun audioRect(): RectF? {
        val a = project.audio ?: return null
        val len = min(a.durationMs, project.totalMs)
        return RectF(xOf(0), audioTop(), xOf(len), audioTop() + rowH)
    }

    private fun addRect(): RectF {
        val left = xOf(project.totalMs) + dp(8f)
        return RectF(left, videoTop() + dp(6f), left + dp(42f), videoTop() + videoH - dp(6f))
    }

    // ------------------------------------------------------------- publik

    fun setTime(ms: Long) {
        timeMs = ms.coerceIn(0L, max(0L, project.totalMs))
        invalidate()
    }

    fun select(kind: Int, id: Long) {
        selKind = kind
        selId = id
        invalidate()
        listener?.onSelect(kind, id)
    }

    /** Dipanggil setelah struktur proyek berubah. */
    fun refresh() {
        // pilihan klip yang sudah tidak ada dibatalkan
        if (selKind == CLIP && (selId < 0 || selId >= project.clips.size)) {
            selKind = NONE
            selId = -1L
        }
        if (selKind == LAYER && project.layers.none { it.id == selId }) {
            selKind = NONE
            selId = -1L
        }
        if (selKind == FX && project.fx.none { it.id == selId }) {
            selKind = NONE
            selId = -1L
        }
        if (selKind == AUDIO && project.audio == null) {
            selKind = NONE
            selId = -1L
        }
        timeMs = timeMs.coerceIn(0L, max(0L, project.totalMs))
        requestLayout()
        invalidate()
    }

    // ------------------------------------------------------------- ukuran

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val rows = layerRows()
        val n = (rows.maxOrNull() ?: -1) + 1
        val fxn = (fxRows().maxOrNull() ?: -1) + 1
        val content = layersTop() + (n + fxn) * (rowH + rowGap) + dp(24f)
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, max(content, dp(170f)).toInt())
    }

    // ------------------------------------------------------------- gambar

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        if (mode == Mode.DRAG_CLIP && dragIdx in project.clips.indices) {
            drawReorder(canvas, w)
            return
        }
        drawRuler(canvas, w)
        drawClips(canvas, w)

        val ar = audioRect()
        if (ar != null) {
            val a = project.audio!!
            val selected = selKind == AUDIO
            drawChip(canvas, ar, 0xFF4B6EF5.toInt(), "♪  " + a.name, selected, false)
        }

        val rows = layerRows()
        for (i in project.layers.indices) {
            val l = project.layers[i]
            val r = layerRect(i, rows)
            if (r.right < 0f || r.left > w) continue
            val color = when (l.type) {
                Layer.TEXT -> 0xFF2E9E6B.toInt()
                Layer.STICKER -> 0xFFE0833A.toInt()
                Layer.VIDEO -> 0xFF3B7BFF.toInt()
                else -> 0xFFB45FD6.toInt()
            }
            val label = when (l.type) {
                Layer.TEXT -> "T  " + l.text
                Layer.STICKER -> if (l.text.startsWith("t:")) "★  " + l.text.substring(2) else "★  Stiker"
                Layer.VIDEO -> "▶  Video"
                else -> "▣  Gambar"
            }
            val selected = selKind == LAYER && selId == l.id
            drawChip(canvas, r, color, label, selected, true)
        }

        val frows = fxRows()
        for (i in project.fx.indices) {
            val f = project.fx[i]
            val r = fxRect(i, frows)
            if (r.right < 0f || r.left > w) continue
            val selected = selKind == FX && selId == f.id
            drawChip(canvas, r, 0xFF7A4DFF.toInt(), "✦  " + Fx.name(f.type), selected, true)
        }

        // garis putar di tengah
        val cx = w / 2f
        canvas.drawLine(cx, rulerH - dp(4f), cx, h, headPaint)
        val tri = Path()
        tri.moveTo(cx - dp(6f), rulerH - dp(10f))
        tri.lineTo(cx + dp(6f), rulerH - dp(10f))
        tri.lineTo(cx, rulerH - dp(2f))
        tri.close()
        canvas.drawPath(tri, whitePaint)
    }

    private fun drawRuler(canvas: Canvas, w: Float) {
        val steps = longArrayOf(1000, 2000, 5000, 10000, 15000, 30000, 60000, 120000, 300000)
        var step = steps[steps.size - 1]
        for (s in steps) {
            if (s * ppm >= dp(72f)) {
                step = s
                break
            }
        }
        val startMs = max(0L, timeMs - (w / 2f / ppm).toLong() - step)
        val endMs = timeMs + (w / 2f / ppm).toLong() + step
        var t = (startMs / step) * step
        while (t <= endMs) {
            val x = xOf(t)
            canvas.drawLine(x, rulerH - dp(8f), x, rulerH, tickPaint)
            canvas.drawText(MediaUtil.formatTime(t), x + dp(3f), rulerH - dp(10f), rulerText)
            val mid = xOf(t + step / 2)
            canvas.drawCircle(mid, rulerH - dp(3f), dp(1.2f), tickPaint)
            t += step
        }
    }

    private fun drawClips(canvas: Canvas, w: Float) {
        val clips = project.clips
        for (i in clips.indices) drawOneClip(canvas, i, w)

        // tombol tambah klip di ujung
        val ar = addRect()
        if (ar.right > 0f && ar.left < w) {
            canvas.drawRoundRect(ar, dp(8f), dp(8f), whitePaint)
            val cx = ar.centerX()
            val cy = ar.centerY()
            val d = dp(8f)
            canvas.drawLine(cx - d, cy, cx + d, cy, gripPaint)
            canvas.drawLine(cx, cy - d, cx, cy + d, gripPaint)
        }
    }

    private fun drawReorder(canvas: Canvas, w: Float) {
        val clips = project.clips
        val t = dragTarget()
        var j = 0
        for (i in clips.indices) {
            if (i == dragIdx) continue
            val slot = if (j < t) j else j + 1
            j++
            drawOneClip(canvas, i, w, tileRect(slot), true)
        }
        val base = tileRect(0)
        val r = RectF(dragX - tileW() / 2f, base.top - dp(6f), dragX + tileW() / 2f, base.bottom - dp(6f))
        // bayangan penanda slot tujuan
        val slot = tileRect(t)
        chipPaint.color = 0x33FFFFFF
        canvas.drawRoundRect(slot, dp(6f), dp(6f), chipPaint)
        drawOneClip(canvas, dragIdx, w, r, true)
        rulerText.textAlign = Paint.Align.CENTER
        canvas.drawText("Seret untuk mengurutkan", w / 2f, base.bottom + dp(28f), rulerText)
        rulerText.textAlign = Paint.Align.LEFT
    }

    private fun drawOneClip(canvas: Canvas, i: Int, w: Float,
                            rect: RectF? = null, compact: Boolean = false) {
        val clips = project.clips
        run {
            val c = clips[i]
            val r = rect ?: clipRect(i)
            if (r.right < 0f || r.left > w) return
            chipPaint.color = 0xFF2A2A36.toInt()
            canvas.drawRoundRect(r, dp(6f), dp(6f), chipPaint)

            val th = thumbs[c.uri.toString()]
            canvas.save()
            canvas.clipRect(r)
            if (th != null && th.height > 0) {
                val tileW = videoH * th.width / th.height
                var x = r.left
                while (x < r.right) {
                    if (x + tileW > 0f && x < w) {
                        canvas.drawBitmap(th, null, RectF(x, r.top, x + tileW, r.bottom), null)
                    }
                    x += tileW
                }
            }
            textPaint.setShadowLayer(dp(3f), 0f, 0f, 0xFF000000.toInt())
            val label = MediaUtil.formatSeconds(c.effectiveMs) + "s" +
                (if (c.speed != 1f) "  ${c.speed}x" else "") +
                (if (c.hasCrop) "  ▣" else "")
            canvas.drawText(label, r.left + dp(6f), r.top + dp(14f), textPaint)
            textPaint.clearShadowLayer()
            canvas.restore()

            if (selKind == CLIP && selId == i.toLong() && !compact) {
                canvas.drawRoundRect(r, dp(6f), dp(6f), strokePaint)
                drawHandle(canvas, r.left, r.top, r.bottom, true)
                drawHandle(canvas, r.right, r.top, r.bottom, false)
            } else if (compact && i == dragIdx) {
                canvas.drawRoundRect(r, dp(6f), dp(6f), strokePaint)
            }
        }
    }

    private fun drawChip(canvas: Canvas, r: RectF, color: Int, label: String, selected: Boolean, trim: Boolean) {
        if (r.right < 0f || r.left > width) return
        chipPaint.color = color
        canvas.drawRoundRect(r, dp(6f), dp(6f), chipPaint)
        canvas.save()
        canvas.clipRect(r)
        canvas.drawText(label, r.left + dp(10f), r.centerY() + dp(4f), textPaint)
        canvas.restore()
        if (selected) {
            canvas.drawRoundRect(r, dp(6f), dp(6f), strokePaint)
            if (trim) {
                drawHandle(canvas, r.left, r.top, r.bottom, true)
                drawHandle(canvas, r.right, r.top, r.bottom, false)
            }
        }
    }

    /** Pegangan putih di pinggir klip terpilih (tarik untuk memotong). */
    private fun drawHandle(canvas: Canvas, x: Float, top: Float, bottom: Float, leftSide: Boolean) {
        val r = if (leftSide) RectF(x - handleW, top, x, bottom) else RectF(x, top, x + handleW, bottom)
        canvas.drawRoundRect(r, dp(5f), dp(5f), whitePaint)
        val cx = r.centerX()
        val cy = r.centerY()
        canvas.drawLine(cx, cy - dp(7f), cx, cy + dp(7f), gripPaint)
    }

    // ------------------------------------------------------------- sentuhan

    private fun hitTest(x: Float, y: Float): Hit? {
        val ext = dp(14f)

        // pegangan item terpilih diperiksa lebih dulu
        if (selKind == CLIP && selId >= 0 && selId < project.clips.size) {
            val r = clipRect(selId.toInt())
            if (y >= r.top - ext && y <= r.bottom + ext) {
                if (x >= r.left - handleW - ext && x <= r.left + dp(6f)) return Hit(CLIP, selId, 1)
                if (x >= r.right - dp(6f) && x <= r.right + handleW + ext) return Hit(CLIP, selId, 2)
            }
        }
        if (selKind == LAYER) {
            val rows = layerRows()
            val idx = project.layers.indexOfFirst { it.id == selId }
            if (idx >= 0) {
                val r = layerRect(idx, rows)
                if (y >= r.top - ext && y <= r.bottom + ext) {
                    if (x >= r.left - handleW - ext && x <= r.left + dp(6f)) return Hit(LAYER, selId, 1)
                    if (x >= r.right - dp(6f) && x <= r.right + handleW + ext) return Hit(LAYER, selId, 2)
                }
            }
        }

        if (selKind == FX) {
            val frows = fxRows()
            val idx = project.fx.indexOfFirst { it.id == selId }
            if (idx >= 0) {
                val r = fxRect(idx, frows)
                if (y >= r.top - ext && y <= r.bottom + ext) {
                    if (x >= r.left - handleW - ext && x <= r.left + dp(6f)) return Hit(FX, selId, 1)
                    if (x >= r.right - dp(6f) && x <= r.right + handleW + ext) return Hit(FX, selId, 2)
                }
            }
        }

        if (addRect().contains(x, y)) return Hit(-1, -1, 0)

        val rows = layerRows()
        for (i in project.layers.indices.reversed()) {
            if (layerRect(i, rows).contains(x, y)) return Hit(LAYER, project.layers[i].id, 0)
        }
        val frows2 = fxRows()
        for (i in project.fx.indices.reversed()) {
            if (fxRect(i, frows2).contains(x, y)) return Hit(FX, project.fx[i].id, 0)
        }
        audioRect()?.let { if (it.contains(x, y)) return Hit(AUDIO, 0, 0) }
        for (i in project.clips.indices) {
            if (clipRect(i).contains(x, y)) return Hit(CLIP, i.toLong(), 0)
        }
        return null
    }

    private fun scrubTo(ms: Long) {
        timeMs = ms.coerceIn(0L, max(0L, project.totalMs))
        invalidate()
        listener?.onScrub(timeMs)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        if (scaleDetector.isInProgress) {
            mode = Mode.NONE
            return true
        }
        val slop = dp(6f)

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                moved = false
                downTime = timeMs
                pending = null
                val hit = hitTest(e.x, e.y)
                when {
                    hit == null -> mode = Mode.SCROLL
                    hit.kind == -1 -> mode = Mode.ADD
                    hit.part == 1 || hit.part == 2 -> {
                        parent?.requestDisallowInterceptTouchEvent(true)
                        listener?.onBeginEdit()
                        mode = if (hit.part == 1) Mode.TRIM_L else Mode.TRIM_R
                        pending = hit
                        if (hit.kind == CLIP) {
                            val c = project.clips[hit.id.toInt()]
                            o1 = c.startMs
                            o2 = c.endMs
                            oSpeed = c.speed
                        } else if (hit.kind == FX) {
                            val f = project.fx.first { it.id == hit.id }
                            o1 = f.startMs
                            o2 = f.durationMs
                        } else {
                            val l = project.layers.first { it.id == hit.id }
                            o1 = l.startMs
                            o2 = l.durationMs
                        }
                    }
                    hit.kind == LAYER || hit.kind == FX -> {
                        mode = Mode.PENDING_LAYER
                        pending = hit
                    }
                    else -> {
                        mode = Mode.PENDING_TAP
                        pending = hit
                        if (hit.kind == CLIP) postDelayed(longPress,
                            android.view.ViewConfiguration.getLongPressTimeout().toLong())
                    }
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX
                val dy = e.y - downY
                if (mode == Mode.DRAG_CLIP) {
                    dragX = e.x
                    invalidate()
                    return true
                }
                if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                    removeCallbacks(longPress)
                    moved = true
                    if (abs(dx) > abs(dy)) parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (!moved) return true
                val dMs = (dx / ppm).toLong()

                when (mode) {
                    Mode.SCROLL, Mode.PENDING_TAP -> {
                        mode = Mode.SCROLL
                        scrubTo(downTime - dMs)
                    }
                    Mode.PENDING_LAYER -> {
                        val hit = pending
                        if (hit != null) {
                            if (selKind != hit.kind || selId != hit.id) select(hit.kind, hit.id)
                            o1 = if (hit.kind == FX) project.fx.first { it.id == hit.id }.startMs
                            else project.layers.first { it.id == hit.id }.startMs
                            listener?.onBeginEdit()
                            mode = Mode.MOVE_LAYER
                            parent?.requestDisallowInterceptTouchEvent(true)
                        }
                    }
                    Mode.MOVE_LAYER -> {
                        val hit = pending
                        if (hit != null) {
                            val maxStart = max(0L, project.totalMs - MIN_CLIP_MS)
                            val ns = (o1 + dMs).coerceIn(0L, maxStart)
                            if (hit.kind == FX) {
                                project.fx.first { it.id == hit.id }.startMs = ns
                            } else {
                                project.layers.first { it.id == hit.id }.startMs = ns
                            }
                            requestLayout()
                            invalidate()
                            listener?.onEditing()
                        }
                    }
                    Mode.TRIM_L -> trimLeft(dMs)
                    Mode.TRIM_R -> trimRight(dMs)
                    else -> {}
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                val hit = pending
                removeCallbacks(longPress)
                when (mode) {
                    Mode.DRAG_CLIP -> {
                        val from = dragIdx
                        val to = dragTarget()
                        dragIdx = -1
                        mode = Mode.NONE
                        invalidate()
                        if (from != to) listener?.onMoveClip(from, to)
                    }
                    Mode.ADD -> if (!moved) listener?.onAdd()
                    Mode.SCROLL -> if (!moved) select(NONE, -1L)
                    Mode.PENDING_TAP, Mode.PENDING_LAYER -> if (!moved && hit != null) select(hit.kind, hit.id)
                    Mode.MOVE_LAYER -> {
                        requestLayout()
                        listener?.onEndEdit(false)
                    }
                    Mode.TRIM_L, Mode.TRIM_R -> {
                        requestLayout()
                        listener?.onEndEdit(hit?.kind == CLIP)
                    }
                    else -> {}
                }
                mode = Mode.NONE
                pending = null
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                dragIdx = -1
                if (mode == Mode.TRIM_L || mode == Mode.TRIM_R || mode == Mode.MOVE_LAYER) {
                    listener?.onEndEdit(pending?.kind == CLIP)
                }
                mode = Mode.NONE
                pending = null
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    /**
     * Tarik pinggir kiri. Pinggir kanan klip tetap di layar, pinggir kiri mengikuti jari
     * (timeline ikut bergeser), seperti di CapCut.
     */
    private fun trimLeft(dMs: Long) {
        val hit = pending ?: return
        if (hit.kind == CLIP) {
            val c = project.clips[hit.id.toInt()]
            val minSrc = (MIN_CLIP_MS * oSpeed).toLong()
            val newStart = (o1 + (dMs * oSpeed).toLong()).coerceIn(0L, max(0L, o2 - minSrc))
            c.startMs = newStart
            val dTl = ((newStart - o1) / oSpeed).toLong()
            timeMs = (downTime - dTl).coerceIn(0L, max(0L, project.totalMs))
        } else if (hit.kind == FX) {
            val f = project.fx.first { it.id == hit.id }
            val end = o1 + o2
            val newStart = (o1 + dMs).coerceIn(0L, end - MIN_CLIP_MS)
            f.startMs = newStart
            f.durationMs = end - newStart
        } else {
            val l = project.layers.first { it.id == hit.id }
            val end = o1 + o2
            val newStart = (o1 + dMs).coerceIn(0L, end - MIN_CLIP_MS)
            l.startMs = newStart
            l.durationMs = end - newStart
        }
        requestLayout()
        invalidate()
        listener?.onEditing()
    }

    private fun trimRight(dMs: Long) {
        val hit = pending ?: return
        if (hit.kind == CLIP) {
            val c = project.clips[hit.id.toInt()]
            val minSrc = (MIN_CLIP_MS * oSpeed).toLong()
            c.endMs = (o2 + (dMs * oSpeed).toLong()).coerceIn(c.startMs + minSrc, c.durationMs)
        } else if (hit.kind == FX) {
            val f = project.fx.first { it.id == hit.id }
            val maxDur = max(MIN_CLIP_MS, project.totalMs - f.startMs)
            f.durationMs = (o2 + dMs).coerceIn(MIN_CLIP_MS, maxDur)
        } else {
            val l = project.layers.first { it.id == hit.id }
            val maxDur = max(MIN_CLIP_MS, project.totalMs - l.startMs)
            l.durationMs = (o2 + dMs).coerceIn(MIN_CLIP_MS, maxDur)
        }
        requestLayout()
        invalidate()
        listener?.onEditing()
    }
}
