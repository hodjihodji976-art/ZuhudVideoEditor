package com.zuhud.videoeditor

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * Alat audio: efek suara bawaan (disintesis, tanpa berkas aset), ekstrak audio dari video,
 * teks ke audio (TextToSpeech Android), dan WAV hening untuk jeda saat ekspor.
 */
object AudioTools {

    private const val RATE = 44100

    class Sfx(val name: String, val gen: () -> ShortArray)

    private fun dir(context: Context, name: String): File {
        val d = File(context.filesDir, name)
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun voiceFile(context: Context): File =
        File(dir(context, "voice"), "rec_${System.currentTimeMillis()}.m4a")

    fun extractFile(context: Context): File =
        File(dir(context, "voice"), "extract_${System.currentTimeMillis()}.m4a")

    fun ttsFile(context: Context): File =
        File(dir(context, "voice"), "tts_${System.currentTimeMillis()}.wav")

    // ------------------------------------------------------------ WAV

    private fun writeWav(file: File, pcm: ShortArray) {
        val dataLen = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(36 + dataLen)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1) // PCM
        bb.putShort(1) // mono
        bb.putInt(RATE)
        bb.putInt(RATE * 2)
        bb.putShort(2)
        bb.putShort(16)
        bb.put("data".toByteArray())
        bb.putInt(dataLen)
        for (s in pcm) bb.putShort(s)
        FileOutputStream(file).use { it.write(bb.array()) }
    }

    /** WAV hening sepanjang [ms]; dipakai sebagai jeda sebelum klip audio saat ekspor. */
    fun silentWav(context: Context, ms: Long): File {
        val f = File(dir(context, "tmp"), "silence_$ms.wav")
        if (!f.exists() || f.length() < 44) {
            val n = (ms * RATE / 1000L).toInt().coerceAtLeast(1)
            writeWav(f, ShortArray(n))
        }
        return f
    }

    /** Hapus berkas jeda lama. */
    fun cleanTmp(context: Context) {
        try {
            File(context.filesDir, "tmp").listFiles()?.forEach { it.delete() }
        } catch (e: Exception) {
            // abaikan
        }
    }

    // ------------------------------------------------------------ efek suara

    private fun buf(ms: Int, f: (i: Int, t: Double) -> Double): ShortArray {
        val n = RATE * ms / 1000
        val out = ShortArray(n)
        for (i in 0 until n) {
            val v = f(i, i.toDouble() / RATE) * 0.85
            out[i] = (v.coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort()
        }
        return out
    }

    /** Nada dengan frekuensi meluncur dari f0 ke f1 selama [ms]. */
    private fun sweep(ms: Int, f0: Double, f1: Double, env: (p: Double) -> Double,
                      square: Boolean = false): ShortArray {
        var phase = 0.0
        return buf(ms) { i, _ ->
            val p = i.toDouble() / (RATE * ms / 1000)
            val f = f0 + (f1 - f0) * p
            phase += 2.0 * PI * f / RATE
            val s = sin(phase)
            (if (square) (if (s >= 0) 0.6 else -0.6) else s) * env(p)
        }
    }

    private fun decay(p: Double, k: Double) = exp(-k * p)

    val sfx: List<Sfx> = listOf(
        Sfx("Klik") {
            val r = Random(1)
            buf(60) { i, t -> (r.nextDouble() * 2 - 1) * decay(t * 1000 / 60, 6.0) * 0.7 +
                sin(2 * PI * 1800 * t) * decay(t * 1000 / 60, 8.0) * 0.5 }
        },
        Sfx("Pop") { sweep(110, 700.0, 180.0, { decay(it, 5.0) }) },
        Sfx("Ding") {
            buf(1000) { _, t ->
                (sin(2 * PI * 1318 * t) + 0.4 * sin(2 * PI * 2637 * t)) * decay(t, 5.0) * 0.55
            }
        },
        Sfx("Bel") {
            buf(1500) { _, t ->
                (sin(2 * PI * 880 * t) + 0.6 * sin(2 * PI * 880 * 2.76 * t) +
                    0.4 * sin(2 * PI * 880 * 5.4 * t)) * decay(t, 3.5) * 0.4
            }
        },
        Sfx("Whoosh") {
            val r = Random(2)
            var lp = 0.0
            buf(800) { i, t ->
                val p = i / (RATE * 0.8)
                val a = sin(PI * p) // naik lalu turun
                val k = 0.03 + 0.5 * a
                lp += k * ((r.nextDouble() * 2 - 1) - lp)
                lp * a * 2.2
            }
        },
        Sfx("Naik") { sweep(900, 200.0, 1400.0, { 0.2 + 0.7 * it }) },
        Sfx("Turun") { sweep(650, 1100.0, 140.0, { 1.0 - it * 0.9 }) },
        Sfx("Laser") { sweep(280, 2200.0, 180.0, { decay(it, 3.0) }, true) },
        Sfx("Ledakan") {
            val r = Random(3)
            var lp = 0.0
            buf(1600) { i, t ->
                val p = t / 1.6
                lp += 0.12 * ((r.nextDouble() * 2 - 1) - lp)
                lp * 3.0 * decay(p, 4.5) + sin(2 * PI * 55 * t) * decay(p, 6.0) * 0.8
            }
        },
        Sfx("Drum") {
            var phase = 0.0
            val r = Random(4)
            buf(450) { i, t ->
                val p = t / 0.45
                val f = 50.0 + 130.0 * exp(-18.0 * p)
                phase += 2 * PI * f / RATE
                sin(phase) * decay(p, 6.0) + (r.nextDouble() * 2 - 1) * decay(p, 40.0) * 0.4
            }
        },
        Sfx("Koin") {
            buf(600) { _, t ->
                val f = if (t < 0.08) 988.0 else 1319.0
                val e = if (t < 0.08) 1.0 else decay(t - 0.08, 7.0)
                sin(2 * PI * f * t) * e * 0.6
            }
        },
        Sfx("Buzzer") {
            buf(550) { _, t ->
                val s = sin(2 * PI * 150 * t)
                (if (s >= 0) 0.55 else -0.55) * (if (t > 0.5) (0.55 - t) / 0.05 else 1.0)
            }
        },
        Sfx("Sirine") {
            var phase = 0.0
            buf(1800) { i, t ->
                val f = 750.0 + 200.0 * sin(2 * PI * 1.1 * t)
                phase += 2 * PI * f / RATE
                val fade = min(1.0, min(t / 0.05, (1.8 - t) / 0.2))
                sin(phase) * 0.6 * fade
            }
        },
        Sfx("Notifikasi") {
            buf(700) { _, t ->
                val a = if (t < 0.15) sin(2 * PI * 1046 * t) * decay(t, 12.0)
                else if (t in 0.18..0.7) sin(2 * PI * 1568 * t) * decay(t - 0.18, 6.0) else 0.0
                a * 0.6
            }
        }
    )

    /** Berkas WAV untuk efek [index]; dibuat sekali lalu disimpan. */
    fun sfxFile(context: Context, index: Int): File {
        val f = File(dir(context, "sfx"), "sfx_$index.wav")
        if (!f.exists() || f.length() < 44) writeWav(f, sfx[index].gen())
        return f
    }

    // ------------------------------------------------------------ ekstrak

    /**
     * Menyalin trek audio video (rentang [startMs]..[endMs] sumber) ke berkas .m4a tanpa
     * encode ulang. Mengembalikan false bila video tidak punya audio atau formatnya
     * tidak bisa dimuat ke m4a.
     */
    fun extractAudio(context: Context, uri: Uri, startMs: Long, endMs: Long, out: File): Boolean {
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(context, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    track = i
                    fmt = f
                    break
                }
            }
            if (track < 0 || fmt == null) return false
            ex.selectTrack(track)
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val dst = muxer.addTrack(fmt)
            muxer.start()
            started = true
            val startUs = startMs * 1000L
            val endUs = endMs * 1000L
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val bb = ByteBuffer.allocate(1 shl 20)
            val info = MediaCodec.BufferInfo()
            var firstUs = -1L
            while (true) {
                val n = ex.readSampleData(bb, 0)
                if (n < 0) break
                val t = ex.sampleTime
                if (t > endUs) break
                if (t >= startUs) {
                    if (firstUs < 0L) firstUs = t
                    info.set(0, n, t - firstUs, MediaCodec.BUFFER_FLAG_KEY_FRAME)
                    muxer.writeSampleData(dst, bb, info)
                }
                ex.advance()
            }
            if (firstUs < 0L) return false
            muxer.stop()
            started = false
            return true
        } catch (e: Exception) {
            out.delete()
            return false
        } finally {
            try {
                if (started) muxer?.stop()
            } catch (e: Exception) {
                // abaikan
            }
            try {
                muxer?.release()
            } catch (e: Exception) {
                // abaikan
            }
            try {
                ex.release()
            } catch (e: Exception) {
                // abaikan
            }
        }
    }

    // ------------------------------------------------------------ teks ke audio

    class Voice(val label: String, val locale: Locale)

    val voices = listOf(
        Voice("Indonesia", Locale("id", "ID")),
        Voice("Inggris (AS)", Locale.US),
        Voice("Inggris (Inggris)", Locale.UK),
        Voice("Arab", Locale("ar")),
        Voice("Jepang", Locale.JAPAN),
        Voice("Korea", Locale.KOREA),
        Voice("Mandarin", Locale.CHINA)
    )

    /**
     * Membuat suara dari teks ke berkas WAV. [done] dipanggil dari thread lain:
     * null = berhasil, selain itu pesan kesalahan. Harus dipanggil dari thread utama.
     */
    fun speak(context: Context, text: String, locale: Locale, rate: Float, pitch: Float,
              out: File, done: (String?) -> Unit) {
        var engine: TextToSpeech? = null
        var finished = false
        fun finish(err: String?) {
            if (finished) return
            finished = true
            try {
                engine?.shutdown()
            } catch (e: Exception) {
                // abaikan
            }
            if (err != null) out.delete()
            done(err)
        }
        engine = TextToSpeech(context.applicationContext) { status ->
            val t = engine
            if (status != TextToSpeech.SUCCESS || t == null) {
                finish("Mesin suara (Text-to-Speech) tidak tersedia di perangkat ini")
                return@TextToSpeech
            }
            val r = t.setLanguage(locale)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                finish("Bahasa belum terpasang. Pasang data suara di Pengaturan > Text-to-Speech")
                return@TextToSpeech
            }
            t.setSpeechRate(rate)
            t.setPitch(pitch)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) = finish(null)

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) = finish("Gagal membuat suara")
            })
            val res = t.synthesizeToFile(text, null, out, "zufx_tts")
            if (res != TextToSpeech.SUCCESS) finish("Gagal membuat suara")
        }
    }
}
