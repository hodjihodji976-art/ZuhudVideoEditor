package com.zuhud.videoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Menggambar garis panduan tengah (cyan) di atas kanvas. */
object GuideDraw {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF19E6D8.toInt()
        style = Paint.Style.STROKE
    }

    fun draw(c: Canvas, w: Float, h: Float, vertical: Boolean, horizontal: Boolean, density: Float) {
        if (!vertical && !horizontal) return
        paint.strokeWidth = 1.5f * density
        if (vertical) c.drawLine(w / 2f, 0f, w / 2f, h, paint)
        if (horizontal) c.drawLine(0f, h / 2f, w, h / 2f, paint)
    }
}

/** Lapisan ringan di atas kanvas: hanya menggambar garis panduan, tidak menerima sentuhan. */
class GuideView(context: Context) : View(context) {
    private var v = false
    private var hz = false

    init {
        isClickable = false
        isFocusable = false
    }

    fun set(vertical: Boolean, horizontal: Boolean) {
        if (vertical == v && horizontal == hz) return
        v = vertical
        hz = horizontal
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        GuideDraw.draw(canvas, width.toFloat(), height.toFloat(), v, hz, resources.displayMetrics.density)
    }
}
