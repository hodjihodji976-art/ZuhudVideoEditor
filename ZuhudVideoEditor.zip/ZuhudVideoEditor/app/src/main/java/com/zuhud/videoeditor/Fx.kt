package com.zuhud.videoeditor

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.Effect
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * Efek video berbasis shader (Kabur, Mozaik, Vinyet, Glitch, dst.) yang aktif pada rentang waktu tertentu.
 * Shader yang sama dipakai preview (ExoPlayer.setVideoEffects) dan ekspor (Composition effects).
 */
object Fx {

    class Def(val name: String, val cat: Int)

    val cats = listOf("Dasar", "Distorsi", "Retro", "Gaya")

    /** Urutan = nomor mode di shader. */
    val all: List<Def> = listOf(
        Def("Kabur", 0),            // 0
        Def("Kabur radial", 0),     // 1
        Def("Mozaik", 3),           // 2
        Def("Vinyet", 0),           // 3
        Def("Pertajam", 0),         // 4
        Def("Bersinar", 0),         // 5
        Def("Glitch", 2),           // 6
        Def("Butiran film", 2),     // 7
        Def("Getar", 1),            // 8
        Def("Denyut", 1),           // 9
        Def("Cermin", 1),           // 10
        Def("Lensa lebar", 1),      // 11
        Def("Neon tepi", 3),        // 12
        Def("Aberasi", 2),          // 13
        Def("VHS", 2),              // 14
        Def("Kilat", 3),            // 15
        Def("Film lama", 2),        // 16
        Def("Bagi 4", 1),           // 17
        Def("Riak", 1),             // 18
        Def("Poster", 3),           // 19
        Def("Latar blur", 0)        // 20 (blur halus kuat di seluruh bingkai, efek biasa)
    )

    const val BLUR_BG = 20

    fun name(type: Int): String = all.getOrNull(type)?.name ?: "Efek"

    /** Jam preview (ms posisi timeline); diperbarui dari thread utama, dibaca thread GL. */
    class Clock {
        @Volatile
        var ms: Long = 0L
    }

    /** Efek untuk ekspor: waktu diambil dari presentationTimeUs komposisi. */
    fun exportEffect(item: FxItem): Effect {
        val snap = FxItem(item.id, item.type, item.startMs, item.durationMs, item.amount)
        return FxEffect(snap, null)
    }

    /** Efek untuk preview: waktu diambil dari jam preview, nilai dibaca langsung dari item. */
    fun previewEffect(item: FxItem, clock: Clock): Effect = FxEffect(item, clock)

    /**
     * Pengganti Presentation (mode muat): video dipas di kanvas out W x out H, bingkai kosong diisi
     * salinan video yang diperbesar dan diburamkan. Zoom/geser klip ikut dihitung di sini.
     */
    fun blurBackground(
        outW: Int, outH: Int, zoom: Float, panX: Float, panY: Float, offsetMs: Long, items: List<FxItem>
    ): Effect = BgEffect(outW, outH, zoom, panX, panY, offsetMs, items)

    private const val BG_FRAGMENT = """
precision highp float;
varying vec2 vTexCoord;
uniform sampler2D uTexSampler;
uniform vec2 uSrc;
uniform vec2 uOut;
uniform float uZoom;
uniform vec2 uPan;
uniform float uBlur;

vec4 tex(vec2 uv) {
  return texture2D(uTexSampler, clamp(uv, 0.0, 1.0));
}

void main() {
  vec2 p = vTexCoord;
  float sFit = min(uOut.x / uSrc.x, uOut.y / uSrc.y);
  vec2 fs = vec2(uSrc.x * sFit / uOut.x, uSrc.y * sFit / uOut.y) * uZoom;
  vec2 center = vec2(0.5 + uPan.x, 0.5 - uPan.y);
  vec2 q = (p - center) / fs + vec2(0.5);
  if (q.x >= 0.0 && q.x <= 1.0 && q.y >= 0.0 && q.y <= 1.0) {
    gl_FragColor = tex(q);
    return;
  }
  if (uBlur < 0.01) {
    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }
  float sCov = max(uOut.x / uSrc.x, uOut.y / uSrc.y);
  vec2 vis = vec2(uOut.x / (uSrc.x * sCov), uOut.y / (uSrc.y * sCov));
  vec2 b = (p - vec2(0.5)) * vis + vec2(0.5);
  vec3 s = tex(b).rgb;
  for (int i = 0; i < 8; i++) {
    float a = float(i) * 0.785398;
    vec2 d = vec2(cos(a), sin(a)) * vis;
    s += tex(b + d * 0.05 * uBlur).rgb;
    s += tex(b + d * 0.033 * uBlur).rgb;
    s += tex(b + d * 0.016 * uBlur).rgb;
  }
  gl_FragColor = vec4(s / 25.0 * 0.75, 1.0);
}
"""

    private class BgEffect(
        val outW: Int, val outH: Int, val zoom: Float, val panX: Float, val panY: Float,
        val offsetMs: Long, val items: List<FxItem>
    ) : GlEffect {
        override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
            BgProgram(outW, outH, zoom, panX, panY, offsetMs, items)
    }

    private class BgProgram(
        val outW: Int, val outH: Int, val zoom: Float, val panX: Float, val panY: Float,
        val offsetMs: Long, val items: List<FxItem>
    ) : BaseGlShaderProgram(false, 1) {
        private val program: GlProgram = try {
            val p = GlProgram(VERTEX, BG_FRAGMENT)
            p.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            p
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
        private var w = 1
        private var h = 1

        override fun configure(inputWidth: Int, inputHeight: Int): Size {
            w = inputWidth
            h = inputHeight
            return Size(outW, outH)
        }

        override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
            try {
                program.use()
                program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
                program.setFloatsUniform("uSrc", floatArrayOf(w.toFloat(), h.toFloat()))
                program.setFloatsUniform("uOut", floatArrayOf(outW.toFloat(), outH.toFloat()))
                program.setFloatUniform("uZoom", zoom)
                program.setFloatsUniform("uPan", floatArrayOf(panX, panY))
                val t = offsetMs + presentationTimeUs / 1000L
                var amt = -1f
                for (f in items) {
                    if (t >= f.startMs && t < f.endMs) amt = f.amount
                }
                program.setFloatUniform("uBlur", if (amt < 0f) 0f else 0.4f + amt)
                program.bindAttributesAndUniforms()
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                GlUtil.checkGlError()
            } catch (e: Exception) {
                throw VideoFrameProcessingException(e, presentationTimeUs)
            }
        }

        override fun release() {
            super.release()
            try {
                program.delete()
            } catch (e: Exception) {
                // abaikan
            }
        }
    }

    private const val VERTEX = """
attribute vec4 aFramePosition;
varying vec2 vTexCoord;
void main() {
  gl_Position = aFramePosition;
  vTexCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""

    private const val FRAGMENT = """
precision highp float;
varying vec2 vTexCoord;
uniform sampler2D uTexSampler;
uniform float uMode;
uniform float uAmt;
uniform float uTime;
uniform float uActive;
uniform vec2 uSize;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

vec4 tex(vec2 uv) {
  return texture2D(uTexSampler, clamp(uv, 0.0, 1.0));
}

float aspect() {
  return uSize.x / uSize.y;
}

vec3 blurAt(vec2 uv, float rad) {
  vec3 s = tex(uv).rgb;
  for (int i = 0; i < 8; i++) {
    float a = float(i) * 0.785398;
    vec2 d = vec2(cos(a) / aspect(), sin(a));
    s += tex(uv + d * rad).rgb;
    s += tex(uv + d * rad * 0.66).rgb;
    s += tex(uv + d * rad * 0.33).rgb;
  }
  return s / 25.0;
}

float luma(vec3 c) {
  return dot(c, vec3(0.299, 0.587, 0.114));
}

vec3 vignette(vec3 c, vec2 uv, float k) {
  vec2 p = (uv - 0.5) * vec2(aspect(), 1.0);
  float d = length(p);
  float v = smoothstep(0.3, 0.95, d);
  return c * (1.0 - v * k);
}

void main() {
  vec2 uv = vTexCoord;
  vec4 base = tex(uv);
  if (uActive < 0.5) {
    gl_FragColor = base;
    return;
  }
  vec3 c = base.rgb;
  float a = uAmt;
  vec2 tx = 1.0 / uSize;

  if (uMode < 0.5) {
    c = blurAt(uv, a * 0.035);
  } else if (uMode < 1.5) {
    vec3 s = vec3(0.0);
    for (int i = 0; i < 12; i++) {
      float t = float(i) / 11.0;
      vec2 q = vec2(0.5) + (uv - vec2(0.5)) * (1.0 - a * 0.3 * t);
      s += tex(q).rgb;
    }
    c = s / 12.0;
  } else if (uMode < 2.5) {
    float n = mix(160.0, 10.0, a);
    vec2 cell = vec2(n, n / aspect());
    c = tex((floor(uv * cell) + 0.5) / cell).rgb;
  } else if (uMode < 3.5) {
    c = vignette(c, uv, a * 1.1);
  } else if (uMode < 4.5) {
    vec3 n = tex(uv + vec2(tx.x, 0.0)).rgb + tex(uv - vec2(tx.x, 0.0)).rgb
           + tex(uv + vec2(0.0, tx.y)).rgb + tex(uv - vec2(0.0, tx.y)).rgb;
    c = c + (c * 4.0 - n) * a * 1.5;
  } else if (uMode < 5.5) {
    vec3 b = blurAt(uv, 0.03);
    c = vec3(1.0) - (vec3(1.0) - c) * (vec3(1.0) - b * a * 1.2);
  } else if (uMode < 6.5) {
    float stp = floor(uTime * 12.0);
    float band = floor(uv.y * 18.0);
    float r = hash(vec2(band, stp));
    float sh = 0.0;
    if (r > 0.78) {
      sh = (r - 0.78) * 0.5 * a;
    }
    float split = 0.012 * a;
    c = vec3(tex(uv + vec2(sh + split, 0.0)).r, tex(uv + vec2(sh, 0.0)).g, tex(uv + vec2(sh - split, 0.0)).b);
  } else if (uMode < 7.5) {
    float n = hash(uv * vec2(aspect(), 1.0) * 900.0 + vec2(floor(uTime * 24.0)));
    c = c + (n - 0.5) * a * 0.6;
  } else if (uMode < 8.5) {
    vec2 o = vec2(sin(uTime * 60.0), cos(uTime * 47.0)) * 0.02 * a;
    c = tex(uv + o).rgb;
  } else if (uMode < 9.5) {
    float s = 1.0 - 0.14 * a * (0.5 + 0.5 * sin(uTime * 10.0));
    c = tex(vec2(0.5) + (uv - vec2(0.5)) * s).rgb;
  } else if (uMode < 10.5) {
    vec2 m = vec2(uv.x > 0.5 ? 1.0 - uv.x : uv.x, uv.y);
    c = tex(m).rgb;
  } else if (uMode < 11.5) {
    vec2 p = uv - vec2(0.5);
    float f = 1.0 - a * dot(p, p) * 2.4;
    c = tex(vec2(0.5) + p * f).rgb;
  } else if (uMode < 12.5) {
    float tl = luma(tex(uv + vec2(-tx.x, tx.y)).rgb);
    float t0 = luma(tex(uv + vec2(0.0, tx.y)).rgb);
    float tr = luma(tex(uv + vec2(tx.x, tx.y)).rgb);
    float l0 = luma(tex(uv + vec2(-tx.x, 0.0)).rgb);
    float r0 = luma(tex(uv + vec2(tx.x, 0.0)).rgb);
    float bl = luma(tex(uv + vec2(-tx.x, -tx.y)).rgb);
    float b0 = luma(tex(uv + vec2(0.0, -tx.y)).rgb);
    float br = luma(tex(uv + vec2(tx.x, -tx.y)).rgb);
    float gx = -tl - 2.0 * l0 - bl + tr + 2.0 * r0 + br;
    float gy = -tl - 2.0 * t0 - tr + bl + 2.0 * b0 + br;
    float e = clamp(length(vec2(gx, gy)) * 2.0, 0.0, 1.0);
    c = c * (1.0 - a * 0.75) + e * vec3(0.1, 0.9, 1.0) * (1.0 + a * 2.0);
  } else if (uMode < 13.5) {
    vec2 sh = (uv - vec2(0.5)) * 0.04 * a;
    c = vec3(tex(uv + sh).r, base.g, tex(uv - sh).b);
  } else if (uMode < 14.5) {
    float wob = sin(uv.y * 40.0 + uTime * 8.0) * 0.004 * a;
    vec2 q = uv + vec2(wob, 0.0);
    c = vec3(tex(q + vec2(0.004 * a, 0.0)).r, tex(q).g, tex(q - vec2(0.004 * a, 0.0)).b);
    float line = 0.9 + 0.1 * sin(uv.y * uSize.y * 1.5);
    c = c * mix(1.0, line, a) + (hash(uv * 500.0 + vec2(uTime)) - 0.5) * 0.08 * a;
  } else if (uMode < 15.5) {
    float f = step(0.5, fract(uTime * 4.0));
    c = c + f * a * 0.7;
  } else if (uMode < 16.5) {
    float g = luma(c);
    vec3 sepia = vec3(g * 1.2, g * 1.0, g * 0.8);
    c = mix(c, sepia, a);
    float n = hash(uv * vec2(aspect(), 1.0) * 700.0 + vec2(floor(uTime * 24.0)));
    c = c + (n - 0.5) * 0.25 * a;
    c = vignette(c, uv, a * 0.8);
    c = c * (1.0 + 0.06 * a * sin(uTime * 40.0));
  } else if (uMode < 17.5) {
    c = tex(fract(uv * 2.0)).rgb;
  } else if (uMode < 18.5) {
    vec2 o = vec2(sin(uv.y * 30.0 + uTime * 6.0), cos(uv.x * 30.0 + uTime * 6.0)) * 0.01 * a;
    c = tex(uv + o).rgb;
  } else if (uMode < 19.5) {
    float lv = mix(16.0, 3.0, a);
    c = floor(c * lv + 0.5) / lv;
  } else {
    c = (blurAt(uv, 0.02 + a * 0.08) + blurAt(uv, 0.012 + a * 0.05)) * 0.5;
  }
  gl_FragColor = vec4(clamp(c, 0.0, 1.0), base.a);
}
"""

    private class FxEffect(val item: FxItem, val clock: Clock?) : GlEffect {
        override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
            FxProgram(item, clock)
    }

    private class FxProgram(val item: FxItem, val clock: Clock?) : BaseGlShaderProgram(false, 1) {
        private val program: GlProgram = try {
            val p = GlProgram(VERTEX, FRAGMENT)
            p.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            p
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
        private var w = 1
        private var h = 1

        override fun configure(inputWidth: Int, inputHeight: Int): Size {
            w = inputWidth
            h = inputHeight
            return Size(inputWidth, inputHeight)
        }

        override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
            try {
                val ms = if (clock != null) clock.ms else presentationTimeUs / 1000L
                val active = ms >= item.startMs && ms < item.startMs + item.durationMs
                val localSec = (ms - item.startMs) / 1000f
                program.use()
                program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
                program.setFloatUniform("uMode", item.type.toFloat())
                program.setFloatUniform("uAmt", item.amount)
                program.setFloatUniform("uTime", localSec)
                program.setFloatUniform("uActive", if (active) 1f else 0f)
                program.setFloatsUniform("uSize", floatArrayOf(w.toFloat(), h.toFloat()))
                program.bindAttributesAndUniforms()
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                GlUtil.checkGlError()
            } catch (e: Exception) {
                throw VideoFrameProcessingException(e, presentationTimeUs)
            }
        }

        override fun release() {
            super.release()
            try {
                program.delete()
            } catch (e: Exception) {
                // abaikan
            }
        }
    }
}
