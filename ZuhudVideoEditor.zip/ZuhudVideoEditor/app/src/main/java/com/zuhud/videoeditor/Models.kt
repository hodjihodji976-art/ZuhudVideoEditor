package com.zuhud.videoeditor

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Satu klip video di timeline. width/height sudah memperhitungkan rotasi. */
data class Clip(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    var startMs: Long = 0L,
    var endMs: Long = durationMs,
    var speed: Float = 1f,
    // Pangkas (crop) sebagai pecahan 0..1 dari tiap sisi.
    var cropL: Float = 0f,
    var cropT: Float = 0f,
    var cropR: Float = 0f,
    var cropB: Float = 0f,
    // Foto sebagai klip utama (durasi diatur dengan menarik tepi klip).
    val isImage: Boolean = false,
    // Transisi masuk (0 = tanpa) dan filter warna (0 = tanpa).
    var transition: Int = 0,
    var filter: Int = 0,
    // Zoom (cubit layar) dan geser; panX/panY dalam pecahan lebar/tinggi kanvas.
    var zoom: Float = 1f,
    var panX: Float = 0f,
    var panY: Float = 0f
) {
    /** Durasi klip di timeline setelah dipotong dan diatur kecepatannya. */
    val effectiveMs: Long
        get() = ((endMs - startMs) / speed).toLong().coerceAtLeast(1L)

    val hasCrop: Boolean
        get() = cropL > 0.001f || cropT > 0.001f || cropR > 0.001f || cropB > 0.001f

    /** Rasio lebar/tinggi setelah dipangkas. */
    val croppedAspect: Float
        get() = (width * (1f - cropL - cropR)) / (height * (1f - cropT - cropB))
}

/** Lapisan di atas video: teks atau gambar. Posisi dalam pecahan kanvas (0..1). */
data class Layer(
    val id: Long,
    val type: Int,
    var text: String = "",
    var uri: Uri? = null,
    var color: Int = 0xFFFFFFFF.toInt(),
    var cx: Float = 0.5f,
    var cy: Float = 0.5f,
    var scale: Float = 1f,
    var rotation: Float = 0f,
    var startMs: Long = 0L,
    var durationMs: Long = 3000L,
    var font: Int = 0,
    // Kunci kroma / hapus latar untuk gambar: 0 = mati, 1 = otomatis, 2 = manual.
    var keyMode: Int = 0,
    var keyColor: Int = 0xFF00FF00.toInt(),
    var keyTol: Float = 0.3f,
    var keySoft: Float = 0.1f,
    // Layer video (PiP): ukuran & durasi sumber, volume 0..2.
    var srcW: Int = 0,
    var srcH: Int = 0,
    var srcDurMs: Long = 0L,
    var volume: Float = 1f,
    // Pangkas manual foto/video PiP (pecahan 0..1 dari sumber)
    var lCropL: Float = 0f,
    var lCropT: Float = 0f,
    var lCropR: Float = 0f,
    var lCropB: Float = 0f,
    // Gaya teks
    var opacity: Float = 1f,
    var strokeColor: Int = 0xFF000000.toInt(),
    var strokeW: Float = 0.14f,
    var bgColor: Int = 0xFF000000.toInt(),
    var bgAlpha: Float = 0f,
    var bold: Boolean = false,
    var italic: Boolean = false,
    var spacing: Float = 0f,
    var fontFile: String = "",
    // Efek teks
    var shadow: Boolean = false,
    var shadowColor: Int = 0xFF000000.toInt(),
    var glowR: Float = 0f,
    var glowColor: Int = 0xFFFF2BD6.toInt(),
    var gradOn: Boolean = false,
    var gradColor: Int = 0xFF7A2BFF.toInt(),
    var extrude: Int = 0,
    var glitch: Boolean = false,
    // Animasi (berlaku untuk teks, stiker, dan gambar)
    var animIn: Int = 0,
    var animOut: Int = 0,
    var animLoop: Int = 0,
    var animMs: Long = 600L
) {
    companion object {
        const val TEXT = 0
        const val IMAGE = 1
        const val STICKER = 2
        const val VIDEO = 3
    }

    val endMs: Long get() = startMs + durationMs
}

data class AudioTrack(
    val uri: Uri,
    val name: String,
    val durationMs: Long
)

/** Efek video pada rentang waktu tertentu di timeline (Kabur, Mozaik, Vinyet, dst.). */
class FxItem(
    var id: Long,
    var type: Int,
    var startMs: Long,
    var durationMs: Long,
    var amount: Float = 0.6f
) {
    val endMs: Long get() = startMs + durationMs
}

class Project(var id: String = System.currentTimeMillis().toString()) {
    var name: String = ""
    var updatedAt: Long = System.currentTimeMillis()
    val clips = mutableListOf<Clip>()
    val layers = mutableListOf<Layer>()
    val fx = mutableListOf<FxItem>()
    var audio: AudioTrack? = null
    var muteOriginal: Boolean = false

    /** Volume video utama dan musik, 0..2 (1 = 100%). */
    var videoVolume: Float = 1f
    var audioVolume: Float = 1f

    /** Rasio kanvas. 0/0 berarti mengikuti video pertama. */
    var aspectW: Int = 0
    var aspectH: Int = 0

    /** false = muat (ada bingkai hitam), true = penuhi kanvas (tepi terpotong). */
    var fillMode: Boolean = false

    /** Mode muat: isi bingkai kosong dengan salinan video yang diburamkan. */
    var blurBg: Boolean = false

    val totalMs: Long get() = clips.sumOf { it.effectiveMs }

    fun canvasAspect(): Float {
        if (aspectW > 0 && aspectH > 0) return aspectW.toFloat() / aspectH
        val c = clips.firstOrNull() ?: return 16f / 9f
        return c.croppedAspect
    }

    fun nextFxId(): Long {
        var id = System.currentTimeMillis()
        val max = fx.maxOfOrNull { it.id } ?: 0L
        if (id <= max) id = max + 1
        return id
    }

    fun nextLayerId(): Long {
        var id = System.currentTimeMillis()
        val max = layers.maxOfOrNull { it.id } ?: 0L
        if (id <= max) id = max + 1
        return id
    }
}

/** Konversi proyek ke/dari JSON (untuk simpan proyek dan undo/redo). */
object ProjectJson {

    fun toJson(p: Project): JSONObject {
        val o = JSONObject()
        o.put("id", p.id)
        o.put("name", p.name)
        o.put("updatedAt", p.updatedAt)
        o.put("mute", p.muteOriginal)
        o.put("aw", p.aspectW)
        o.put("ah", p.aspectH)
        o.put("fill", p.fillMode)
        o.put("bb", p.blurBg)
        o.put("vv", p.videoVolume.toDouble())
        o.put("av", p.audioVolume.toDouble())

        val clips = JSONArray()
        for (c in p.clips) {
            val j = JSONObject()
            j.put("uri", c.uri.toString())
            j.put("name", c.name)
            j.put("dur", c.durationMs)
            j.put("w", c.width)
            j.put("h", c.height)
            j.put("s", c.startMs)
            j.put("e", c.endMs)
            j.put("sp", c.speed.toDouble())
            j.put("cl", c.cropL.toDouble())
            j.put("ct", c.cropT.toDouble())
            j.put("cr", c.cropR.toDouble())
            j.put("cb", c.cropB.toDouble())
            j.put("img", c.isImage)
            j.put("zm", c.zoom.toDouble())
            j.put("px", c.panX.toDouble())
            j.put("py", c.panY.toDouble())
            j.put("tr", c.transition)
            j.put("fl", c.filter)
            clips.put(j)
        }
        o.put("clips", clips)

        val layers = JSONArray()
        for (l in p.layers) {
            val j = JSONObject()
            j.put("id", l.id)
            j.put("type", l.type)
            j.put("text", l.text)
            j.put("uri", l.uri?.toString() ?: "")
            j.put("color", l.color)
            j.put("cx", l.cx.toDouble())
            j.put("cy", l.cy.toDouble())
            j.put("sc", l.scale.toDouble())
            j.put("rot", l.rotation.toDouble())
            j.put("s", l.startMs)
            j.put("d", l.durationMs)
            j.put("font", l.font)
            j.put("km", l.keyMode)
            j.put("kc", l.keyColor)
            j.put("kt", l.keyTol.toDouble())
            j.put("ks", l.keySoft.toDouble())
            j.put("sw", l.srcW)
            j.put("sh", l.srcH)
            j.put("sd", l.srcDurMs)
            j.put("vol", l.volume.toDouble())
            j.put("lcl", l.lCropL.toDouble())
            j.put("lct", l.lCropT.toDouble())
            j.put("lcr", l.lCropR.toDouble())
            j.put("lcb", l.lCropB.toDouble())
            j.put("op", l.opacity.toDouble())
            j.put("stc", l.strokeColor)
            j.put("stw", l.strokeW.toDouble())
            j.put("bgc", l.bgColor)
            j.put("bga", l.bgAlpha.toDouble())
            j.put("bd", l.bold)
            j.put("it", l.italic)
            j.put("sp", l.spacing.toDouble())
            j.put("ff", l.fontFile)
            j.put("shd", l.shadow)
            j.put("shc", l.shadowColor)
            j.put("gr", l.glowR.toDouble())
            j.put("gc", l.glowColor)
            j.put("go", l.gradOn)
            j.put("gc2", l.gradColor)
            j.put("ex", l.extrude)
            j.put("gl", l.glitch)
            j.put("ai", l.animIn)
            j.put("ao", l.animOut)
            j.put("al", l.animLoop)
            j.put("am", l.animMs)
            layers.put(j)
        }
        o.put("layers", layers)

        val fxs = JSONArray()
        for (f in p.fx) {
            val j = JSONObject()
            j.put("id", f.id)
            j.put("t", f.type)
            j.put("s", f.startMs)
            j.put("d", f.durationMs)
            j.put("a", f.amount.toDouble())
            fxs.put(j)
        }
        o.put("fx", fxs)

        p.audio?.let { a ->
            val j = JSONObject()
            j.put("uri", a.uri.toString())
            j.put("name", a.name)
            j.put("dur", a.durationMs)
            o.put("audio", j)
        }
        return o
    }

    fun fromJson(o: JSONObject): Project {
        val p = Project(o.optString("id", System.currentTimeMillis().toString()))
        p.name = o.optString("name", "")
        p.updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
        p.muteOriginal = o.optBoolean("mute", false)
        p.aspectW = o.optInt("aw", 0)
        p.aspectH = o.optInt("ah", 0)
        p.fillMode = o.optBoolean("fill", false)
        p.blurBg = o.optBoolean("bb", false)
        p.videoVolume = o.optDouble("vv", 1.0).toFloat()
        p.audioVolume = o.optDouble("av", 1.0).toFloat()

        val clips = o.optJSONArray("clips")
        if (clips != null) {
            for (i in 0 until clips.length()) {
                val j = clips.getJSONObject(i)
                p.clips.add(
                    Clip(
                        uri = Uri.parse(j.getString("uri")),
                        name = j.optString("name", "video"),
                        durationMs = j.getLong("dur"),
                        width = j.getInt("w"),
                        height = j.getInt("h"),
                        startMs = j.optLong("s", 0L),
                        endMs = j.optLong("e", j.getLong("dur")),
                        speed = j.optDouble("sp", 1.0).toFloat(),
                        cropL = j.optDouble("cl", 0.0).toFloat(),
                        cropT = j.optDouble("ct", 0.0).toFloat(),
                        cropR = j.optDouble("cr", 0.0).toFloat(),
                        cropB = j.optDouble("cb", 0.0).toFloat(),
                        isImage = j.optBoolean("img", false),
                        transition = j.optInt("tr", 0),
                        filter = j.optInt("fl", 0),
                        zoom = j.optDouble("zm", 1.0).toFloat(),
                        panX = j.optDouble("px", 0.0).toFloat(),
                        panY = j.optDouble("py", 0.0).toFloat()
                    )
                )
            }
        }

        val layers = o.optJSONArray("layers")
        if (layers != null) {
            for (i in 0 until layers.length()) {
                val j = layers.getJSONObject(i)
                val u = j.optString("uri", "")
                p.layers.add(
                    Layer(
                        id = j.getLong("id"),
                        type = j.getInt("type"),
                        text = j.optString("text", ""),
                        uri = if (u.isEmpty()) null else Uri.parse(u),
                        color = j.optInt("color", 0xFFFFFFFF.toInt()),
                        cx = j.optDouble("cx", 0.5).toFloat(),
                        cy = j.optDouble("cy", 0.5).toFloat(),
                        scale = j.optDouble("sc", 1.0).toFloat(),
                        rotation = j.optDouble("rot", 0.0).toFloat(),
                        startMs = j.optLong("s", 0L),
                        durationMs = j.optLong("d", 3000L),
                        font = j.optInt("font", 0),
                        keyMode = j.optInt("km", 0),
                        keyColor = j.optInt("kc", 0xFF00FF00.toInt()),
                        keyTol = j.optDouble("kt", 0.3).toFloat(),
                        keySoft = j.optDouble("ks", 0.1).toFloat(),
                        srcW = j.optInt("sw", 0),
                        srcH = j.optInt("sh", 0),
                        srcDurMs = j.optLong("sd", 0L),
                        volume = j.optDouble("vol", 1.0).toFloat(),
                        lCropL = j.optDouble("lcl", 0.0).toFloat(),
                        lCropT = j.optDouble("lct", 0.0).toFloat(),
                        lCropR = j.optDouble("lcr", 0.0).toFloat(),
                        lCropB = j.optDouble("lcb", 0.0).toFloat(),
                        opacity = j.optDouble("op", 1.0).toFloat(),
                        strokeColor = j.optInt("stc", 0xFF000000.toInt()),
                        strokeW = j.optDouble("stw", 0.14).toFloat(),
                        bgColor = j.optInt("bgc", 0xFF000000.toInt()),
                        bgAlpha = j.optDouble("bga", 0.0).toFloat(),
                        bold = j.optBoolean("bd", false),
                        italic = j.optBoolean("it", false),
                        spacing = j.optDouble("sp", 0.0).toFloat(),
                        fontFile = j.optString("ff", ""),
                        shadow = j.optBoolean("shd", false),
                        shadowColor = j.optInt("shc", 0xFF000000.toInt()),
                        glowR = j.optDouble("gr", 0.0).toFloat(),
                        glowColor = j.optInt("gc", 0xFFFF2BD6.toInt()),
                        gradOn = j.optBoolean("go", false),
                        gradColor = j.optInt("gc2", 0xFF7A2BFF.toInt()),
                        extrude = j.optInt("ex", 0),
                        glitch = j.optBoolean("gl", false),
                        animIn = j.optInt("ai", 0),
                        animOut = j.optInt("ao", 0),
                        animLoop = j.optInt("al", 0),
                        animMs = j.optLong("am", 600L)
                    )
                )
            }
        }

        val a = o.optJSONObject("audio")
        if (a != null) {
            p.audio = AudioTrack(
                Uri.parse(a.getString("uri")),
                a.optString("name", "audio"),
                a.getLong("dur")
            )
        }
        val fxs = o.optJSONArray("fx")
        if (fxs != null) {
            for (i in 0 until fxs.length()) {
                val j = fxs.getJSONObject(i)
                p.fx.add(
                    FxItem(
                        j.optLong("id", i.toLong() + 1L),
                        j.optInt("t", 0),
                        j.optLong("s", 0L),
                        j.optLong("d", 3000L),
                        j.optDouble("a", 0.6).toFloat()
                    )
                )
            }
        }
        return p
    }
}
