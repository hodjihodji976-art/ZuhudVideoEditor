package com.zuhud.videoeditor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Menggambar teks/gambar di atas preview dan mengizinkan pengguna menggeser bebas,
 * memperbesar/memutar lewat pegangan sudut kanan-bawah, menghapus (x) dan mengubah teks.
 */
class LayerOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onSelect(layer: Layer?)
        fun onEdit(layer: Layer)
        fun onDelete(layer: Layer)
        fun onBeginChange()
        fun onEndChange()
    }

    var listener: Listener? = null

    /** Dipanggil tiap menggambar ulang; dipakai untuk menyelaraskan posisi layer video. */
    var onDrawHook: (() -> Unit)? = null
    var selectedId: Long = -1L
        set(v) {
            field = v
            invalidate()
        }
    var timeMs: Long = 0L
        set(v) {
            field = v
            invalidate()
        }

    private val density = resources.displayMetrics.density
    private val layers: List<Layer> get() = ProjectStore.current.layers

    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFFFFFF.toInt()
        strokeWidth = 2f * density
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFFFFFFF.toInt()
    }
    private val glyphPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF14141C.toInt()
        strokeWidth = 2f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val textGlyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF14141C.toInt()
        textSize = 11f * density
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    private val handleR = 13f * density
    private val pad = 6f * density

    private enum class Mode { NONE, DRAG, SCALE, DELETE, EDIT }

    private var mode = Mode.NONE
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var active: Layer? = null
    private var startCx = 0f
    private var startCy = 0f
    private var startScale = 1f
    private var startRot = 0f
    private var startDist = 1f
    private var startAngle = 0f
    private var began = false
    private var guideV = false
    private var guideH = false

    // ----------------------------------------------------------------- draw

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        onDrawHook?.invoke()
        LayerRenderer.draw(canvas, w, h, layers, timeMs)
        GuideDraw.draw(canvas, w, h, guideV, guideH, density)

        val sel = selectedActive() ?: return
        val box = LayerRenderer.measure(sel, w, h)
        val hw = box.w / 2f + pad
        val hh = box.h / 2f + pad
        canvas.save()
        canvas.translate(sel.cx * w, sel.cy * h)
        canvas.rotate(sel.rotation)
        canvas.drawRect(-hw, -hh, hw, hh, framePaint)

        // pegangan: hapus (kiri-atas)
        canvas.drawCircle(-hw, -hh, handleR, handlePaint)
        val d = handleR * 0.38f
        canvas.drawLine(-hw - d, -hh - d, -hw + d, -hh + d, glyphPaint)
        canvas.drawLine(-hw - d, -hh + d, -hw + d, -hh - d, glyphPaint)

        // pegangan: ubah teks (kanan-atas)
        if (sel.type == Layer.TEXT) {
            canvas.drawCircle(hw, -hh, handleR, handlePaint)
            canvas.drawText("Aa", hw, -hh + textGlyph.textSize * 0.35f, textGlyph)
        }

        // pegangan: skala + putar (kanan-bawah)
        canvas.drawCircle(hw, hh, handleR, handlePaint)
        val a = handleR * 0.42f
        val p = Path()
        p.moveTo(hw - a, hh - a)
        p.lineTo(hw + a, hh + a)
        canvas.drawPath(p, glyphPaint)
        canvas.drawLine(hw + a, hh + a, hw + a, hh + a * 0.1f, glyphPaint)
        canvas.drawLine(hw + a, hh + a, hw + a * 0.1f, hh + a, glyphPaint)
        canvas.drawLine(hw - a, hh - a, hw - a, hh - a * 0.1f, glyphPaint)
        canvas.drawLine(hw - a, hh - a, hw - a * 0.1f, hh - a, glyphPaint)
        canvas.restore()
    }

    private fun selectedActive(): Layer? {
        val l = layers.firstOrNull { it.id == selectedId } ?: return null
        return if (LayerRenderer.isActive(l, timeMs)) l else null
    }

    // ------------------------------------------------------------- geometry

    private fun toLocal(l: Layer, x: Float, y: Float): FloatArray {
        val dx = x - l.cx * width
        val dy = y - l.cy * height
        val r = Math.toRadians(-l.rotation.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        return floatArrayOf(dx * c - dy * s, dx * s + dy * c)
    }

    private fun cornerScreen(l: Layer, lx: Float, ly: Float): FloatArray {
        val r = Math.toRadians(l.rotation.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        return floatArrayOf(l.cx * width + lx * c - ly * s, l.cy * height + lx * s + ly * c)
    }

    private fun near(p: FloatArray, x: Float, y: Float): Boolean =
        hypot(p[0] - x, p[1] - y) <= handleR * 1.6f

    private fun hitTest(x: Float, y: Float): Layer? {
        for (i in layers.indices.reversed()) {
            val l = layers[i]
            if (!LayerRenderer.isActive(l, timeMs)) continue
            val box = LayerRenderer.measure(l, width.toFloat(), height.toFloat())
            val p = toLocal(l, x, y)
            if (abs(p[0]) <= box.w / 2f + pad && abs(p[1]) <= box.h / 2f + pad) return l
        }
        return null
    }

    // ---------------------------------------------------------------- touch

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val slop = 6f * density
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                moved = false
                began = false
                mode = Mode.NONE
                active = null

                val sel = selectedActive()
                if (sel != null) {
                    val box = LayerRenderer.measure(sel, width.toFloat(), height.toFloat())
                    val hw = box.w / 2f + pad
                    val hh = box.h / 2f + pad
                    if (near(cornerScreen(sel, -hw, -hh), e.x, e.y)) {
                        mode = Mode.DELETE
                        active = sel
                        return true
                    }
                    if (sel.type == Layer.TEXT && near(cornerScreen(sel, hw, -hh), e.x, e.y)) {
                        mode = Mode.EDIT
                        active = sel
                        return true
                    }
                    if (near(cornerScreen(sel, hw, hh), e.x, e.y)) {
                        mode = Mode.SCALE
                        active = sel
                        val cx = sel.cx * width
                        val cy = sel.cy * height
                        startScale = sel.scale
                        startRot = sel.rotation
                        startDist = max(1f, hypot(e.x - cx, e.y - cy))
                        startAngle = Math.toDegrees(atan2((e.y - cy).toDouble(), (e.x - cx).toDouble())).toFloat()
                        parent?.requestDisallowInterceptTouchEvent(true)
                        return true
                    }
                }

                val hit = hitTest(e.x, e.y)
                if (hit != null) {
                    mode = Mode.DRAG
                    active = hit
                    startCx = hit.cx
                    startCy = hit.cy
                    if (hit.id != selectedId) {
                        selectedId = hit.id
                        listener?.onSelect(hit)
                    }
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                if (selectedId != -1L) {
                    selectedId = -1L
                    listener?.onSelect(null)
                }
                return false
            }

            MotionEvent.ACTION_MOVE -> {
                val l = active ?: return false
                if (!moved && (abs(e.x - downX) > slop || abs(e.y - downY) > slop)) moved = true
                if (!moved) return true
                when (mode) {
                    Mode.DRAG -> {
                        if (!began) {
                            began = true
                            listener?.onBeginChange()
                        }
                        val w = max(1f, width.toFloat())
                        val h = max(1f, height.toFloat())
                        var nx = (startCx + (e.x - downX) / w).coerceIn(0f, 1f)
                        var ny = (startCy + (e.y - downY) / h).coerceIn(0f, 1f)
                        // magnet ke titik tengah kanvas + garis panduan
                        val snapPx = 8f * density
                        val sx = abs(nx - 0.5f) * w < snapPx
                        val sy = abs(ny - 0.5f) * h < snapPx
                        if (sx) nx = 0.5f
                        if (sy) ny = 0.5f
                        if ((sx && !guideV) || (sy && !guideH)) {
                            performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                        }
                        guideV = sx
                        guideH = sy
                        l.cx = nx
                        l.cy = ny
                        invalidate()
                    }
                    Mode.SCALE -> {
                        if (!began) {
                            began = true
                            listener?.onBeginChange()
                        }
                        val cx = l.cx * width
                        val cy = l.cy * height
                        val dist = max(1f, hypot(e.x - cx, e.y - cy))
                        val ang = Math.toDegrees(atan2((e.y - cy).toDouble(), (e.x - cx).toDouble())).toFloat()
                        l.scale = (startScale * dist / startDist).coerceIn(0.15f, 8f)
                        var rot = startRot + (ang - startAngle)
                        // tarik ke sudut lurus bila dekat 0/90/180/270
                        val snapped = Math.round(rot / 90f) * 90f
                        if (abs(rot - snapped) < 3f) rot = snapped
                        l.rotation = rot
                        guideV = abs(l.cx - 0.5f) < 0.0005f
                        guideH = abs(l.cy - 0.5f) < 0.0005f
                        invalidate()
                    }
                    else -> {}
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                val l = active
                if (l != null) {
                    when (mode) {
                        Mode.DELETE -> if (near(cornerFor(l, true), e.x, e.y)) listener?.onDelete(l)
                        Mode.EDIT -> if (near(cornerFor(l, false), e.x, e.y)) listener?.onEdit(l)
                        Mode.DRAG, Mode.SCALE -> if (began) listener?.onEndChange()
                        else -> {}
                    }
                }
                mode = Mode.NONE
                active = null
                guideV = false
                guideH = false
                invalidate()
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                if (began) listener?.onEndChange()
                mode = Mode.NONE
                active = null
                guideV = false
                guideH = false
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    /** Titik pegangan hapus (kiri-atas) atau ubah (kanan-atas) pada layar. */
    private fun cornerFor(l: Layer, deleteHandle: Boolean): FloatArray {
        val box = LayerRenderer.measure(l, width.toFloat(), height.toFloat())
        val hw = box.w / 2f + pad
        val hh = box.h / 2f + pad
        return if (deleteHandle) cornerScreen(l, -hw, -hh) else cornerScreen(l, hw, -hh)
    }

    @Suppress("unused")
    private fun clampMin(a: Float, b: Float) = min(a, b)
}
