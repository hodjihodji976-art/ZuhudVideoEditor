package com.zuhud.videoeditor

import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Animasi masuk / keluar / berulang untuk layer. Dipakai sama oleh preview dan ekspor. */
object LayerAnim {

    val inNames = listOf("Tanpa", "Pudar", "Geser turun", "Geser naik", "Dari kiri", "Dari kanan", "Zoom", "Pop", "Mesin tik", "Putar")
    val outNames = listOf("Tanpa", "Pudar", "Zoom keluar", "Geser turun", "Geser naik", "Ke kiri", "Ke kanan")
    val loopNames = listOf("Tanpa", "Denyut", "Getar", "Melayang", "Kedip", "Goyang", "Berputar")

    class Fx {
        var alpha = 1f
        var tx = 0f      // pecahan lebar kanvas
        var ty = 0f      // pecahan tinggi kanvas
        var scale = 1f
        var rot = 0f     // derajat
        var chars = 1f   // bagian teks yang terlihat (mesin tik)
    }

    val NONE = Fx()

    fun hasAnimation(l: Layer): Boolean = l.animIn > 0 || l.animOut > 0 || l.animLoop > 0

    private fun ease(p: Float): Float {
        val q = 1f - p.coerceIn(0f, 1f)
        return 1f - q * q * q
    }

    fun compute(l: Layer, timeMs: Long): Fx {
        val f = Fx()
        if (!hasAnimation(l)) return f
        val dur = max(100L, min(l.animMs, l.durationMs / 2))
        val t = timeMs - l.startMs

        if (l.animIn > 0 && t in 0 until dur) {
            val p = t.toFloat() / dur
            val e = ease(p)
            when (l.animIn) {
                1 -> f.alpha = e
                2 -> { f.alpha = e; f.ty = -0.12f * (1f - e) }
                3 -> { f.alpha = e; f.ty = 0.12f * (1f - e) }
                4 -> { f.alpha = e; f.tx = -0.15f * (1f - e) }
                5 -> { f.alpha = e; f.tx = 0.15f * (1f - e) }
                6 -> { f.alpha = e; f.scale = 0.3f + 0.7f * e }
                7 -> {
                    f.alpha = min(1f, p * 3f)
                    f.scale = if (p < 0.6f) 1.15f * (p / 0.6f) else 1.15f - 0.15f * ((p - 0.6f) / 0.4f)
                }
                8 -> f.chars = p
                9 -> { f.alpha = e; f.rot = -180f * (1f - e); f.scale = 0.4f + 0.6f * e }
            }
        }

        val remain = l.durationMs - t
        if (l.animOut > 0 && remain in 0 until dur) {
            val q = remain.toFloat() / dur
            val e = ease(q)
            f.alpha *= e
            when (l.animOut) {
                2 -> f.scale *= 0.3f + 0.7f * e
                3 -> f.ty += 0.12f * (1f - e)
                4 -> f.ty -= 0.12f * (1f - e)
                5 -> f.tx -= 0.15f * (1f - e)
                6 -> f.tx += 0.15f * (1f - e)
            }
        }

        if (l.animLoop > 0 && t >= 0) {
            val ph = (t % 1000L) / 1000f
            val ang = (2.0 * PI * ph).toFloat()
            when (l.animLoop) {
                1 -> f.scale *= 1f + 0.06f * sin(ang)
                2 -> f.tx += 0.008f * sin(ang * 6f)
                3 -> f.ty += 0.015f * sin(ang)
                4 -> f.alpha *= if (ph < 0.5f) 1f else 0.25f
                5 -> f.rot += 6f * sin(ang)
                6 -> f.rot += 360f * ph
            }
        }
        return f
    }
}
