package com.zuhud.videoeditor

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Memilih video/foto dari tiga sumber:
 *  1. Galeri (pemilih foto & video sistem)
 *  2. Berkas / ZArchiver / penyimpanan (Storage Access Framework)
 *  3. Aplikasi lain (ACTION_GET_CONTENT: Google Foto, pengelola berkas, dll.)
 * Harus dibuat sebagai properti Activity (sebelum STARTED).
 */
class MediaSources(
    private val act: AppCompatActivity,
    private val onUris: (List<Uri>) -> Unit
) {
    private val gallery =
        act.registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { onUris(it) }
    private val files =
        act.registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { onUris(it) }
    private val other =
        act.registerForActivityResult(GetMany()) { onUris(it) }

    /** mimes: jenis yang diizinkan, mis. arrayOf("video/*", "image/*"). */
    fun launch(mimes: Array<String> = arrayOf("video/*", "image/*")) {
        val labels = arrayOf(
            "Galeri (foto & video)",
            "Berkas / ZArchiver / penyimpanan",
            "Aplikasi lain (Google Foto, dll.)"
        )
        AlertDialog.Builder(act, R.style.ZuhudDialog)
            .setTitle("Pilih dari")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> {
                        val hasImage = mimes.any { it.startsWith("image") }
                        val hasVideo = mimes.any { it.startsWith("video") }
                        val type = when {
                            hasImage && !hasVideo -> ActivityResultContracts.PickVisualMedia.ImageOnly
                            hasVideo && !hasImage -> ActivityResultContracts.PickVisualMedia.VideoOnly
                            else -> ActivityResultContracts.PickVisualMedia.ImageAndVideo
                        }
                        gallery.launch(PickVisualMediaRequest(type))
                    }
                    1 -> files.launch(mimes)
                    else -> other.launch(mimes)
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private class GetMany : ActivityResultContract<Array<String>, List<Uri>>() {
        override fun createIntent(context: Context, input: Array<String>): Intent {
            val i = Intent(Intent.ACTION_GET_CONTENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
                .putExtra(Intent.EXTRA_MIME_TYPES, input)
                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            return Intent.createChooser(i, "Pilih media")
        }

        override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> {
            if (resultCode != Activity.RESULT_OK || intent == null) return emptyList()
            val out = ArrayList<Uri>()
            val cd = intent.clipData
            if (cd != null) {
                for (k in 0 until cd.itemCount) {
                    val u = cd.getItemAt(k).uri
                    if (u != null) out.add(u)
                }
            }
            if (out.isEmpty()) intent.data?.let { out.add(it) }
            return out
        }
    }
}
