package com.zuhud.videoeditor

import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.ScaleGestureDetector
import android.view.Window
import android.widget.BaseAdapter
import android.widget.ListView
import java.io.File
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.MotionEvent
import android.view.TextureView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.GridLayout
import android.widget.SeekBar
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONObject
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class EditorActivity : AppCompatActivity() {

    private val project: Project get() = ProjectStore.current
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newFixedThreadPool(2)

    private lateinit var player: ExoPlayer
    private lateinit var audioPlayer: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var previewBox: FrameLayout
    private lateinit var canvasBox: FrameLayout
    private lateinit var layerOverlay: LayerOverlayView
    private lateinit var cropOverlay: CropOverlayView
    private lateinit var timeline: TimelineView
    private lateinit var toolbar: LinearLayout
    private lateinit var btnPlay: ImageView
    private lateinit var btnUndo: ImageView
    private lateinit var btnRedo: ImageView
    private lateinit var btnRatio: TextView
    private lateinit var txtTime: TextView

    private lateinit var previewImage: ImageView
    private lateinit var fadeCover: View
    private val filterPaint = Paint()
    private var shownImageUri: Uri? = null
    private var videoLeft = 0
    private var videoTop = 0

    private class LayerVideo(val player: ExoPlayer, val view: PlayerView)

    private val layerVideos = HashMap<Long, LayerVideo>()

    private var canvasW = 0f
    private var canvasH = 0f

    private var cropMode = false
    private var cropIndex = -1

    private val undoStack = ArrayList<String>()
    private val redoStack = ArrayList<String>()

    private var exporter: Exporter? = null
    private var exportDialog: AlertDialog? = null

    // ---------------------------------------------------------------- picker

    private val pickMoreVideos = MediaSources(this) { uris ->
        if (uris.isNotEmpty()) addVideos(uris)
    }

    private val pickAudio =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                MediaUtil.keepAccess(this, uri)
                io.execute {
                    val t = MediaUtil.probeAudio(this, uri)
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        if (t == null) toast("Berkas audio tidak dapat dibaca") else setAudio(t)
                    }
                }
            }
        }

    /** Foto atau video sebagai layer (PiP): jenisnya dikenali otomatis. */
    private val pickImage = MediaSources(this) { uris ->
        val first = uris.firstOrNull()
        if (first != null) {
            io.execute {
                val uri = MediaUtil.ensureAccess(this, first)
                run {
                    if (MediaUtil.isImage(this, uri)) {
                        val bmp = LayerRenderer.bitmapFor(uri)
                        runOnUiThread {
                            if (isFinishing || isDestroyed) return@runOnUiThread
                            if (bmp == null) toast("Gambar tidak dapat dibaca") else addImageLayer(uri)
                        }
                    } else {
                        val clip = MediaUtil.probeVideo(this, uri)
                        runOnUiThread {
                            if (isFinishing || isDestroyed) return@runOnUiThread
                            if (clip == null) toast("Video tidak dapat dibaca") else addVideoLayer(clip)
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LayerRenderer.init(this)
        if (project.clips.isEmpty()) {
            finish()
            return
        }
        setContentView(R.layout.activity_editor)

        playerView = findViewById(R.id.playerView)
        previewBox = findViewById(R.id.previewBox)
        canvasBox = findViewById(R.id.canvasBox)
        layerOverlay = findViewById(R.id.layerOverlay)
        cropOverlay = findViewById(R.id.cropOverlay)
        timeline = findViewById(R.id.timeline)
        toolbar = findViewById(R.id.toolbar)
        btnPlay = findViewById(R.id.btnPlay)
        btnUndo = findViewById(R.id.btnUndo)
        btnRedo = findViewById(R.id.btnRedo)
        btnRatio = findViewById(R.id.btnRatio)
        txtTime = findViewById(R.id.txtTime)
        findViewById<TextView>(R.id.txtTitle).text = project.name

        previewImage = ImageView(this)
        previewImage.scaleType = ImageView.ScaleType.FIT_XY
        previewImage.visibility = View.GONE
        canvasBox.addView(previewImage, 1)
        fadeCover = View(this)
        fadeCover.alpha = 0f
        canvasBox.addView(
            fadeCover, 2,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        audioPlayer = ExoPlayer.Builder(this).build()
        audioPlayer.repeatMode = Player.REPEAT_MODE_ALL

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                if (project.audio != null) {
                    if (isPlaying) {
                        seekAudio(currentTimelineMs())
                        audioPlayer.play()
                    } else {
                        audioPlayer.pause()
                    }
                }
                if (isPlaying) handler.post(tick)
                syncLayerVideos()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                applySpeed()
                if (!cropMode) layoutVideo(project.clips.getOrNull(player.currentMediaItemIndex))
                applyPreviewFx()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    audioPlayer.pause()
                    player.seekTo(0, 0L)
                    player.pause()
                    applySpeed()
                    updateUi()
                }
            }
        })

        previewBox.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) relayoutCanvas()
        }

        findViewById<View>(R.id.btnBack).setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        findViewById<View>(R.id.btnExport).setOnClickListener { showExportDialog() }
        btnRatio.setOnClickListener { showAspectDialog() }
        btnPlay.setOnClickListener { togglePlay() }
        btnUndo.setOnClickListener { undo() }
        btnRedo.setOnClickListener { redo() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    cropMode -> exitCrop()
                    timeline.selKind != TimelineView.NONE -> timeline.select(TimelineView.NONE, -1L)
                    else -> finish()
                }
            }
        })

        timeline.listener = object : TimelineView.Listener {
            override fun onScrub(ms: Long) {
                if (player.isPlaying) player.pause()
                seekToTimeline(ms)
                layerOverlay.timeMs = ms
                updateTimeLabel(ms)
                applyPreviewFx()
            }

            override fun onSelect(kind: Int, id: Long) {
                layerOverlay.selectedId = if (kind == TimelineView.LAYER) id else -1L
                refreshTools()
            }

            override fun onBeginEdit() {
                player.pause()
                pushUndo()
            }

            override fun onEditing() {
                updateTimeLabel(timeline.timeMs)
                layerOverlay.timeMs = timeline.timeMs
            }

            override fun onEndEdit(clipChanged: Boolean) {
                if (clipChanged) afterEdit(timeline.timeMs) else {
                    layerOverlay.invalidate()
                    save()
                }
            }

            override fun onAdd() {
                pickMoreVideos.launch()
            }
        }

        layerOverlay.listener = object : LayerOverlayView.Listener {
            override fun onSelect(layer: Layer?) {
                if (layer == null) timeline.select(TimelineView.NONE, -1L)
                else timeline.select(TimelineView.LAYER, layer.id)
            }

            override fun onEdit(layer: Layer) {
                showTextEditor(layer)
            }

            override fun onDelete(layer: Layer) {
                deleteLayer(layer)
            }

            override fun onBeginChange() {
                player.pause()
                pushUndo()
            }

            override fun onEndChange() {
                timeline.invalidate()
                save()
            }
        }

        layerOverlay.onDrawHook = { updateLayerGeometry() }
        previewBox.setOnTouchListener { _, e -> handlePreviewTouch(e) }
        io.execute { Fonts.systemFonts() }

        applyAll(0L)
        previewBox.post { relayoutCanvas() }
    }

    override fun onResume() {
        super.onResume()
        if (!::player.isInitialized) return
        // Musik hasil Meta Sound Collection yang menunggu diimpor.
        fontPanelRefresh?.invoke()
        ProjectStore.pendingAudio?.let {
            ProjectStore.pendingAudio = null
            setAudio(it)
        }
    }

    override fun onPause() {
        super.onPause()
        if (::player.isInitialized) {
            player.pause()
            audioPlayer.pause()
            for (lv in layerVideos.values) lv.player.pause()
            save()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        exporter?.cancel()
        exportDialog?.dismiss()
        io.shutdownNow()
        if (::player.isInitialized) {
            playerView.player = null
            player.release()
            audioPlayer.release()
            for (lv in layerVideos.values) {
                lv.view.player = null
                lv.player.release()
            }
            layerVideos.clear()
        }
    }

    private fun save() {
        ProjectStore.save(this, project)
    }

    // -------------------------------------------------------------- playback

    private val tick = object : Runnable {
        override fun run() {
            updateUi()
            if (player.isPlaying) handler.postDelayed(this, 33)
        }
    }

    private fun togglePlay() {
        if (cropMode) return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (currentTimelineMs() >= project.totalMs - 50) seekToTimeline(0L)
            player.play()
        }
    }

    private fun applySpeed() {
        val c = project.clips.getOrNull(player.currentMediaItemIndex) ?: return
        player.playbackParameters = PlaybackParameters(c.speed, 1f)
        applyVolumes()
    }

    /** Preview hanya bisa meredam (maks 100%); penguatan >100% terdengar pada hasil ekspor. */
    private fun applyVolumes() {
        player.volume = if (project.muteOriginal) 0f else min(1f, project.videoVolume)
        audioPlayer.volume = min(1f, project.audioVolume)
    }

    private fun currentTimelineMs(): Long {
        val clips = project.clips
        if (clips.isEmpty()) return 0L
        val i = player.currentMediaItemIndex.coerceIn(0, clips.size - 1)
        var before = 0L
        for (k in 0 until i) before += clips[k].effectiveMs
        val within = (player.currentPosition / clips[i].speed).toLong().coerceIn(0L, clips[i].effectiveMs)
        return before + within
    }

    private fun seekToTimeline(ms: Long) {
        val clips = project.clips
        if (clips.isEmpty()) return
        var rest = ms.coerceIn(0L, project.totalMs)
        var idx = clips.size - 1
        var offset = clips[idx].effectiveMs
        for ((i, c) in clips.withIndex()) {
            if (rest < c.effectiveMs) {
                idx = i
                offset = rest
                break
            }
            rest -= c.effectiveMs
        }
        player.seekTo(idx, (offset * clips[idx].speed).toLong())
        player.playbackParameters = PlaybackParameters(clips[idx].speed, 1f)
        applyVolumes()
        if (!cropMode) layoutVideo(clips[idx])
        seekAudio(ms)
    }

    private fun seekAudio(timelineMs: Long) {
        val a = project.audio ?: return
        if (a.durationMs > 0) audioPlayer.seekTo(timelineMs % a.durationMs)
    }

    /** Memuat ulang daftar klip ke pemutar setelah struktur proyek berubah. */
    private fun reloadPlayer(keepMs: Long) {
        val items = project.clips.map { c ->
            val b = MediaItem.Builder().setUri(c.uri)
            if (c.isImage) {
                b.setImageDurationMs(c.endMs - c.startMs)
            } else {
                b.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.startMs)
                        .setEndPositionMs(c.endMs)
                        .build()
                )
            }
            b.build()
        }
        player.setMediaItems(items)
        player.prepare()
        seekToTimeline(keepMs)
    }

    private fun syncAudioPlayer() {
        val a = project.audio
        audioPlayer.stop()
        audioPlayer.clearMediaItems()
        if (a != null) {
            audioPlayer.setMediaItem(MediaItem.fromUri(a.uri))
            audioPlayer.prepare()
        }
        applyVolumes()
    }

    private fun updateTimeLabel(pos: Long) {
        txtTime.text = "${MediaUtil.formatTime(pos)} / ${MediaUtil.formatTime(project.totalMs)}"
    }

    private fun updateUi() {
        val pos = currentTimelineMs()
        timeline.setTime(pos)
        layerOverlay.timeMs = pos
        updateTimeLabel(pos)
        applyPreviewFx()
    }

    /** Animasi transisi di preview: transformasi view video/foto + penutup warna untuk pudar. */
    private fun applyPreviewFx() {
        if (!::previewImage.isInitialized) return
        val c = if (cropMode) null else project.clips.getOrNull(player.currentMediaItemIndex)
        var fx: Transitions.Fx? = null
        if (c != null && c.transition in 1..Transitions.names.size) {
            val dur = Transitions.durationMs(c.effectiveMs)
            val local = (player.currentPosition / c.speed).toLong()
            if (dur > 0 && local in 0 until dur) fx = Transitions.fx(c.transition, local.toFloat() / dur)
        }
        for (v in listOf<View>(playerView, previewImage)) {
            v.pivotX = canvasW / 2f - videoLeft
            v.pivotY = canvasH / 2f - videoTop
            if (fx == null) {
                v.scaleX = 1f
                v.scaleY = 1f
                v.rotation = 0f
                v.translationX = 0f
                v.translationY = 0f
            } else {
                v.scaleX = fx.scale
                v.scaleY = fx.scale
                v.rotation = fx.rot
                v.translationX = fx.tx * canvasW
                v.translationY = fx.ty * canvasH
            }
        }
        if (fx != null && fx.overlayAlpha > 0f) {
            fadeCover.setBackgroundColor(if (fx.white) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())
            fadeCover.alpha = fx.overlayAlpha
        } else {
            fadeCover.alpha = 0f
        }
        syncLayerVideos()
    }

    private fun applyPreviewFilter(c: Clip?) {
        val m = if (cropMode) null else Filters.previewMatrix(c?.filter ?: 0)
        val tv = playerView.videoSurfaceView as? TextureView
        if (m == null) {
            tv?.setLayerPaint(null)
            previewImage.colorFilter = null
        } else {
            val f: ColorFilter = ColorMatrixColorFilter(m)
            filterPaint.colorFilter = f
            tv?.setLayerPaint(filterPaint)
            previewImage.colorFilter = f
        }
    }

    // ---------------------------------------------------------------- kanvas

    private fun cropClip(): Clip? = if (cropMode) project.clips.getOrNull(cropIndex) else null

    /** Menghitung ukuran kanvas (sesuai rasio) di dalam area preview. */
    private fun relayoutCanvas() {
        val bw = previewBox.width.toFloat()
        val bh = previewBox.height.toFloat()
        if (bw <= 0f || bh <= 0f) return
        val cc = cropClip()
        val aspect = if (cc != null) cc.width.toFloat() / cc.height else project.canvasAspect()
        val pad = dp(10).toFloat()
        var w = bw - 2f * pad
        var h = w / aspect
        if (h > bh - 2f * pad) {
            h = bh - 2f * pad
            w = h * aspect
        }
        w = max(w, 20f)
        h = max(h, 20f)
        canvasW = w
        canvasH = h
        canvasBox.layoutParams = FrameLayout.LayoutParams(w.toInt(), h.toInt(), Gravity.CENTER)
        layoutVideo(cc ?: project.clips.getOrNull(player.currentMediaItemIndex))
    }

    /**
     * Menempatkan tampilan video di dalam kanvas sehingga area pangkas (crop) tepat
     * memenuhi/muat di kanvas. Rumus ini sama dengan yang dipakai saat ekspor.
     */
    private fun layoutVideo(c: Clip?) {
        if (c == null || canvasW <= 0f || canvasH <= 0f) return
        val l = if (cropMode) 0f else c.cropL
        val t = if (cropMode) 0f else c.cropT
        val r = if (cropMode) 0f else c.cropR
        val b = if (cropMode) 0f else c.cropB
        val cwp = c.width * (1f - l - r)
        val chp = c.height * (1f - t - b)
        val s = if (project.fillMode && !cropMode) max(canvasW / cwp, canvasH / chp)
        else min(canvasW / cwp, canvasH / chp)
        val z = if (cropMode) 1f else c.zoom
        val px = if (cropMode) 0f else c.panX
        val py = if (cropMode) 0f else c.panY
        val vw = (c.width * s * z).toInt()
        val vh = (c.height * s * z).toInt()
        val cxv = c.width * (l + (1f - l - r) / 2f)
        val cyv = c.height * (t + (1f - t - b) / 2f)
        val lp = FrameLayout.LayoutParams(max(2, vw), max(2, vh), Gravity.TOP or Gravity.START)
        lp.leftMargin = (canvasW / 2f + px * canvasW - cxv * s * z).toInt()
        lp.topMargin = (canvasH / 2f + py * canvasH - cyv * s * z).toInt()
        playerView.layoutParams = lp
        previewImage.layoutParams = FrameLayout.LayoutParams(lp)
        videoLeft = lp.leftMargin
        videoTop = lp.topMargin
        if (c.isImage) {
            previewImage.visibility = View.VISIBLE
            playerView.visibility = View.INVISIBLE
            if (shownImageUri != c.uri) {
                previewImage.setImageBitmap(LayerRenderer.bitmapFor(c.uri))
                shownImageUri = c.uri
            }
        } else {
            previewImage.visibility = View.GONE
            playerView.visibility = View.VISIBLE
        }
        applyPreviewFilter(c)
    }

    private fun updateRatioLabel() {
        btnRatio.text = if (project.aspectW > 0) "${project.aspectW}:${project.aspectH}" else "Asli"
    }

    // ------------------------------------------------------- perubahan proyek

    private fun snapshot(): String = ProjectJson.toJson(project).toString()

    private fun pushUndo() {
        undoStack.add(snapshot())
        if (undoStack.size > 40) undoStack.removeAt(0)
        redoStack.clear()
        updateUndoButtons()
    }

    private fun updateUndoButtons() {
        btnUndo.alpha = if (undoStack.isEmpty()) 0.35f else 1f
        btnRedo.alpha = if (redoStack.isEmpty()) 0.35f else 1f
    }

    private fun undo() {
        if (undoStack.isEmpty() || cropMode) return
        redoStack.add(snapshot())
        restore(undoStack.removeAt(undoStack.size - 1))
    }

    private fun redo() {
        if (redoStack.isEmpty() || cropMode) return
        undoStack.add(snapshot())
        restore(redoStack.removeAt(redoStack.size - 1))
    }

    private fun restore(json: String) {
        player.pause()
        val keep = timeline.timeMs
        try {
            ProjectStore.current = ProjectJson.fromJson(JSONObject(json))
        } catch (e: Exception) {
            toast("Gagal memulihkan")
            return
        }
        timeline.select(TimelineView.NONE, -1L)
        applyAll(keep)
        updateUndoButtons()
    }

    /** Memuat ulang semua tampilan dari proyek. */
    private fun applyAll(keepMs: Long) {
        syncAudioPlayer()
        reloadPlayer(min(keepMs, project.totalMs))
        rebuildLayerVideos()
        relayoutCanvas()
        timeline.refresh()
        updateRatioLabel()
        updateUndoButtons()
        refreshTools()
        ensureThumbs()
        updateUi()
    }

    /** Dipanggil setelah proyek diubah. */
    private fun afterEdit(keepMs: Long) {
        player.pause()
        reloadPlayer(min(keepMs, project.totalMs))
        rebuildLayerVideos()
        relayoutCanvas()
        timeline.refresh()
        layerOverlay.invalidate()
        updateRatioLabel()
        refreshTools()
        ensureThumbs()
        updateUi()
        save()
    }

    private fun ensureThumbs() {
        for (c in project.clips) {
            val key = c.uri.toString()
            if (timeline.thumbs.containsKey(key)) continue
            val uri = c.uri
            val at = c.startMs
            io.execute {
                val bmp = MediaUtil.thumbnail(this, uri, at) ?: return@execute
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    timeline.thumbs[key] = bmp
                    timeline.invalidate()
                }
            }
        }
    }

    // --------------------------------------------------------------- toolbar

    private class Tool(val icon: Int, val label: String, val onClick: () -> Unit)

    private fun refreshTools() {
        val tools = when {
            cropMode -> cropTools()
            timeline.selKind == TimelineView.CLIP -> clipTools()
            timeline.selKind == TimelineView.LAYER -> layerTools()
            timeline.selKind == TimelineView.AUDIO -> audioTools()
            else -> mainTools()
        }
        toolbar.removeAllViews()
        for (t in tools) toolbar.addView(toolView(t))
    }

    private fun toolView(t: Tool): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
                val img = ImageView(this)
        img.setImageResource(t.icon)
        box.addView(img, LinearLayout.LayoutParams(dp(24), dp(24)))
        val tv = TextView(this)
        tv.text = t.label
        tv.setTextColor(0xFFE6E6F0.toInt())
        tv.textSize = 11f
        tv.maxLines = 1
        tv.gravity = Gravity.CENTER
        tv.setPadding(0, dp(4), 0, 0)
        box.addView(tv)
        box.setOnClickListener { t.onClick() }
        box.layoutParams = LinearLayout.LayoutParams(dp(74), ViewGroup.LayoutParams.MATCH_PARENT)
        return box
    }

    private fun backTool() = Tool(R.drawable.ic_back, "Kembali") {
        timeline.select(TimelineView.NONE, -1L)
    }

    private fun mainTools(): List<Tool> = listOf(
        Tool(R.drawable.ic_add, "Video/Foto") { pickMoreVideos.launch() },
        Tool(R.drawable.ic_audio, "Audio") { showAudioDialog() },
        Tool(R.drawable.ic_add, "Layer") { showLayerMenu() },
        Tool(R.drawable.ic_text, "Teks") { showTextEditor(null) },
        Tool(R.drawable.ic_sticker, "Stiker") { showStickerPicker() },
        Tool(R.drawable.ic_image, "Foto/Video PiP") { pickImage.launch(arrayOf("image/*", "video/*")) },
        Tool(R.drawable.ic_volume, "Volume") { showVolumeDialog() },
        Tool(R.drawable.ic_aspect, "Rasio") { showAspectDialog() },
        Tool(R.drawable.ic_fill, if (project.fillMode) "Mode muat" else "Isi layar") {
            pushUndo()
            project.fillMode = !project.fillMode
            afterEdit(timeline.timeMs)
        }
    )

    private fun clipTools(): List<Tool> {
        val i = timeline.selId.toInt()
        val isImg = project.clips.getOrNull(i)?.isImage == true
        val list = ArrayList<Tool>()
        list.add(backTool())
        list.add(Tool(R.drawable.ic_split, "Bagi") { splitAtPlayhead() })
        if (!isImg) list.add(Tool(R.drawable.ic_speed, "Kecepatan") { showSpeedDialog(i) })
        list.add(Tool(R.drawable.ic_transition, "Transisi") { showTransitionDialog(i) })
        list.add(Tool(R.drawable.ic_filter, "Filter") { showFilterDialog(i) })
        if (!isImg) list.add(Tool(R.drawable.ic_volume, "Volume") { showVolumeDialog() })
        list.add(Tool(R.drawable.ic_crop, "Pangkas") { enterCrop(i) })
        val cz = project.clips.getOrNull(i)
        if (cz != null && (cz.zoom != 1f || cz.panX != 0f || cz.panY != 0f)) {
            list.add(Tool(R.drawable.ic_aspect, "Reset zoom") { resetZoom(i) })
        }
        list.add(Tool(R.drawable.ic_back, "Mundur") { moveClip(i, -1) })
        list.add(Tool(R.drawable.ic_forward, "Maju") { moveClip(i, 1) })
        list.add(Tool(R.drawable.ic_copy, "Duplikat") { duplicateClip(i) })
        list.add(Tool(R.drawable.ic_delete, "Hapus") { deleteClip(i) })
        return list
    }

    private fun layerTools(): List<Tool> {
        val l = project.layers.firstOrNull { it.id == timeline.selId }
            ?: return listOf(backTool())
        val list = ArrayList<Tool>()
        list.add(backTool())
        if (l.type == Layer.TEXT) {
            list.add(Tool(R.drawable.ic_edit, "Edit") { showTextPanel(l, 1, true) })
            list.add(Tool(R.drawable.ic_font, "Font") { showTextPanel(l, 0, true) })
            list.add(Tool(R.drawable.ic_palette, "Efek") { showTextPanel(l, 2, true) })
            list.add(Tool(R.drawable.ic_transition, "Animasi") { showTextPanel(l, 3, true) })
        }
        if (l.type == Layer.VIDEO) {
            list.add(Tool(R.drawable.ic_volume, "Volume") { showLayerVolumeDialog(l) })
        }
        if (l.type == Layer.IMAGE || l.type == Layer.STICKER) {
            list.add(Tool(R.drawable.ic_transition, "Animasi") { showAnimDialog(l) })
        }
        if (l.type == Layer.IMAGE) {
            list.add(Tool(R.drawable.ic_eraser, "Kroma/Latar") { showChromaDialog(l) })
        }
        if (l.type == Layer.STICKER && !l.text.startsWith("e:")) {
            list.add(Tool(R.drawable.ic_palette, "Warna") { showColorDialog(l) })
        }
        list.add(Tool(R.drawable.ic_copy, "Duplikat") { duplicateLayer(l) })
        list.add(Tool(R.drawable.ic_delete, "Hapus") { deleteLayer(l) })
        return list
    }

    private fun audioTools(): List<Tool> = listOf(
        backTool(),
        Tool(R.drawable.ic_swap, "Ganti") { pickAudio.launch(arrayOf("audio/*")) },
        Tool(R.drawable.ic_volume, "Volume") { showVolumeDialog() },
        Tool(R.drawable.ic_mute, if (project.muteOriginal) "Suara asli" else "Bisukan asli") {
            pushUndo()
            project.muteOriginal = !project.muteOriginal
            applySpeed()
            refreshTools()
            save()
            toast(if (project.muteOriginal) "Suara asli video dimatikan" else "Suara asli video dinyalakan")
        },
        Tool(R.drawable.ic_delete, "Hapus") {
            pushUndo()
            project.audio = null
            timeline.select(TimelineView.NONE, -1L)
            syncAudioPlayer()
            afterEdit(timeline.timeMs)
        }
    )

    private fun cropTools(): List<Tool> = listOf(
        Tool(R.drawable.ic_close, "Batal") { exitCrop() },
        Tool(R.drawable.ic_crop, "Bebas") { cropOverlay.setRatio(0f) },
        Tool(R.drawable.ic_crop, "1:1") { cropOverlay.setRatio(1f) },
        Tool(R.drawable.ic_crop, "9:16") { cropOverlay.setRatio(9f / 16f) },
        Tool(R.drawable.ic_crop, "16:9") { cropOverlay.setRatio(16f / 9f) },
        Tool(R.drawable.ic_crop, "4:3") { cropOverlay.setRatio(4f / 3f) },
        Tool(R.drawable.ic_crop, "3:4") { cropOverlay.setRatio(3f / 4f) },
        Tool(R.drawable.ic_crop, "Reset") {
            cropOverlay.reset()
        },
        Tool(R.drawable.ic_check, "Terapkan") { applyCrop() }
    )

    // ------------------------------------------------------------ aksi klip

    private fun addVideos(uris: List<Uri>) {
        toast("Memuat…")
        io.execute {
            val clips = uris.mapNotNull { u ->
                MediaUtil.probeMedia(this, MediaUtil.ensureAccess(this, u))
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (clips.isEmpty()) {
                    toast("Video/foto tidak dapat dibaca")
                } else {
                    pushUndo()
                    val pos = currentTimelineMs()
                    project.clips.addAll(clips)
                    afterEdit(pos)
                }
            }
        }
    }

    /** Membagi klip di posisi garis putar (tepat di tengah timeline). */
    private fun splitAtPlayhead() {
        val pos = currentTimelineMs()
        var before = 0L
        for ((i, c) in project.clips.withIndex()) {
            val len = c.effectiveMs
            if (pos < before + len || i == project.clips.size - 1) {
                val offset = (pos - before).coerceIn(0L, len)
                val src = c.startMs + (offset * c.speed).toLong()
                if (src - c.startMs < 300L || c.endMs - src < 300L) {
                    toast("Geser garis putar ke bagian tengah klip lalu tekan Bagi")
                    return
                }
                pushUndo()
                val a = c.copy(endMs = src)
                val b = c.copy(startMs = src)
                project.clips.removeAt(i)
                project.clips.add(i, b)
                project.clips.add(i, a)
                timeline.select(TimelineView.CLIP, i.toLong())
                afterEdit(pos)
                return
            }
            before += len
        }
    }

    private fun showSpeedDialog(index: Int) {
        val c = project.clips.getOrNull(index) ?: return
        val options = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
        val names = options.map { "${it}x" + if (it == c.speed) "  ✓" else "" }.toTypedArray()
        dialog().setTitle("Kecepatan klip")
            .setItems(names) { _, which ->
                pushUndo()
                val pos = currentTimelineMs()
                c.speed = options[which]
                afterEdit(min(pos, project.totalMs))
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun moveClip(i: Int, delta: Int) {
        val j = i + delta
        if (i !in project.clips.indices || j !in project.clips.indices) return
        pushUndo()
        val c = project.clips.removeAt(i)
        project.clips.add(j, c)
        timeline.select(TimelineView.CLIP, j.toLong())
        afterEdit(timeline.timeMs)
    }

    private fun duplicateClip(i: Int) {
        val c = project.clips.getOrNull(i) ?: return
        pushUndo()
        project.clips.add(i + 1, c.copy())
        timeline.select(TimelineView.CLIP, (i + 1).toLong())
        afterEdit(timeline.timeMs)
    }

    private fun deleteClip(i: Int) {
        if (project.clips.size <= 1) {
            toast("Proyek minimal memiliki satu klip")
            return
        }
        if (i !in project.clips.indices) return
        pushUndo()
        project.clips.removeAt(i)
        timeline.select(TimelineView.NONE, -1L)
        afterEdit(timeline.timeMs)
    }

    // ---------------------------------------------------------------- pangkas

    private fun enterCrop(i: Int) {
        val c = project.clips.getOrNull(i) ?: return
        player.pause()
        cropMode = true
        cropIndex = i
        var start = 0L
        for (k in 0 until i) start += project.clips[k].effectiveMs
        seekToTimeline(start + 20L)
        layerOverlay.visibility = View.GONE
        syncLayerVideos()
        cropOverlay.visibility = View.VISIBLE
        cropOverlay.setSource(c.width, c.height)
        cropOverlay.setRatio(0f)
        cropOverlay.setRect(c.cropL, c.cropT, 1f - c.cropR, 1f - c.cropB)
        relayoutCanvas()
        refreshTools()
    }

    private fun exitCrop() {
        cropMode = false
        cropIndex = -1
        syncLayerVideos()
        cropOverlay.visibility = View.GONE
        layerOverlay.visibility = View.VISIBLE
        relayoutCanvas()
        refreshTools()
    }

    private fun applyCrop() {
        val c = project.clips.getOrNull(cropIndex)
        if (c == null) {
            exitCrop()
            return
        }
        pushUndo()
        val l = cropOverlay.fLeft
        val t = cropOverlay.fTop
        val r = 1f - cropOverlay.fRight
        val b = 1f - cropOverlay.fBottom
        c.cropL = if (l < 0.005f) 0f else l
        c.cropT = if (t < 0.005f) 0f else t
        c.cropR = if (r < 0.005f) 0f else r
        c.cropB = if (b < 0.005f) 0f else b
        val pos = timeline.timeMs
        cropMode = false
        cropIndex = -1
        cropOverlay.visibility = View.GONE
        layerOverlay.visibility = View.VISIBLE
        afterEdit(pos)
    }

    // ------------------------------------------------------------------ layer

    private fun defaultTiming(): Pair<Long, Long> {
        val total = project.totalMs
        val pos = timeline.timeMs
        val dur = min(3000L, max(500L, total))
        val start = if (pos + dur > total) max(0L, total - dur) else pos
        return start to dur
    }

    private fun addImageLayer(uri: Uri) {
        pushUndo()
        val (start, dur) = defaultTiming()
        val l = Layer(project.nextLayerId(), Layer.IMAGE, uri = uri, startMs = start, durationMs = dur)
        project.layers.add(l)
        afterEdit(timeline.timeMs)
        timeline.select(TimelineView.LAYER, l.id)
    }

    private fun duplicateLayer(l: Layer) {
        pushUndo()
        val copy = l.copy(
            id = project.nextLayerId(),
            cx = (l.cx + 0.06f).coerceAtMost(0.95f),
            cy = (l.cy + 0.06f).coerceAtMost(0.95f)
        )
        project.layers.add(copy)
        afterEdit(timeline.timeMs)
        timeline.select(TimelineView.LAYER, copy.id)
    }

    private fun deleteLayer(l: Layer) {
        pushUndo()
        project.layers.removeAll { it.id == l.id }
        timeline.select(TimelineView.NONE, -1L)
        afterEdit(timeline.timeMs)
    }

    private val swatches = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFD400.toInt(), 0xFFFF3B30.toInt(),
        0xFFFF9500.toInt(), 0xFF34C759.toInt(), 0xFF19B4FF.toInt(), 0xFF3B5BFF.toInt(),
        0xFFFF2BD6.toInt(), 0xFFC6FF1A.toInt()
    )

    private fun swatchRow(initial: Int, onPick: (Int) -> Unit): View {
        val scroll = android.widget.HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(6), 0, dp(6))
        val views = ArrayList<View>()
        for (col in swatches) {
            val v = View(this)
            val gd = GradientDrawable()
            gd.shape = GradientDrawable.OVAL
            gd.setColor(col)
            gd.setStroke(dp(if (col == initial) 3 else 1), if (col == initial) 0xFF19D3E6.toInt() else 0x66FFFFFF)
            v.background = gd
            val lp = LinearLayout.LayoutParams(dp(34), dp(34))
            lp.marginEnd = dp(10)
            v.setOnClickListener {
                onPick(col)
                for ((k, other) in views.withIndex()) {
                    val g = GradientDrawable()
                    g.shape = GradientDrawable.OVAL
                    g.setColor(swatches[k])
                    val sel = swatches[k] == col
                    g.setStroke(dp(if (sel) 3 else 1), if (sel) 0xFF19D3E6.toInt() else 0x66FFFFFF)
                    other.background = g
                }
            }
            views.add(v)
            row.addView(v, lp)
        }
        scroll.addView(row)
        return scroll
    }

    @Suppress("unused")
    private fun legacyTextEditor(existing: Layer?) {
        var chosen = existing?.color ?: 0xFFFFFFFF.toInt()
        var chosenFont = existing?.font ?: 0
        val edit = EditText(this)
        edit.setText(existing?.text ?: "")
        edit.setTextColor(0xFFFFFFFF.toInt())
        edit.hint = "Tulis teks"
        edit.setHintTextColor(0xFF888888.toInt())
        edit.minLines = 2
        edit.gravity = Gravity.TOP or Gravity.START

        edit.typeface = Fonts.get(chosenFont).typeface

        val fontBtn = TextView(this)
        fontBtn.text = "Font: " + Fonts.get(chosenFont).name + "   ▾"
        fontBtn.setTextColor(0xFF19D3E6.toInt())
        fontBtn.textSize = 15f
        fontBtn.setPadding(0, dp(12), 0, dp(12))
        fontBtn.setOnClickListener {
            showFontDialog(chosenFont) { f ->
                chosenFont = f
                fontBtn.text = "Font: " + Fonts.get(f).name + "   ▾"
                edit.typeface = Fonts.get(f).typeface
            }
        }

        val box = column()
        box.addView(edit)
        box.addView(fontBtn)
        box.addView(label("Warna"))
        box.addView(swatchRow(chosen) { chosen = it })

        dialog().setTitle(if (existing == null) "Tambah teks" else "Ubah teks")
            .setView(box)
            .setPositiveButton("Selesai") { _, _ ->
                val txt = edit.text.toString().trim()
                if (txt.isEmpty()) {
                    toast("Teks kosong")
                    return@setPositiveButton
                }
                pushUndo()
                if (existing == null) {
                    val (start, dur) = defaultTiming()
                    val l = Layer(
                        project.nextLayerId(), Layer.TEXT, text = txt, color = chosen,
                        startMs = start, durationMs = dur, font = chosenFont
                    )
                    project.layers.add(l)
                    afterEdit(timeline.timeMs)
                    timeline.select(TimelineView.LAYER, l.id)
                } else {
                    existing.text = txt
                    existing.color = chosen
                    existing.font = chosenFont
                    afterEdit(timeline.timeMs)
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showColorDialog(l: Layer) {
        var chosen = l.color
        val box = column()
        box.addView(swatchRow(chosen) { chosen = it })
        dialog().setTitle("Warna teks")
            .setView(box)
            .setPositiveButton("Terapkan") { _, _ ->
                pushUndo()
                l.color = chosen
                layerOverlay.invalidate()
                save()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ------------------------------------------------------------ rasio & audio

    private fun showAspectDialog() {
        val names = arrayOf(
            "Asli (ikut video)", "9:16  (TikTok, Reels, Shorts)", "16:9  (YouTube)", "1:1  (Kotak)",
            "4:5  (Potret Instagram)", "4:3", "3:4", "21:9  (Sinema)"
        )
        val ws = intArrayOf(0, 9, 16, 1, 4, 4, 3, 21)
        val hs = intArrayOf(0, 16, 9, 1, 5, 3, 4, 9)

        val group = RadioGroup(this)
        var current = 0
        for (i in ws.indices) if (ws[i] == project.aspectW && hs[i] == project.aspectH) current = i
        for (i in names.indices) {
            group.addView(RadioButton(this).apply {
                id = 300 + i
                text = names[i]
                setTextColor(0xFFFFFFFF.toInt())
            })
        }
        group.check(300 + current)

        val fill = CheckBox(this)
        fill.text = "Penuhi kanvas (tepi video terpotong)"
        fill.setTextColor(0xFFFFFFFF.toInt())
        fill.isChecked = project.fillMode

        val box = column()
        box.addView(group)
        box.addView(fill)
        val scroll = ScrollView(this)
        scroll.addView(box)

        dialog().setTitle("Rasio aspek")
            .setView(scroll)
            .setPositiveButton("Terapkan") { _, _ ->
                val k = group.checkedRadioButtonId - 300
                pushUndo()
                project.aspectW = ws[k]
                project.aspectH = hs[k]
                project.fillMode = fill.isChecked
                afterEdit(timeline.timeMs)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showAudioDialog() {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        labels.add("Pilih audio dari perangkat")
        actions.add { pickAudio.launch(arrayOf("audio/*")) }

        labels.add("Meta Sound Collection")
        actions.add { startActivity(Intent(this, MetaSoundActivity::class.java)) }

        if (project.audio != null) {
            labels.add("Hapus musik")
            actions.add {
                pushUndo()
                project.audio = null
                afterEdit(timeline.timeMs)
            }
        }
        labels.add(if (project.muteOriginal) "Nyalakan suara asli video" else "Matikan suara asli video")
        actions.add {
            pushUndo()
            project.muteOriginal = !project.muteOriginal
            applySpeed()
            save()
            toast(if (project.muteOriginal) "Suara asli dimatikan" else "Suara asli dinyalakan")
        }

        dialog().setTitle("Musik & audio")
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun setAudio(track: AudioTrack) {
        pushUndo()
        project.audio = track
        afterEdit(timeline.timeMs)
        syncAudioPlayer()
        toast("Musik ditambahkan: ${track.name}")
    }

    // ---------------------------------------------------------------- ekspor

    private fun showExportDialog() {
        if (cropMode) exitCrop()
        player.pause()
        val resNames = arrayOf("1080p (Full HD)", "1440p (2K)", "2160p (4K)", "Native Resolution")
        val resValues = intArrayOf(1080, 1440, 2160, 0)
        val fpsValues = intArrayOf(0, 30, 60, 120) // 0 = FPS asli

        val resGroup = RadioGroup(this)
        resNames.forEachIndexed { i, n ->
            resGroup.addView(RadioButton(this).apply {
                id = 100 + i
                text = n
                setTextColor(0xFFFFFFFF.toInt())
            })
        }
        resGroup.check(100)

        val fpsGroup = RadioGroup(this)
        fpsValues.forEachIndexed { i, f ->
            fpsGroup.addView(RadioButton(this).apply {
                id = 200 + i
                text = if (f == 0) "FPS asli video (disarankan)" else "Maks. $f FPS"
                setTextColor(0xFFFFFFFF.toInt())
            })
        }
        fpsGroup.check(200)

        val note = label(
            "Frame rate 60/120 hanyalah batas maksimum. Aplikasi tidak membuat frame baru " +
                "(tanpa interpolasi), jadi gerakan tetap natural tanpa ghosting. " +
                "Video sumber 30 FPS tetap 30 FPS. Resolusi 4K/Native bergantung pada dukungan encoder perangkat."
        )
        val box = column().apply {
            addView(label("Resolusi (sisi terpendek)"))
            addView(resGroup)
            addView(label("Frame rate"))
            addView(fpsGroup)
            addView(note)
        }
        val scroll = ScrollView(this)
        scroll.addView(box)

        dialog().setTitle("Ekspor video")
            .setView(scroll)
            .setPositiveButton("Ekspor") { _, _ ->
                val res = resValues[resGroup.checkedRadioButtonId - 100]
                val fps = fpsValues[fpsGroup.checkedRadioButtonId - 200]
                runExport(res, fps)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun runExport(shortSide: Int, fps: Int) {
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        val info = label("Memproses… jangan tutup aplikasi.")
        val box = column().apply {
            addView(info)
            addView(bar)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val ex = Exporter(this)
        exporter = ex
        val dlg = dialog().setTitle("Mengekspor…")
            .setView(box)
            .setCancelable(false)
            .setNegativeButton("Batalkan") { _, _ -> ex.cancel() }
            .create()
        exportDialog = dlg
        dlg.show()

        ex.start(project, shortSide, fps, object : Exporter.Callback {
            override fun onProgress(percent: Int) {
                bar.progress = percent
                info.text = "Memproses… $percent%"
            }

            override fun onDone(uri: Uri) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                dlg.dismiss()
                if (isFinishing || isDestroyed) return
                dialog().setTitle("Selesai")
                    .setMessage("Video tersimpan di galeri (Movies/ZuhudVideoEditor).")
                    .setPositiveButton("Buka") { _, _ ->
                        try {
                            startActivity(
                                Intent(Intent.ACTION_VIEW)
                                    .setDataAndType(uri, "video/mp4")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        } catch (e: Exception) {
                            toast("Tidak ada aplikasi pemutar video")
                        }
                    }
                    .setNegativeButton("Tutup", null)
                    .show()
            }

            override fun onError(message: String) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                dlg.dismiss()
                if (isFinishing || isDestroyed) return
                dialog().setTitle("Ekspor gagal")
                    .setMessage(
                        "$message\n\nCoba resolusi/FPS yang lebih rendah. " +
                            "Resolusi tinggi tidak didukung semua perangkat."
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }
        })
    }

    // ------------------------------------------------------ layer video (PiP)

    private fun addVideoLayer(clip: Clip) {
        pushUndo()
        val total = project.totalMs
        val pos = timeline.timeMs
        val start = if (pos >= total - 500L) max(0L, total - 500L) else pos
        val dur = min(clip.durationMs, max(500L, total - start))
        val l = Layer(
            project.nextLayerId(), Layer.VIDEO, uri = clip.uri,
            startMs = start, durationMs = dur,
            srcW = clip.width, srcH = clip.height, srcDurMs = clip.durationMs
        )
        project.layers.add(l)
        afterEdit(timeline.timeMs)
        timeline.select(TimelineView.LAYER, l.id)
    }

    /** Menyamakan pemutar/tampilan layer video dengan daftar layer proyek. */
    private fun rebuildLayerVideos() {
        val wanted = project.layers.filter { it.type == Layer.VIDEO && it.uri != null }
        val ids = wanted.map { it.id }.toSet()
        val gone = layerVideos.keys.filter { it !in ids }
        for (id in gone) {
            val lv = layerVideos.remove(id) ?: continue
            canvasBox.removeView(lv.view)
            lv.view.player = null
            lv.player.release()
        }
        for (l in wanted) {
            val existing = layerVideos[l.id]
            if (existing != null) {
                existing.player.volume = min(1f, l.volume)
                continue
            }
            val view = layoutInflater.inflate(R.layout.view_layer_video, canvasBox, false) as PlayerView
            view.layoutParams = FrameLayout.LayoutParams(10, 10, Gravity.TOP or Gravity.START)
            view.visibility = View.INVISIBLE
            canvasBox.addView(view, canvasBox.indexOfChild(layerOverlay))
            val p = ExoPlayer.Builder(this).build()
            p.setMediaItem(MediaItem.fromUri(l.uri!!))
            p.prepare()
            p.volume = min(1f, l.volume)
            view.player = p
            layerVideos[l.id] = LayerVideo(p, view)
        }
        updateLayerGeometry()
        syncLayerVideos()
    }

    private fun layerIsLive(l: Layer, t: Long): Boolean {
        if (cropMode) return false
        if (!LayerRenderer.isActive(l, t)) return false
        val src = if (l.srcDurMs > 0) l.srcDurMs else l.durationMs
        return t - l.startMs < src
    }

    /** Posisi, ukuran, dan putaran tampilan layer video (sama dengan yang dipakai ekspor). */
    private fun updateLayerGeometry() {
        if (layerVideos.isEmpty() || canvasW <= 0f || canvasH <= 0f) return
        for (l in project.layers) {
            val lv = layerVideos[l.id] ?: continue
            val box = LayerRenderer.measure(l, canvasW, canvasH)
            val w = max(2, box.w.toInt())
            val h = max(2, box.h.toInt())
            val v = lv.view
            val lp = v.layoutParams
            if (lp.width != w || lp.height != h) {
                lp.width = w
                lp.height = h
                v.post { v.layoutParams = lp }
            }
            v.translationX = l.cx * canvasW - box.w / 2f
            v.translationY = l.cy * canvasH - box.h / 2f
            v.rotation = l.rotation
        }
    }

    private fun syncLayerVideos() {
        if (layerVideos.isEmpty()) return
        val t = currentTimelineMs()
        val playing = player.isPlaying
        for (l in project.layers) {
            val lv = layerVideos[l.id] ?: continue
            if (layerIsLive(l, t)) {
                lv.view.visibility = View.VISIBLE
                val target = t - l.startMs
                val drift = abs(lv.player.currentPosition - target)
                if (playing) {
                    if (drift > 300L) lv.player.seekTo(target)
                    if (!lv.player.isPlaying) lv.player.play()
                } else {
                    lv.player.pause()
                    if (drift > 40L) lv.player.seekTo(target)
                }
            } else {
                lv.view.visibility = View.INVISIBLE
                if (lv.player.isPlaying) lv.player.pause()
            }
        }
    }

    private fun showLayerVolumeDialog(l: Layer) {
        var vol = (l.volume * 100).toInt()
        val box = column()
        sliderRow(box, "Volume layer video", vol, 200) { vol = it }
        box.addView(label("Preview hanya meredam sampai 100%. Penguatan di atas 100% terdengar pada hasil ekspor."))
        dialog().setTitle("Volume layer")
            .setView(box)
            .setPositiveButton("Terapkan") { _, _ ->
                pushUndo()
                l.volume = vol / 100f
                layerVideos[l.id]?.player?.volume = min(1f, l.volume)
                save()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showLayerMenu() {
        val labels = arrayOf("Tambah teks", "Tambah stiker", "Tambah foto / video (PiP)")
        dialog().setTitle("Tambah layer")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> showTextEditor(null)
                    1 -> showStickerPicker()
                    else -> pickImage.launch(arrayOf("image/*", "video/*"))
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ------------------------------------------------------- font & volume

    private fun showFontDialog(current: Int, onPick: (Int) -> Unit) {
        val names = Fonts.all.map { it.name }
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                val f = Fonts.get(position)
                v.typeface = f.typeface
                v.text = (if (f.caps) names[position].uppercase() else names[position]) +
                    if (position == current) "   ✓" else ""
                v.setTextColor(0xFFFFFFFF.toInt())
                v.textSize = 20f
                return v
            }
        }
        dialog().setTitle("Pilih font (20)")
            .setAdapter(adapter) { _, which -> onPick(which) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun sliderRow(box: LinearLayout, title: String, startPercent: Int, maxPercent: Int,
                          onChange: (Int) -> Unit) {
        val tv = label("$title: $startPercent%")
        val sb = SeekBar(this)
        sb.max = maxPercent
        sb.progress = startPercent.coerceIn(0, maxPercent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tv.text = "$title: $progress%"
                onChange(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
    }

    private fun showVolumeDialog() {
        var video = (project.videoVolume * 100).toInt()
        var music = (project.audioVolume * 100).toInt()
        val box = column()
        sliderRow(box, "Video utama", video, 200) { video = it }
        sliderRow(
            box, if (project.audio == null) "Musik / audio tambahan (belum ada)" else "Musik / audio tambahan",
            music, 200
        ) { music = it }
        box.addView(label("Preview hanya meredam sampai 100%. Penguatan di atas 100% terdengar pada hasil ekspor."))
        dialog().setTitle("Volume")
            .setView(box)
            .setPositiveButton("Terapkan") { _, _ ->
                pushUndo()
                project.videoVolume = video / 100f
                project.audioVolume = music / 100f
                applyVolumes()
                save()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ------------------------------------------------------ transisi & filter

    private fun clipStartMs(index: Int): Long {
        var t = 0L
        for (k in 0 until index) t += project.clips[k].effectiveMs
        return t
    }

    private fun showTransitionDialog(index: Int) {
        val c = project.clips.getOrNull(index) ?: return
        val names = ArrayList<String>()
        names.add("Tanpa transisi" + if (c.transition == 0) "  ✓" else "")
        Transitions.names.forEachIndexed { i, n -> names.add(n + if (c.transition == i + 1) "  ✓" else "") }
        dialog().setTitle("Transisi masuk klip")
            .setItems(names.toTypedArray()) { _, which ->
                pushUndo()
                c.transition = which
                afterEdit(clipStartMs(index))
                if (which > 0) player.play()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showFilterDialog(index: Int) {
        val c = project.clips.getOrNull(index) ?: return
        val names = ArrayList<String>()
        names.add("Tanpa filter")
        Filters.all.forEach { names.add(it.name) }
        val group = RadioGroup(this)
        names.forEachIndexed { i, n ->
            group.addView(RadioButton(this).apply {
                id = 400 + i
                text = n
                setTextColor(0xFFFFFFFF.toInt())
            })
        }
        group.check(400 + c.filter)
        val all = CheckBox(this)
        all.text = "Terapkan ke semua klip"
        all.setTextColor(0xFFFFFFFF.toInt())
        val box = column()
        box.addView(group)
        box.addView(all)
        val scroll = ScrollView(this)
        scroll.addView(box)
        dialog().setTitle("Filter warna")
            .setView(scroll)
            .setPositiveButton("Terapkan") { _, _ ->
                val f = group.checkedRadioButtonId - 400
                pushUndo()
                if (all.isChecked) project.clips.forEach { it.filter = f } else c.filter = f
                afterEdit(timeline.timeMs)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ----------------------------------------------------------------- stiker

    private fun stickerPreview(key: String): Bitmap {
        val size = 128
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.translate(size / 2f, size / 2f)
        if (key.startsWith("t:")) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.textAlign = Paint.Align.CENTER
            p.typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.NORMAL)
            val txt = key.substring(2)
            p.textSize = 30f
            val w = p.measureText(txt)
            if (w > size - 12) p.textSize = 30f * (size - 12) / w
            val y = -(p.ascent() + p.descent()) / 2f
            p.style = Paint.Style.STROKE
            p.strokeWidth = p.textSize * 0.14f
            p.color = 0xFF000000.toInt()
            c.drawText(txt, 0f, y, p)
            p.style = Paint.Style.FILL
            p.color = 0xFFFFFFFF.toInt()
            c.drawText(txt, 0f, y, p)
        } else {
            Stickers.draw(c, key, size * 0.86f, 0xFFFFFFFF.toInt())
        }
        return bmp
    }

    private fun showStickerPicker() {
        val root = column()
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        val grid = GridLayout(this)
        grid.columnCount = 4
        val scroll = ScrollView(this)
        scroll.addView(grid)
        val tabViews = ArrayList<TextView>()
        lateinit var dlg: AlertDialog

        fun showCategory(index: Int) {
            for ((i, t) in tabViews.withIndex()) t.alpha = if (i == index) 1f else 0.5f
            grid.removeAllViews()
            for (key in Stickers.categories[index].items) {
                val iv = ImageView(this)
                iv.setImageBitmap(stickerPreview(key))
                iv.setBackgroundResource(R.drawable.bg_card)
                iv.setPadding(dp(4), dp(4), dp(4), dp(4))
                iv.setOnClickListener {
                    dlg.dismiss()
                    addSticker(key)
                }
                val lp = GridLayout.LayoutParams()
                lp.width = dp(68)
                lp.height = dp(68)
                lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                grid.addView(iv, lp)
            }
            scroll.scrollTo(0, 0)
        }

        for ((i, cat) in Stickers.categories.withIndex()) {
            val t = TextView(this)
            t.text = cat.name
            t.setTextColor(0xFFFFFFFF.toInt())
            t.textSize = 14f
            t.setPadding(dp(14), dp(8), dp(14), dp(8))
            t.setBackgroundResource(R.drawable.bg_pill)
            t.setOnClickListener { showCategory(i) }
            tabViews.add(t)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            tabs.addView(t, lp)
        }
        val tabScroll = android.widget.HorizontalScrollView(this)
        tabScroll.isHorizontalScrollBarEnabled = false
        tabScroll.addView(tabs)
        root.addView(tabScroll)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(340)))
        showCategory(0)

        dlg = dialog().setTitle("Stiker")
            .setView(root)
            .setNegativeButton("Tutup", null)
            .create()
        dlg.show()
    }

    private fun addSticker(key: String) {
        pushUndo()
        val (start, dur) = defaultTiming()
        val l = Layer(project.nextLayerId(), Layer.STICKER, text = key, startMs = start, durationMs = dur)
        project.layers.add(l)
        afterEdit(timeline.timeMs)
        timeline.select(TimelineView.LAYER, l.id)
    }

    // ------------------------------------------------- kunci kroma / hapus latar

    private fun showChromaDialog(l: Layer) {
        val uri = l.uri ?: return
        val base = LayerRenderer.bitmapFor(uri)
        if (base == null) {
            toast("Gambar tidak dapat dibaca")
            return
        }
        val k = 480f / max(base.width, base.height)
        val small = if (k < 1f) Bitmap.createScaledBitmap(
            base, max(1, (base.width * k).toInt()), max(1, (base.height * k).toInt()), true
        ) else base

        var mode = l.keyMode
        var color = l.keyColor
        var tol = (l.keyTol * 100).toInt()
        var soft = (l.keySoft * 100).toInt()
        var token = 0

        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setBackgroundColor(0xFF4A4A5A.toInt())
        iv.setImageBitmap(small)

        fun refresh() {
            val my = ++token
            if (mode == 0) {
                iv.setImageBitmap(small)
                return
            }
            val m = mode
            val col = color
            val t = tol / 100f
            val s = soft / 100f
            io.execute {
                val out = ChromaKey.apply(small, m, col, t, s)
                runOnUiThread {
                    if (my == token && !isFinishing && !isDestroyed) iv.setImageBitmap(out)
                }
            }
        }

        val group = RadioGroup(this)
        val modeNames = arrayOf("Mati", "Hapus latar otomatis (dari tepi)", "Kunci kroma manual (pilih warna)")
        modeNames.forEachIndexed { i, n ->
            group.addView(RadioButton(this).apply {
                id = 500 + i
                text = n
                setTextColor(0xFFFFFFFF.toInt())
            })
        }
        group.check(500 + mode)
        group.setOnCheckedChangeListener { _, id ->
            mode = id - 500
            refresh()
        }

        iv.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                val inv = Matrix()
                if ((v as ImageView).imageMatrix.invert(inv)) {
                    val pt = floatArrayOf(e.x, e.y)
                    inv.mapPoints(pt)
                    val bx = pt[0].toInt()
                    val by = pt[1].toInt()
                    if (bx in 0 until small.width && by in 0 until small.height) {
                        color = small.getPixel(bx, by) or 0xFF000000.toInt()
                        mode = 2
                        group.check(502)
                    }
                }
            }
            if (e.actionMasked == MotionEvent.ACTION_UP) refresh()
            true
        }

        val box = column()
        box.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)))
        box.addView(label("Mode"))
        box.addView(group)
        box.addView(label("Ketuk gambar untuk mengambil warna latar (mode manual)."))
        box.addView(swatchRow(color) {
            color = it
            mode = 2
            group.check(502)
        })
        sliderRow(box, "Toleransi", tol, 100) { tol = it }
        sliderRow(box, "Kelembutan tepi", soft, 50) { soft = it }
        val apply = TextView(this)
        apply.text = "Lihat hasil"
        apply.setTextColor(0xFF19D3E6.toInt())
        apply.setPadding(0, dp(10), 0, dp(6))
        apply.setOnClickListener { refresh() }
        box.addView(apply)
        val scroll = ScrollView(this)
        scroll.addView(box)

        dialog().setTitle("Kunci kroma & hapus latar")
            .setView(scroll)
            .setPositiveButton("Terapkan") { _, _ ->
                pushUndo()
                l.keyMode = mode
                l.keyColor = color
                l.keyTol = tol / 100f
                l.keySoft = soft / 100f
                io.execute {
                    LayerRenderer.imageFor(l)
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed) afterEdit(timeline.timeMs)
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ============================================================ panel teks
    // Font / Gaya / Efek / Animasi, bergaya CapCut. Panel tidak menggelapkan layar dan tidak menutup
    // sentuhan di luarnya, jadi teks di preview tetap bisa digeser sambil mengedit.

    private var fontPanelRefresh: (() -> Unit)? = null

    private val pickFont =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                val name = MediaUtil.displayName(this, uri)
                io.execute {
                    val path = Fonts.importUri(this, uri, name)
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        if (path == null) toast("Berkas font tidak valid (gunakan .ttf / .otf)")
                        else {
                            toast("Font diimpor: " + File(path).nameWithoutExtension)
                            fontPanelRefresh?.invoke()
                        }
                    }
                }
            }
        }

    private fun showTextEditor(existing: Layer?) {
        if (existing == null) {
            pushUndo()
            val (start, dur) = defaultTiming()
            val l = Layer(project.nextLayerId(), Layer.TEXT, text = "Teks", startMs = start, durationMs = dur)
            project.layers.add(l)
            afterEdit(timeline.timeMs)
            timeline.select(TimelineView.LAYER, l.id)
            showTextPanel(l, 1, false)
        } else {
            showTextPanel(existing, 1, true)
        }
    }

    private fun showTextPanel(l: Layer, startTab: Int, undoFirst: Boolean) {
        if (undoFirst) pushUndo()
        val live: () -> Unit = {
            layerOverlay.invalidate()
            timeline.invalidate()
        }

        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF1E1E26.toInt())
        root.setPadding(dp(12), dp(10), dp(12), dp(6))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val edit = EditText(this)
        edit.setText(l.text)
        edit.setTextColor(0xFFFFFFFF.toInt())
        edit.setHintTextColor(0xFF888899.toInt())
        edit.hint = "Tulis teks"
        edit.maxLines = 3
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                l.text = s?.toString() ?: ""
                live()
            }
        })
        top.addView(edit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val ok = ImageView(this)
        ok.setImageResource(R.drawable.ic_check)
        ok.setPadding(dp(10), dp(10), dp(10), dp(10))
        ok.setOnClickListener { dlg.dismiss() }
        top.addView(ok, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(top)

        val content = FrameLayout(this)
        val tabNames = listOf("Font", "Gaya", "Efek", "Animasi")
        val tabViews = ArrayList<TextView>()
        fun showTab(i: Int) {
            for ((k, t) in tabViews.withIndex()) {
                t.alpha = if (k == i) 1f else 0.5f
                t.paint.isFakeBoldText = k == i
            }
            content.removeAllViews()
            val v = when (i) {
                0 -> fontTab(l, live)
                1 -> styleTab(l, live)
                2 -> effectTab(l, live)
                else -> animContent(l, live)
            }
            content.addView(v)
        }
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        for ((i, n) in tabNames.withIndex()) {
            val t = TextView(this)
            t.text = n
            t.textSize = 15f
            t.setTextColor(0xFFFFFFFF.toInt())
            t.setPadding(dp(14), dp(10), dp(14), dp(10))
            t.setOnClickListener { showTab(i) }
            tabViews.add(t)
            tabs.addView(t)
        }
        root.addView(tabs)
        // Panel naik sampai ~56% tinggi layar dari atas (sekitar 44% layar untuk seluruh panel).
        val screenH = resources.displayMetrics.heightPixels
        val contentH = (screenH * 0.44f).toInt() - dp(120)
        root.addView(
            content,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, contentH.coerceAtLeast(dp(250)))
        )
        dlg.setContentView(root)

        val w = dlg.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(0x00000000))
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setGravity(Gravity.BOTTOM)
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            w.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL)
            w.setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN or
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            )
        }
        dlg.setCanceledOnTouchOutside(false)
        dlg.setOnDismissListener {
            fontPanelRefresh = null
            if (l.text.isBlank()) l.text = "Teks"
            if (!isFinishing && !isDestroyed) afterEdit(timeline.timeMs)
        }
        showTab(startTab)
        dlg.show()
    }

    // ----------------------------------------------------------- pembantu UI

    private fun pill(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 13f
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setBackgroundResource(R.drawable.bg_pill)
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        t.alpha = if (selected) 1f else 0.5f
        t.setOnClickListener { onClick() }
        return t
    }

    private fun chips(names: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val hs = android.widget.HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(4), 0, dp(4))
        val tvs = ArrayList<TextView>()
        for ((i, n) in names.withIndex()) {
            val tv = pill(n, i == selected) {
                for ((k, v) in tvs.withIndex()) v.alpha = if (k == i) 1f else 0.5f
                onPick(i)
            }
            tvs.add(tv)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            row.addView(tv, lp)
        }
        hs.addView(row)
        return hs
    }

    private fun sliderF(
        box: LinearLayout, title: String, value: Float, lo: Float, hi: Float,
        fmt: (Float) -> String, onChange: (Float) -> Unit
    ) {
        val tv = label("$title: ${fmt(value)}")
        val sb = SeekBar(this)
        sb.max = 1000
        sb.progress = (((value - lo) / (hi - lo)).coerceIn(0f, 1f) * 1000f).toInt()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = lo + progress / 1000f * (hi - lo)
                tv.text = "$title: ${fmt(v)}"
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
    }

    private fun pct(v: Float): String = "${(v * 100).toInt()}%"

    private fun showHexDialog(initial: Int, onPick: (Int) -> Unit) {
        val et = EditText(this)
        et.setText(String.format("#%06X", initial and 0xFFFFFF))
        et.setTextColor(0xFFFFFFFF.toInt())
        val box = column()
        box.addView(et)
        dialog().setTitle("Warna (hex)")
            .setView(box)
            .setPositiveButton("Terapkan") { _, _ ->
                try {
                    onPick(android.graphics.Color.parseColor(et.text.toString().trim()) or 0xFF000000.toInt())
                } catch (e: Exception) {
                    toast("Format warna salah, contoh: #FF8800")
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Deretan warna + tombol hex untuk warna bebas. */
    private fun colorRow(initial: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(swatchRow(initial, onPick), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val hex = TextView(this)
        hex.text = "#"
        hex.textSize = 16f
        hex.gravity = Gravity.CENTER
        hex.setTextColor(0xFFFFFFFF.toInt())
        hex.setBackgroundResource(R.drawable.bg_pill)
        hex.setOnClickListener { showHexDialog(initial, onPick) }
        row.addView(hex, LinearLayout.LayoutParams(dp(40), dp(34)))
        return row
    }

    // --------------------------------------------------------------- tab Font

    private class FontRow(val name: String, val tf: () -> Typeface?, val selected: Boolean, val select: () -> Unit)

    private fun fontTab(l: Layer, live: () -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        var cat = 0
        var query = ""
        var rows: List<FontRow> = emptyList()

        val info = TextView(this)
        info.setTextColor(0xFFBBBBCC.toInt())
        info.textSize = 12f
        info.setPadding(0, dp(4), 0, dp(4))

        val search = EditText(this)
        search.hint = "Cari font…"
        search.setHintTextColor(0xFF888899.toInt())
        search.setTextColor(0xFFFFFFFF.toInt())
        search.textSize = 14f
        search.setSingleLine(true)

        val list = ListView(this)
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = rows.size
            override fun getItem(position: Int): Any = rows[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(this@EditorActivity)
                val r = rows[position]
                tv.text = r.name + if (r.selected) "   ✓" else ""
                tv.typeface = r.tf() ?: Typeface.DEFAULT
                tv.textSize = 20f
                tv.setTextColor(if (r.selected) 0xFF19D3E6.toInt() else 0xFFFFFFFF.toInt())
                tv.setPadding(dp(8), dp(10), dp(8), dp(10))
                return tv
            }
        }
        list.adapter = adapter

        fun build() {
            val q = query.trim().lowercase()
            fun ok(n: String) = q.isEmpty() || n.lowercase().contains(q)
            rows = when (cat) {
                0 -> Fonts.all.mapIndexedNotNull { i, f ->
                    if (!ok(f.name)) null else FontRow(
                        if (f.caps) f.name.uppercase() else f.name, { f.typeface },
                        l.fontFile.isEmpty() && l.font == i
                    ) {
                        l.font = i
                        l.fontFile = ""
                    }
                }
                1 -> Fonts.assetFonts().filter { ok(it.name) }.map { ff ->
                    FontRow(ff.name, { Fonts.fromFile(ff.path) }, l.fontFile == ff.path) { l.fontFile = ff.path }
                }
                2 -> Fonts.systemFonts().filter { ok(it.name) }.map { ff ->
                    FontRow(ff.name, { Fonts.fromFile(ff.path) }, l.fontFile == ff.path) { l.fontFile = ff.path }
                }
                else -> Fonts.userFonts(this).filter { ok(it.name) }.map { ff ->
                    FontRow(
                        ff.name, { Fonts.fromFile(ff.path) },
                        l.fontFile.isNotEmpty() && File(l.fontFile).name == File(ff.path).name
                    ) {
                        val saved = Fonts.adopt(this, ff.path)
                        if (saved != null) {
                            l.fontFile = saved
                        } else {
                            toast("Font tidak valid")
                        }
                    }
                }
            }
            info.text = when (cat) {
                0 -> "${rows.size} gaya bawaan"
                1 -> "${rows.size} font koleksi di dalam aplikasi"
                2 -> "${rows.size} font bawaan sistem Android"
                else -> if (!Fonts.canReadUserDir() && rows.isEmpty())
                    "Folder ${Fonts.USER_DIR} belum bisa dibaca. Beri izin \"Akses semua file\", lalu tekan Muat ulang."
                else if (rows.isEmpty())
                    "Belum ada font. Salin berkas .ttf / .otf ke ${Fonts.USER_DIR} lalu tekan Muat ulang."
                else "${rows.size} font dari ${Fonts.USER_DIR} dan font yang diimpor"
            }
            adapter.notifyDataSetChanged()
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                build()
            }
        })
        list.setOnItemClickListener { _, _, pos, _ ->
            rows.getOrNull(pos)?.select?.invoke()
            live()
            build()
        }

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        fun addAction(text: String, onClick: () -> Unit) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            actions.addView(pill(text, true, onClick), lp)
        }
        addAction("Muat ulang") { build() }
        addAction("Izin akses file") { requestAllFilesAccess() }
        addAction("Impor font…") { pickFont.launch(arrayOf("*/*")) }

        box.addView(chips(listOf("Bawaan", "Koleksi", "Sistem", "Folder fonts"), 0) {
            cat = it
            build()
        })
        box.addView(search)
        box.addView(info)
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val hs = android.widget.HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(actions)
        box.addView(hs)
        fontPanelRefresh = { build() }
        build()
        return box
    }

    private fun requestAllFilesAccess() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    toast("Izin sudah diberikan")
                } else {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                    )
                }
            } else {
                requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 77)
            }
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (e2: Exception) {
                toast("Buka Pengaturan > Aplikasi > ZuFX > Izin > Akses semua file")
            }
        }
    }

    // --------------------------------------------------------------- tab Gaya

    private class StylePreset(
        val fill: Int, val stroke: Int, val strokeW: Float,
        val bg: Int, val bgA: Float, val shadow: Boolean
    )

    private val stylePresets = listOf(
        StylePreset(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0f, 0xFF000000.toInt(), 0f, false),
        StylePreset(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0.14f, 0xFF000000.toInt(), 0f, false),
        StylePreset(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0f, 0xFF000000.toInt(), 0f, true),
        StylePreset(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0.26f, 0xFF000000.toInt(), 0f, false),
        StylePreset(0xFFFFD400.toInt(), 0xFF000000.toInt(), 0.14f, 0xFF000000.toInt(), 0f, false),
        StylePreset(0xFFFF3B30.toInt(), 0xFFFFFFFF.toInt(), 0.14f, 0xFF000000.toInt(), 0f, false),
        StylePreset(0xFFFF9500.toInt(), 0xFF000000.toInt(), 0.14f, 0xFF000000.toInt(), 0f, false),
        StylePreset(0xFF19B4FF.toInt(), 0xFFFFFFFF.toInt(), 0.14f, 0xFF000000.toInt(), 0f, false),
        StylePreset(0xFF34C759.toInt(), 0xFF000000.toInt(), 0.14f, 0xFF000000.toInt(), 0f, false),
        StylePreset(0xFF000000.toInt(), 0xFF000000.toInt(), 0f, 0xFFBBBBBB.toInt(), 1f, false),
        StylePreset(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0f, 0xFF222222.toInt(), 1f, false),
        StylePreset(0xFF000000.toInt(), 0xFF000000.toInt(), 0f, 0xFFFFD400.toInt(), 1f, false),
        StylePreset(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0f, 0xFF7A2BFF.toInt(), 1f, false)
    )

    private fun styleTab(l: Layer, live: () -> Unit): View {
        val sv = ScrollView(this)
        val box = column()
        sv.addView(box)

        box.addView(label("Gaya cepat"))
        val hs = android.widget.HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (p in stylePresets) {
            val tile = TextView(this)
            tile.text = "Aa"
            tile.textSize = 22f
            tile.gravity = Gravity.CENTER
            tile.typeface = Typeface.DEFAULT_BOLD
            tile.setTextColor(p.fill)
            if (p.strokeW > 0f || p.shadow) tile.setShadowLayer(4f, 0f, 0f, p.stroke)
            tile.setBackgroundColor(if (p.bgA > 0f) p.bg else 0xFF3A3A44.toInt())
            tile.setOnClickListener {
                l.color = p.fill
                l.strokeColor = p.stroke
                l.strokeW = p.strokeW
                l.bgColor = p.bg
                l.bgAlpha = p.bgA
                l.shadow = p.shadow
                l.shadowColor = 0xFF000000.toInt()
                live()
            }
            val lp = LinearLayout.LayoutParams(dp(52), dp(52))
            lp.marginEnd = dp(8)
            row.addView(tile, lp)
        }
        hs.addView(row)
        box.addView(hs)

        box.addView(label("Warna teks"))
        box.addView(colorRow(l.color) {
            l.color = it
            live()
        })
        sliderF(box, "Ukuran", l.scale, 0.3f, 4f, { String.format("%.1fx", it) }) {
            l.scale = it
            live()
        }
        sliderF(box, "Opacity", l.opacity, 0f, 1f, ::pct) {
            l.opacity = it
            live()
        }

        val toggles = LinearLayout(this)
        toggles.orientation = LinearLayout.HORIZONTAL
        val bold = CheckBox(this)
        bold.text = "Tebal"
        bold.setTextColor(0xFFFFFFFF.toInt())
        bold.isChecked = l.bold
        bold.setOnCheckedChangeListener { _, c ->
            l.bold = c
            live()
        }
        val ital = CheckBox(this)
        ital.text = "Miring"
        ital.setTextColor(0xFFFFFFFF.toInt())
        ital.isChecked = l.italic
        ital.setOnCheckedChangeListener { _, c ->
            l.italic = c
            live()
        }
        toggles.addView(bold)
        toggles.addView(ital)
        box.addView(toggles)

        sliderF(box, "Spasi huruf", l.spacing, -0.05f, 0.5f, { String.format("%.2f", it) }) {
            l.spacing = it
            live()
        }

        box.addView(label("Garis tepi"))
        box.addView(colorRow(l.strokeColor) {
            l.strokeColor = it
            if (l.strokeW < 0.02f) l.strokeW = 0.14f
            live()
        })
        sliderF(box, "Tebal garis", l.strokeW, 0f, 0.4f, { String.format("%.2f", it) }) {
            l.strokeW = it
            live()
        }

        box.addView(label("Latar belakang"))
        box.addView(colorRow(l.bgColor) {
            l.bgColor = it
            if (l.bgAlpha < 0.05f) l.bgAlpha = 1f
            live()
        })
        sliderF(box, "Opasitas latar", l.bgAlpha, 0f, 1f, ::pct) {
            l.bgAlpha = it
            live()
        }
        return sv
    }

    // --------------------------------------------------------------- tab Efek

    private fun effectTab(l: Layer, live: () -> Unit): View {
        val sv = ScrollView(this)
        val box = column()
        sv.addView(box)
        val names = listOf("Tanpa", "Bayangan", "Neon", "3D", "Glitch", "Gradasi", "Timbul")
        val current = when {
            l.glitch -> 4
            l.glowR > 0.001f -> 2
            l.extrude in 1..5 -> 6
            l.extrude >= 6 -> 3
            l.gradOn -> 5
            l.shadow -> 1
            else -> 0
        }
        box.addView(label("Efek teks"))
        box.addView(chips(names, current) { i ->
            l.shadow = false
            l.glowR = 0f
            l.extrude = 0
            l.glitch = false
            l.gradOn = false
            when (i) {
                1 -> l.shadow = true
                2 -> l.glowR = 0.4f
                3 -> l.extrude = 6
                4 -> l.glitch = true
                5 -> l.gradOn = true
                6 -> {
                    l.extrude = 3
                    l.shadow = true
                }
            }
            live()
        })
        box.addView(label("Warna efek (cahaya / gradasi / bayangan)"))
        box.addView(colorRow(l.glowColor) {
            l.glowColor = it
            l.gradColor = it
            l.shadowColor = it
            live()
        })
        sliderF(box, "Intensitas", 0.5f, 0.1f, 1f, ::pct) { v ->
            if (l.glowR > 0.001f) l.glowR = v * 0.8f
            if (l.extrude > 0) l.extrude = max(1, (v * 12f).toInt())
            live()
        }
        box.addView(label("Neon paling bagus dengan teks putih; Gradasi memakai warna teks lalu warna efek."))
        return sv
    }

    // ------------------------------------------------------------ tab Animasi

    private fun animContent(l: Layer, live: () -> Unit): View {
        val sv = ScrollView(this)
        val box = column()
        sv.addView(box)
        fun preview() {
            player.pause()
            seekToTimeline(l.startMs)
            player.play()
        }
        box.addView(label("Masuk"))
        box.addView(chips(LayerAnim.inNames, l.animIn) {
            l.animIn = it
            live()
            preview()
        })
        box.addView(label("Keluar"))
        box.addView(chips(LayerAnim.outNames, l.animOut) {
            l.animOut = it
            live()
            preview()
        })
        box.addView(label("Berulang"))
        box.addView(chips(LayerAnim.loopNames, l.animLoop) {
            l.animLoop = it
            live()
            preview()
        })
        sliderF(box, "Durasi animasi", l.animMs / 1000f, 0.2f, 2f, { String.format("%.1f dtk", it) }) {
            l.animMs = (it * 1000f).toLong()
            live()
        }
        return sv
    }

    /** Animasi untuk stiker / gambar (teks memakai panel). */
    private fun showAnimDialog(l: Layer) {
        pushUndo()
        val live: () -> Unit = {
            layerOverlay.invalidate()
            timeline.invalidate()
        }
        dialog().setTitle("Animasi layer")
            .setView(animContent(l, live))
            .setPositiveButton("Selesai") { _, _ -> save() }
            .show()
    }

    // ========================================================= zoom cubit layar

    private var gestureEdit = false
    private var lastCx = 0f
    private var lastCy = 0f

    private fun clipAtPlayhead(): Clip? = project.clips.getOrNull(player.currentMediaItemIndex)

    private fun beginGestureEdit() {
        if (!gestureEdit) {
            gestureEdit = true
            pushUndo()
        }
    }

    private val scaleDetector by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val c = clipAtPlayhead() ?: return false
                beginGestureEdit()
                c.zoom = (c.zoom * detector.scaleFactor).coerceIn(0.2f, 8f)
                layoutVideo(c)
                return true
            }
        })
    }

    /** Cubit = zoom in/out video atau foto utama; geser dengan jari saat sudah di-zoom. */
    private fun handlePreviewTouch(e: MotionEvent): Boolean {
        if (cropMode || canvasW <= 0f) return false
        scaleDetector.onTouchEvent(e)
        val skip = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
        var cx = 0f
        var cy = 0f
        var n = 0
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            cx += e.getX(i)
            cy += e.getY(i)
            n++
        }
        if (n > 0) {
            cx /= n
            cy /= n
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                lastCx = cx
                lastCy = cy
            }
            MotionEvent.ACTION_MOVE -> {
                val c = clipAtPlayhead()
                if (c != null && (e.pointerCount >= 2 || c.zoom != 1f || c.panX != 0f || c.panY != 0f)) {
                    val dx = cx - lastCx
                    val dy = cy - lastCy
                    if (e.pointerCount >= 2 || c.zoom != 1f) {
                        if (dx != 0f || dy != 0f) {
                            beginGestureEdit()
                            c.panX = (c.panX + dx / canvasW).coerceIn(-2f, 2f)
                            c.panY = (c.panY + dy / canvasH).coerceIn(-2f, 2f)
                            layoutVideo(c)
                        }
                    }
                }
                lastCx = cx
                lastCy = cy
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (gestureEdit) {
                    gestureEdit = false
                    save()
                    timeline.invalidate()
                }
            }
        }
        return true
    }

    private fun resetZoom(index: Int) {
        val c = project.clips.getOrNull(index) ?: return
        pushUndo()
        c.zoom = 1f
        c.panX = 0f
        c.panY = 0f
        afterEdit(timeline.timeMs)
    }

    // --------------------------------------------------------------- helpers

    private fun dialog() = AlertDialog.Builder(this, R.style.ZuhudDialog)

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(8), dp(20), dp(4))
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(0xFFBBBBCC.toInt())
        textSize = 13f
        setPadding(0, dp(10), 0, dp(4))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
