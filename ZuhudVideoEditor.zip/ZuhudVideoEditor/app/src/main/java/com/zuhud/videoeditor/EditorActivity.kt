package com.zuhud.videoeditor

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class EditorActivity : AppCompatActivity() {

    private val project: Project get() = ProjectStore.project
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newFixedThreadPool(2)

    private lateinit var player: ExoPlayer
    private lateinit var audioPlayer: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var previewText: TextView
    private lateinit var btnPlay: TextView
    private lateinit var txtTime: TextView
    private lateinit var seek: SeekBar
    private lateinit var timelineScroll: HorizontalScrollView
    private lateinit var timelineRoot: FrameLayout
    private var playhead: View? = null

    private var selClip = 0
    private var userSeeking = false
    private var exporter: Exporter? = null
    private var exportDialog: AlertDialog? = null

    private val thumbs = HashMap<String, Bitmap>()

    private val pxPerSec get() = dp(40)

    // ---------------------------------------------------------------- picker

    private val pickMoreVideos =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) addVideos(uris)
        }

    private val pickAudio =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                MediaUtil.keepAccess(this, uri)
                io.execute {
                    val t = MediaUtil.probeAudio(this, uri)
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        if (t == null) toast("Berkas audio tidak dapat dibaca") else setAudio(t)
                    }
                }
            }
        }

    // ------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (project.clips.isEmpty()) {
            finish()
            return
        }
        setContentView(R.layout.activity_editor)

        playerView = findViewById(R.id.playerView)
        previewText = findViewById(R.id.previewText)
        btnPlay = findViewById(R.id.btnPlay)
        txtTime = findViewById(R.id.txtTime)
        seek = findViewById(R.id.seek)
        timelineScroll = findViewById(R.id.timelineScroll)
        timelineRoot = findViewById(R.id.timelineRoot)

        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        audioPlayer = ExoPlayer.Builder(this).build()
        audioPlayer.repeatMode = Player.REPEAT_MODE_ALL

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                btnPlay.text = if (isPlaying) "⏸" else "▶"
                if (project.audio != null) {
                    if (isPlaying) {
                        seekAudio(currentTimelineMs())
                        audioPlayer.play()
                    } else {
                        audioPlayer.pause()
                    }
                }
                if (isPlaying) handler.post(tick)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                applySpeed()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    audioPlayer.pause()
                    player.seekTo(0, 0L)
                    player.pause()
                    applySpeed()
                    updateUi()
                }
            }
        })

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnExport).setOnClickListener { showExportDialog() }
        btnPlay.setOnClickListener { togglePlay() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    seekToTimeline(project.totalMs * progress / sb.max)
                    updateUi(fromSeekBar = true)
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar) {
                userSeeking = true
            }

            override fun onStopTrackingTouch(sb: SeekBar) {
                userSeeking = false
            }
        })

        findViewById<View>(R.id.toolAdd).setOnClickListener { pickMoreVideos.launch(arrayOf("video/*")) }
        findViewById<View>(R.id.toolTrim).setOnClickListener { showTrimDialog() }
        findViewById<View>(R.id.toolSplit).setOnClickListener { splitAtPlayhead() }
        findViewById<View>(R.id.toolSpeed).setOnClickListener { showSpeedDialog() }
        findViewById<View>(R.id.toolText).setOnClickListener { addText() }
        findViewById<View>(R.id.toolMusic).setOnClickListener { showMusicDialog() }
        findViewById<View>(R.id.toolLeft).setOnClickListener { moveClip(-1) }
        findViewById<View>(R.id.toolRight).setOnClickListener { moveClip(1) }
        findViewById<View>(R.id.toolDelete).setOnClickListener { deleteSelected() }

        selClip = 0
        syncAudioPlayer()
        reloadPlayer(0L)
        rebuildTimeline()
        updateUi()
    }

    override fun onResume() {
        super.onResume()
        if (!::player.isInitialized) return
        // Musik hasil Meta Sound Collection yang menunggu diimpor.
        ProjectStore.pendingAudio?.let {
            ProjectStore.pendingAudio = null
            setAudio(it)
        }
    }

    override fun onPause() {
        super.onPause()
        if (::player.isInitialized) {
            player.pause()
            audioPlayer.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        exporter?.cancel()
        exportDialog?.dismiss()
        io.shutdownNow()
        if (::player.isInitialized) {
            playerView.player = null
            player.release()
            audioPlayer.release()
        }
    }

    // -------------------------------------------------------------- playback

    private val tick = object : Runnable {
        override fun run() {
            updateUi()
            if (player.isPlaying) handler.postDelayed(this, 80)
        }
    }

    private fun togglePlay() {
        if (player.isPlaying) {
            player.pause()
        } else {
            if (currentTimelineMs() >= project.totalMs - 50) seekToTimeline(0L)
            player.play()
        }
    }

    private fun applySpeed() {
        val c = project.clips.getOrNull(player.currentMediaItemIndex) ?: return
        player.playbackParameters = PlaybackParameters(c.speed, 1f)
        player.volume = if (project.muteOriginal) 0f else 1f
    }

    private fun currentTimelineMs(): Long {
        val clips = project.clips
        if (clips.isEmpty()) return 0L
        val i = player.currentMediaItemIndex.coerceIn(0, clips.size - 1)
        var before = 0L
        for (k in 0 until i) before += clips[k].effectiveMs
        val within = (player.currentPosition / clips[i].speed).toLong().coerceIn(0L, clips[i].effectiveMs)
        return before + within
    }

    private fun seekToTimeline(ms: Long) {
        val clips = project.clips
        if (clips.isEmpty()) return
        var rest = ms.coerceIn(0L, project.totalMs)
        var idx = clips.size - 1
        var offset = clips[idx].effectiveMs
        for ((i, c) in clips.withIndex()) {
            if (rest < c.effectiveMs) {
                idx = i
                offset = rest
                break
            }
            rest -= c.effectiveMs
        }
        player.seekTo(idx, (offset * clips[idx].speed).toLong())
        applySpeed()
        seekAudio(ms)
    }

    private fun seekAudio(timelineMs: Long) {
        val a = project.audio ?: return
        if (a.durationMs > 0) audioPlayer.seekTo(timelineMs % a.durationMs)
    }

    /** Memuat ulang daftar klip ke pemutar setelah struktur proyek berubah. */
    private fun reloadPlayer(keepMs: Long) {
        val items = project.clips.map { c ->
            MediaItem.Builder()
                .setUri(c.uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.startMs)
                        .setEndPositionMs(c.endMs)
                        .build()
                )
                .build()
        }
        player.setMediaItems(items)
        player.prepare()
        seekToTimeline(keepMs)
    }

    private fun syncAudioPlayer() {
        val a = project.audio
        audioPlayer.stop()
        audioPlayer.clearMediaItems()
        if (a != null) {
            audioPlayer.setMediaItem(MediaItem.fromUri(a.uri))
            audioPlayer.prepare()
        }
    }

    private fun updateUi(fromSeekBar: Boolean = false) {
        val total = project.totalMs
        val pos = currentTimelineMs()
        txtTime.text = "${MediaUtil.formatTime(pos)} / ${MediaUtil.formatTime(total)}"
        if (!userSeeking && !fromSeekBar && total > 0) {
            seek.progress = (pos * seek.max / total).toInt()
        }

        val active = project.texts.filter { pos >= it.startMs && pos < it.endMs }
        if (active.isEmpty()) {
            previewText.visibility = View.GONE
        } else {
            previewText.text = active.joinToString("\n") { it.text }
            previewText.visibility = View.VISIBLE
        }

        val x = dp(16) + msToPx(pos)
        playhead?.translationX = x.toFloat()
        if (player.isPlaying) {
            val target = max(0, x - timelineScroll.width / 2)
            timelineScroll.scrollTo(target, 0)
        }
    }

    // -------------------------------------------------------------- timeline

    private fun msToPx(ms: Long): Int = (ms / 1000f * pxPerSec).toInt()

    private fun rebuildTimeline() {
        val root = timelineRoot
        root.removeAllViews()
        val x0 = dp(16)
        val total = project.totalMs
        val audioLen = project.audio?.let { min(it.durationMs, total) } ?: 0L
        val textEnd = project.texts.maxOfOrNull { it.endMs } ?: 0L
        val longest = max(total, max(audioLen, textEnd))
        val screenW = resources.displayMetrics.widthPixels
        val width = max(x0 * 2 + msToPx(longest), screenW)
        root.layoutParams = FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.MATCH_PARENT)

        // ---- baris video
        var before = 0L
        for ((i, c) in project.clips.withIndex()) {
            val w = max(msToPx(c.effectiveMs), dp(28))
            val chip = FrameLayout(this)
            chip.setBackgroundResource(R.drawable.bg_chip_video)
            if (i == selClip) chip.foreground = getDrawable(R.drawable.fg_chip_selected)

            val img = ImageView(this)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.alpha = 0.85f
            chip.addView(img, FrameLayout.LayoutParams(-1, -1))
            loadThumb(c, img)

            val label = TextView(this)
            label.setTextColor(0xFFFFFFFF.toInt())
            label.textSize = 10f
            label.setShadowLayer(4f, 0f, 0f, 0xFF000000.toInt())
            label.setPadding(dp(4), dp(2), dp(4), 0)
            label.maxLines = 1
            label.text = "${MediaUtil.formatSeconds(c.effectiveMs)}s" +
                if (c.speed != 1f) "  ${c.speed}x" else ""
            chip.addView(label, FrameLayout.LayoutParams(-2, -2))

            val lp = FrameLayout.LayoutParams(w - dp(2), dp(56))
            lp.leftMargin = x0 + msToPx(before)
            lp.topMargin = dp(12)
            val index = i
            chip.setOnClickListener {
                selClip = index
                rebuildTimeline()
            }
            root.addView(chip, lp)
            before += c.effectiveMs
        }

        // ---- baris teks
        for (t in project.texts) {
            val chip = TextView(this)
            chip.setBackgroundResource(R.drawable.bg_chip_text)
            chip.setTextColor(0xFFFFFFFF.toInt())
            chip.textSize = 11f
            chip.maxLines = 1
            chip.gravity = Gravity.CENTER_VERTICAL
            chip.setPadding(dp(8), 0, dp(8), 0)
            chip.text = "T  ${t.text}"
            val lp = FrameLayout.LayoutParams(max(msToPx(t.durationMs), dp(40)), dp(40))
            lp.leftMargin = x0 + msToPx(t.startMs)
            lp.topMargin = dp(76)
            chip.setOnClickListener { showTextDialog(t) }
            root.addView(chip, lp)
        }

        // ---- baris musik
        project.audio?.let { a ->
            val chip = TextView(this)
            chip.setBackgroundResource(R.drawable.bg_chip_music)
            chip.setTextColor(0xFFFFFFFF.toInt())
            chip.textSize = 11f
            chip.maxLines = 1
            chip.gravity = Gravity.CENTER_VERTICAL
            chip.setPadding(dp(8), 0, dp(8), 0)
            chip.text = "♪  ${a.name}"
            val lp = FrameLayout.LayoutParams(max(msToPx(audioLen), dp(40)), dp(40))
            lp.leftMargin = x0
            lp.topMargin = dp(124)
            chip.setOnClickListener { showMusicDialog() }
            root.addView(chip, lp)
        }

        // ---- garis posisi putar
        val line = View(this)
        line.setBackgroundColor(0xFFFFFFFF.toInt())
        root.addView(line, FrameLayout.LayoutParams(dp(2), ViewGroup.LayoutParams.MATCH_PARENT))
        playhead = line
        updateUi()
    }

    private fun loadThumb(c: Clip, img: ImageView) {
        val key = "${c.uri}@${c.startMs}"
        thumbs[key]?.let {
            img.setImageBitmap(it)
            return
        }
        img.tag = key
        io.execute {
            val bmp = MediaUtil.thumbnail(this, c.uri, c.startMs) ?: return@execute
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                thumbs[key] = bmp
                if (img.tag == key) img.setImageBitmap(bmp)
            }
        }
    }

    /** Dipanggil setiap kali klip/teks/musik berubah. */
    private fun afterStructureChange(keepMs: Long) {
        player.pause()
        reloadPlayer(keepMs)
        rebuildTimeline()
        updateUi()
    }

    // ----------------------------------------------------------------- tools

    private fun addVideos(uris: List<Uri>) {
        toast("Memuat video…")
        io.execute {
            val clips = uris.mapNotNull { u ->
                MediaUtil.keepAccess(this, u)
                MediaUtil.probeVideo(this, u)
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (clips.isEmpty()) {
                    toast("Video tidak dapat dibaca")
                } else {
                    val pos = currentTimelineMs()
                    project.clips.addAll(clips)
                    afterStructureChange(pos)
                }
            }
        }
    }

    private fun selectedClip(): Clip? {
        val c = project.clips.getOrNull(selClip)
        if (c == null) toast("Pilih klip di timeline dulu")
        return c
    }

    private fun showTrimDialog() {
        val c = selectedClip() ?: return
        val step = 100L // 0,1 detik
        val maxSteps = (c.durationMs / step).toInt().coerceAtLeast(1)

        val startBar = SeekBar(this).apply {
            max = maxSteps
            progress = (c.startMs / step).toInt()
        }
        val endBar = SeekBar(this).apply {
            max = maxSteps
            progress = (c.endMs / step).toInt()
        }
        val startLabel = label("")
        val endLabel = label("")
        fun refresh() {
            startLabel.text = "Mulai: ${MediaUtil.formatSeconds(startBar.progress * step)} dtk"
            endLabel.text = "Selesai: ${MediaUtil.formatSeconds(endBar.progress * step)} dtk  (durasi asli ${MediaUtil.formatSeconds(c.durationMs)} dtk)"
        }
        val minSteps = 5
        startBar.setOnSeekBarChangeListener(simpleSeek {
            if (startBar.progress > endBar.progress - minSteps) startBar.progress = max(0, endBar.progress - minSteps)
            refresh()
        })
        endBar.setOnSeekBarChangeListener(simpleSeek {
            if (endBar.progress < startBar.progress + minSteps) endBar.progress = min(maxSteps, startBar.progress + minSteps)
            refresh()
        })
        refresh()

        val box = column().apply {
            addView(startLabel)
            addView(startBar)
            addView(endLabel)
            addView(endBar)
        }
        dialog().setTitle("Potong klip")
            .setView(box)
            .setPositiveButton("Terapkan") { _, _ ->
                val pos = currentTimelineMs()
                c.startMs = startBar.progress * step
                c.endMs = min(c.durationMs, max(endBar.progress * step, c.startMs + 500L))
                afterStructureChange(min(pos, project.totalMs))
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun splitAtPlayhead() {
        val pos = currentTimelineMs()
        var before = 0L
        for ((i, c) in project.clips.withIndex()) {
            val len = c.effectiveMs
            if (pos < before + len || i == project.clips.size - 1) {
                val offset = (pos - before).coerceIn(0L, len)
                val src = c.startMs + (offset * c.speed).toLong()
                if (src - c.startMs < 300L || c.endMs - src < 300L) {
                    toast("Geser posisi putar ke tengah klip untuk membelah")
                    return
                }
                val a = c.copy(endMs = src)
                val b = c.copy(startMs = src)
                project.clips.removeAt(i)
                project.clips.add(i, b)
                project.clips.add(i, a)
                selClip = i
                afterStructureChange(pos)
                return
            }
            before += len
        }
    }

    private fun showSpeedDialog() {
        val c = selectedClip() ?: return
        val options = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
        val names = options.map { "${it}x" + if (it == c.speed) "  ✓" else "" }.toTypedArray()
        dialog().setTitle("Kecepatan klip")
            .setItems(names) { _, which ->
                val pos = currentTimelineMs()
                c.speed = options[which]
                afterStructureChange(min(pos, project.totalMs))
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun addText() {
        val total = project.totalMs
        val pos = currentTimelineMs()
        val dur = min(3000L, total)
        val start = if (pos + dur > total) max(0L, total - dur) else pos
        val item = TextItem("Teks baru", start, max(dur, 500L))
        showTextDialog(item, isNew = true)
    }

    private fun showTextDialog(item: TextItem, isNew: Boolean = false) {
        val edit = EditText(this).apply {
            setText(item.text)
            setTextColor(0xFFFFFFFF.toInt())
            hint = "Tulis teks"
            setHintTextColor(0xFF888888.toInt())
        }
        val startEdit = numberField((item.startMs / 1000f).toString())
        val durEdit = numberField((item.durationMs / 1000f).toString())
        val box = column().apply {
            addView(edit)
            addView(label("Mulai (detik)"))
            addView(startEdit)
            addView(label("Durasi (detik)"))
            addView(durEdit)
        }
        val b = dialog().setTitle(if (isNew) "Tambah teks" else "Ubah teks")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val txt = edit.text.toString().trim()
                if (txt.isEmpty()) {
                    toast("Teks kosong")
                    return@setPositiveButton
                }
                item.text = txt
                item.startMs = ((startEdit.text.toString().toFloatOrNull() ?: 0f) * 1000).toLong().coerceAtLeast(0L)
                item.durationMs = ((durEdit.text.toString().toFloatOrNull() ?: 3f) * 1000).toLong().coerceAtLeast(300L)
                if (isNew) project.texts.add(item)
                afterStructureChange(currentTimelineMs())
            }
            .setNegativeButton("Batal", null)
        if (!isNew) {
            b.setNeutralButton("Hapus") { _, _ ->
                project.texts.remove(item)
                afterStructureChange(currentTimelineMs())
            }
        }
        b.show()
    }

    private fun showMusicDialog() {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        labels.add("Pilih audio dari perangkat")
        actions.add { pickAudio.launch(arrayOf("audio/*")) }

        labels.add("Meta Sound Collection")
        actions.add { startActivity(Intent(this, MetaSoundActivity::class.java)) }

        if (project.audio != null) {
            labels.add("Hapus musik")
            actions.add {
                project.audio = null
                syncAudioPlayer()
                afterStructureChange(currentTimelineMs())
            }
        }
        labels.add(if (project.muteOriginal) "Nyalakan suara asli video" else "Matikan suara asli video")
        actions.add {
            project.muteOriginal = !project.muteOriginal
            applySpeed()
            toast(if (project.muteOriginal) "Suara asli dimatikan" else "Suara asli dinyalakan")
        }

        dialog().setTitle("Musik & audio")
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun setAudio(track: AudioTrack) {
        project.audio = track
        syncAudioPlayer()
        afterStructureChange(currentTimelineMs())
        toast("Musik ditambahkan: ${track.name}")
    }

    private fun moveClip(delta: Int) {
        val i = selClip
        val j = i + delta
        if (i !in project.clips.indices || j !in project.clips.indices) return
        val pos = currentTimelineMs()
        val c = project.clips.removeAt(i)
        project.clips.add(j, c)
        selClip = j
        afterStructureChange(pos)
    }

    private fun deleteSelected() {
        if (project.clips.size <= 1) {
            toast("Proyek minimal memiliki satu klip")
            return
        }
        val c = selectedClip() ?: return
        project.clips.remove(c)
        selClip = selClip.coerceIn(0, project.clips.size - 1)
        afterStructureChange(min(currentTimelineMs(), project.totalMs))
    }

    // ---------------------------------------------------------------- export

    private fun showExportDialog() {
        player.pause()
        val resNames = arrayOf("1080p (Full HD)", "1440p (2K)", "2160p (4K)", "Native Resolution")
        val resValues = intArrayOf(1080, 1440, 2160, 0)
        val fpsValues = intArrayOf(0, 30, 60, 120) // 0 = FPS asli

        val resGroup = RadioGroup(this)
        resNames.forEachIndexed { i, n ->
            resGroup.addView(RadioButton(this).apply {
                id = 100 + i
                text = n
                setTextColor(0xFFFFFFFF.toInt())
            })
        }
        resGroup.check(100)

        val fpsGroup = RadioGroup(this)
        fpsValues.forEachIndexed { i, f ->
            fpsGroup.addView(RadioButton(this).apply {
                id = 200 + i
                text = if (f == 0) "FPS asli video (disarankan)" else "Maks. $f FPS"
                setTextColor(0xFFFFFFFF.toInt())
            })
        }
        fpsGroup.check(200)

        val note = label(
            "Frame rate 60/120 hanyalah batas maksimum. Aplikasi tidak membuat frame baru " +
                "(tanpa interpolasi), jadi gerakan tetap natural tanpa ghosting. " +
                "Video sumber 30 FPS tetap 30 FPS. Resolusi 4K/Native bergantung pada dukungan encoder perangkat."
        )
        val box = column().apply {
            addView(label("Resolusi"))
            addView(resGroup)
            addView(label("Frame rate"))
            addView(fpsGroup)
            addView(note)
        }
        val scroll = ScrollView(this)
        scroll.addView(box)

        dialog().setTitle("Ekspor video")
            .setView(scroll)
            .setPositiveButton("Ekspor") { _, _ ->
                val res = resValues[resGroup.checkedRadioButtonId - 100]
                val fps = fpsValues[fpsGroup.checkedRadioButtonId - 200]
                runExport(res, fps)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun runExport(shortSide: Int, fps: Int) {
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        val info = label("Memproses… jangan tutup aplikasi.")
        val box = column().apply {
            addView(info)
            addView(bar)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val ex = Exporter(this)
        exporter = ex
        val dlg = dialog().setTitle("Mengekspor…")
            .setView(box)
            .setCancelable(false)
            .setNegativeButton("Batalkan") { _, _ -> ex.cancel() }
            .create()
        exportDialog = dlg
        dlg.show()

        ex.start(project, shortSide, fps, object : Exporter.Callback {
            override fun onProgress(percent: Int) {
                bar.progress = percent
                info.text = "Memproses… $percent%"
            }

            override fun onDone(uri: Uri) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                dlg.dismiss()
                if (isFinishing || isDestroyed) return
                dialog().setTitle("Selesai")
                    .setMessage("Video tersimpan di galeri (Movies/ZuhudVideoEditor).")
                    .setPositiveButton("Buka") { _, _ ->
                        try {
                            startActivity(
                                Intent(Intent.ACTION_VIEW)
                                    .setDataAndType(uri, "video/mp4")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        } catch (e: Exception) {
                            toast("Tidak ada aplikasi pemutar video")
                        }
                    }
                    .setNegativeButton("Tutup", null)
                    .show()
            }

            override fun onError(message: String) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                dlg.dismiss()
                if (isFinishing || isDestroyed) return
                dialog().setTitle("Ekspor gagal")
                    .setMessage(
                        "$message\n\nCoba resolusi/FPS yang lebih rendah. " +
                            "Resolusi tinggi tidak didukung semua perangkat."
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }
        })
    }

    // --------------------------------------------------------------- helpers

    private fun dialog() = AlertDialog.Builder(this, R.style.ZuhudDialog)

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(8), dp(20), dp(4))
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(0xFFBBBBCC.toInt())
        textSize = 13f
        setPadding(0, dp(10), 0, dp(4))
    }

    private fun numberField(value: String) = EditText(this).apply {
        setText(value)
        setTextColor(0xFFFFFFFF.toInt())
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }

    private fun simpleSeek(onChange: () -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            if (fromUser) onChange()
        }

        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
