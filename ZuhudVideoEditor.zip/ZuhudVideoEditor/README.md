# Zuhud Video Editor

Editor video Android (Kotlin, Media3) dengan latar grafiti "Zuhud".

## Cara build APK lewat GitHub (dari HP)
1. Buat repository baru di GitHub.
2. Unggah **isi** folder proyek ini (bukan foldernya) ke root repository — termasuk folder tersembunyi `.github`.
   Alternatif: unggah `ZuhudVideoEditor.zip` apa adanya **beserta** file `.github/workflows/build-apk.yml`; workflow akan mengekstrak ZIP otomatis.
3. Buka tab **Actions** → **Build APK** → tunggu hingga hijau.
4. Buka run tersebut → bagian **Artifacts** → unduh `ZuhudVideoEditor-debug-apk` (ZIP berisi `app-debug.apk`), ekstrak, lalu pasang.

## Fitur
- Import video dari galeri (bisa banyak sekaligus)
- Potong, belah di posisi putar, gabung, urutkan, hapus klip
- Kecepatan 0.25x – 4x per klip
- Teks dengan waktu mulai dan durasi
- Musik dari perangkat atau dari Meta Sound Collection; suara asli bisa dimatikan
- Preview, lalu ekspor 1080p / 1440p / 4K / Native Resolution dengan pilihan FPS asli (default, disarankan) atau batas maksimum 30 / 60 / 120 FPS. Tidak ada frame interpolation/generation, jadi tidak ada ghosting atau bayangan ganda; sumber 30 FPS tidak dinaikkan menjadi 60/120
- Hasil disimpan di Movies/ZuhudVideoEditor

## Meta Sound Collection
Menu ini membuka halaman resmi `https://www.facebook.com/sound/collection/` di WebView. Anda login dengan akun Facebook sendiri, mencari, dan mengunduh memakai fitur resmi halaman tersebut. Aplikasi tidak memakai API tidak resmi atau scraping. Jika unduhan tidak berjalan di WebView, tombol **Browser** membukanya di browser, lalu gunakan **Pilih File** untuk mengimpor hasil unduhan.
Patuhi ketentuan lisensi Meta untuk penggunaan musik di video Anda.

## v4
- Nama aplikasi di perangkat: **ZuFX** (nama proyek/repo tetap ZuhudVideoEditor); ikon memakai logo ZuFX.
- Cubit layar di preview untuk zoom in/out video/foto utama (dua jari untuk geser; tombol "Reset zoom" di toolbar klip).
- Panel teks: Font (20 bawaan + font sistem + folder `/storage/emulated/0/fonts` + impor), Gaya, Efek, Animasi.
- Membaca `/storage/emulated/0/fonts` butuh izin "Akses semua file" (tombol "Izin akses file" di tab Font).

## v5
- Panel font lebih tinggi (naik sampai ~56% layar), kolom pencarian font.
- 275 font koleksi ikut di dalam aplikasi (tab "Koleksi", assets/fonts).
- Pilih media dari Galeri, Berkas/ZArchiver, atau aplikasi lain (MediaSources.kt). Media dari Galeri disalin ke penyimpanan aplikasi.
- v5.1: panel font ~62% tinggi layar; 489 font dari fontzuhud.zip menggantikan koleksi lama.
