# Zuhud Video Editor

Editor video Android (Kotlin, Media3) dengan latar grafiti "Zuhud".

## Cara build APK lewat GitHub (dari HP)
1. Buat repository baru di GitHub.
2. Unggah **isi** folder proyek ini (bukan foldernya) ke root repository — termasuk folder tersembunyi `.github`.
   Alternatif: unggah `ZuhudVideoEditor.zip` apa adanya **beserta** file `.github/workflows/build-apk.yml`; workflow akan mengekstrak ZIP otomatis.
3. Buka tab **Actions** → **Build APK** → tunggu hingga hijau.
4. Buka run tersebut → bagian **Artifacts** → unduh `ZuhudVideoEditor-debug-apk` (ZIP berisi `app-debug.apk`), ekstrak, lalu pasang.

## Fitur
- Import video dari galeri (bisa banyak sekaligus)
- Potong, belah di posisi putar, gabung, urutkan, hapus klip
- Kecepatan 0.25x – 4x per klip
- Teks dengan waktu mulai dan durasi
- Musik dari perangkat atau dari Meta Sound Collection; suara asli bisa dimatikan
- Preview, lalu ekspor 1080p / 1440p / 4K / Native Resolution dengan pilihan FPS asli (default, disarankan) atau batas maksimum 30 / 60 / 120 FPS. Tidak ada frame interpolation/generation, jadi tidak ada ghosting atau bayangan ganda; sumber 30 FPS tidak dinaikkan menjadi 60/120
- Hasil disimpan di Movies/ZuhudVideoEditor

## Meta Sound Collection
Menu ini membuka halaman resmi `https://www.facebook.com/sound/collection/` di WebView. Anda login dengan akun Facebook sendiri, mencari, dan mengunduh memakai fitur resmi halaman tersebut. Aplikasi tidak memakai API tidak resmi atau scraping. Jika unduhan tidak berjalan di WebView, tombol **Browser** membukanya di browser, lalu gunakan **Pilih File** untuk mengimpor hasil unduhan.
Patuhi ketentuan lisensi Meta untuk penggunaan musik di video Anda.

## v4
- Nama aplikasi di perangkat: **ZuFX** (nama proyek/repo tetap ZuhudVideoEditor); ikon memakai logo ZuFX.
- Cubit layar di preview untuk zoom in/out video/foto utama (dua jari untuk geser; tombol "Reset zoom" di toolbar klip).
- Panel teks: Font (20 bawaan + font sistem + folder `/storage/emulated/0/fonts` + impor), Gaya, Efek, Animasi.
- Membaca `/storage/emulated/0/fonts` butuh izin "Akses semua file" (tombol "Izin akses file" di tab Font).

## v5
- Panel font lebih tinggi (naik sampai ~56% layar), kolom pencarian font.
- 275 font koleksi ikut di dalam aplikasi (tab "Koleksi", assets/fonts).
- Pilih media dari Galeri, Berkas/ZArchiver, atau aplikasi lain (MediaSources.kt). Media dari Galeri disalin ke penyimpanan aplikasi.
- v5.1: panel font ~62% tinggi layar; 489 font dari fontzuhud.zip menggantikan koleksi lama.
- v6: Efek video (20 efek shader: Kabur, Mozaik, Vinyet, Glitch, VHS, dst.) di rentang waktu timeline, slider Sesuaikan, bar efek di timeline; preview via ExoPlayer.setVideoEffects, ekspor via Composition effects (Fx.kt).
- v6.1: Latar blur (mode muat): bingkai kosong diisi video yang diburamkan (shader di Fx.kt, tombol Latar blur).
- v7: 'Latar blur' jadi pilihan di panel Efek (rentang waktu + slider). Garis panduan cyan + magnet tengah saat geser/zoom video utama dan layer (GuideView.kt).
- v7.1: ubah rasio/isi layar -> video dipas ulang di tengah (zoom/geser direset); bagian yang dipangkas tidak lagi muncul di preview (clipBounds).
- v8: pangkas manual untuk layer PiP (foto/video), pilihan efek 'Tidak pakai', 'Latar blur' jadi efek biasa seluruh bingkai.
- v9: layar 'Ubah ukuran' penuh untuk pangkas video utama dan layer PiP (grid, rasio aspek, Reset, penggeser waktu).
- v10: tombol Ganti + Overlay (klip utama), Ganti + Utama (layer foto/video PiP); 3 ikon baru.
- v10.1: fix duplikat clipStartMs
- v10.2: urutan klip dengan tap-tahan lalu seret (tombol Mundur/Maju dihapus)
- v10.2: tombol Mundur/Maju dihapus; urut klip lewat tap-tahan lalu seret
- v10.3: tap-tahan klip -> semua klip mengecil jadi kotak untuk diurutkan
- v10.4: menu Audio ala CapCut (kisi ikon): Musik, Efek suara, Rekam, Ekstrak, Teks ke audio, Meta Sound, Bisukan asli, Hapus musik.
  - Klip audio tambahan (AudioClip) punya baris sendiri di timeline: geser, tarik tepi untuk memangkas, Bagi, Duplikat, Hapus, panel Suara (volume 0-200%, fade masuk/keluar).
  - Rekam: voice over dari posisi garis putar (izin mikrofon), video bisa dibisukan saat merekam.
  - Ekstrak: ambil audio klip video tanpa encode ulang (m4a), opsi bisukan suara asli.
  - Efek suara: 14 efek bawaan (disintesis, tanpa berkas aset) dengan pratinjau, atau pilih berkas dari perangkat.
  - Teks ke audio: memakai Text-to-Speech Android (Indonesia, Inggris, Arab, Jepang, Korea, Mandarin), atur kecepatan dan nada.
  - Ekspor: tiap klip audio jadi urutan sendiri (jeda hening, pangkas, fade, gain) dan dicampur dengan musik dan suara video.
